import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Plus, Trash2, Pencil, GanttChartSquare, Users as UsersIcon, X, Link2,
  Lock, Check, ArrowRight, Paperclip, Send, ChevronUp, ChevronDown,
  MessageSquare, Video, Mail, Download, Upload, ExternalLink,
} from "lucide-react";
import { api } from "../lib/api.js";
import { onRealtimeMessage } from "../lib/realtime.js";
import { copyText, fmtDate, fmtDateTime, fmtRelative, fmtSize, resolveUser } from "../lib/theme.js";
import { Avatar, Modal, ModalHeader, Field, Spinner, inputStyle } from "../lib/ui.jsx";
import { downloadFile } from "./AuthImage.jsx";
import FilePreview from "./FilePreview.jsx";
import InviteMembers from "./InviteMembers.jsx";

// =====================================================================
// Диаграммы Ганта.
//
// Записи диаграммы — самостоятельные: у них своё название, свои даты и
// свой прогресс. Это сознательно. Диаграмма нужна, чтобы крупно
// показать этапы работ — «проектирование», «согласование», «монтаж», —
// а этапу редко соответствует ровно одна задача в проекте. Тянуть сюда
// задачи приложения значило бы либо дробить диаграмму до уровня
// поручений, либо подменять сроки задач сроками этапов.
//
// Связь с задачами — только ссылки, добровольные. Если смотрящий к
// задаче не допущен, вместо названия он видит прямое объяснение.
// =====================================================================

// Масштаб: сколько пикселей в сутках и как подписывать шкалу.
const SCALES = {
  day:   { label: "День",   px: 34, step: 1 },
  week:  { label: "Неделя", px: 12, step: 7 },
  month: { label: "Месяц",  px: 4,  step: 30 },
};

const DAY = 24 * 60 * 60 * 1000;

const ymd = (d) => {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};
// Дата из строки YYYY-MM-DD как ЛОКАЛЬНАЯ полночь. new Date("2026-05-01")
// разбирается как UTC, и западнее Гринвича полоса уезжала бы на день назад.
const parseDay = (s) => {
  const [y, m, d] = String(s || "").split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
};
const daysBetween = (a, b) => Math.round((parseDay(b) - parseDay(a)) / DAY);
const addDays = (s, n) => { const d = parseDay(s); d.setDate(d.getDate() + n); return ymd(d); };

// Предопределённые цвета полос — как у задач. Свободная палитра на
// диаграмме быстро превращается в десяток почти одинаковых оттенков, и
// цвет перестаёт что-либо означать.
export const BAR_COLORS = [
  ["", "По умолчанию"],
  ["#2B4162", "Тёмно-синий"],
  ["#3D5A80", "Синий"],
  ["#4E7AA7", "Голубой"],
  ["#3E8EA8", "Лазурный"],
  ["#2A9D8F", "Бирюзовый"],
  ["#3F8F6B", "Изумрудный"],
  ["#5B8C5A", "Зелёный"],
  ["#7CA05A", "Оливковый"],
  ["#B5A642", "Горчичный"],
  ["#E9C46A", "Жёлтый"],
  ["#E8A33D", "Янтарный"],
  ["#E76F51", "Оранжевый"],
  ["#D0553F", "Кирпичный"],
  ["#C1666B", "Красный"],
  ["#A34A5E", "Бордовый"],
  ["#8E5572", "Сливовый"],
  ["#7768AE", "Сиреневый"],
  ["#5D5FA6", "Индиго"],
  ["#6C757D", "Серый"],
  ["#4A5259", "Графитовый"],
  ["#8C7B6B", "Коричневый"],
];

// Склонение слова «день» — сводка над диаграммой читается как фраза,
// и «5 дня» в ней выглядит как недоделка.
function plural(n) {
  const ten = n % 10;
  const hundred = n % 100;
  if (ten === 1 && hundred !== 11) return "день";
  if (ten >= 2 && ten <= 4 && (hundred < 10 || hundred >= 20)) return "дня";
  return "дней";
}

const DEFAULT_SETTINGS = {
  scale: "week",
  showWeekends: true,
  showToday: true,
  showLinks: true,
  rowHeight: 34,
  barColor: "",
};

export default function Charts({ theme, directory, team, currentUser, onError, onOpenTask, openId, onOpened }) {
  const [charts, setCharts] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.charts();
      setCharts(list);
      setActiveId((prev) => (prev && list.some((c) => c.id === prev) ? prev : list[0]?.id || null));
    } catch (e) {
      onError(e.message);
    } finally {
      setLoading(false);
    }
  }, [onError]);

  useEffect(() => { load(); }, [load]);

  // Диаграмма, открытая по ссылке.
  useEffect(() => {
    if (!openId) return;
    if (charts.some((c) => c.id === openId)) {
      setActiveId(openId);
      onOpened?.();
    }
  }, [openId, charts, onOpened]);

  // Чужие изменения самой диаграммы (название, настройки, состав).
  // Права и состав участников должны меняться на лету, без
  // перезагрузки страницы.
  useEffect(() => onRealtimeMessage("chart", () => { load(); }), [load]);

  const active = charts.find((c) => c.id === activeId) || null;

  const create = async (title) => {
    try {
      const ch = await api.createChart({ title, settings: DEFAULT_SETTINGS });
      setCharts((prev) => [...prev, ch]);
      setActiveId(ch.id);
      setCreating(false);
    } catch (e) { onError(e.message); }
  };

  if (loading) return <Spinner theme={theme} label="Загружаем диаграммы…" />;

  return (
    <div className="pb-6">
      <div className="flex items-center gap-2 flex-wrap mb-3">
        <h2 style={{ color: theme.text }} className="text-[15px] font-semibold flex items-center gap-2">
          <GanttChartSquare size={16} /> Диаграммы
        </h2>
        <button onClick={() => setCreating(true)}
          style={{ background: theme.accent, color: theme.accentText }}
          className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13px] font-semibold">
          <Plus size={14} /> Новая диаграмма
        </button>
      </div>

      {charts.length > 0 && (
        // Переключатель диаграмм — вкладками: их обычно единицы, и
        // прятать выбор в выпадающий список значило бы добавить
        // лишнее нажатие к самой частой операции.
        <div className="flex items-center gap-1.5 flex-wrap mb-3">
          {charts.map((ch) => (
            <button key={ch.id} onClick={() => setActiveId(ch.id)}
              style={{
                background: ch.id === activeId ? theme.accent : theme.surfaceAlt,
                color: ch.id === activeId ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-3 py-1.5 rounded-lg text-[12.5px] font-medium">
              {ch.title}
            </button>
          ))}
        </div>
      )}

      {charts.length === 0 ? (
        <p style={{ color: theme.textMuted }} className="text-[13px]">
          Диаграмм пока нет. Создайте первую — на ней удобно показать этапы работ
          крупно, вместе со сроками и зависимостями.
        </p>
      ) : active ? (
        <ChartView key={active.id} theme={theme} chart={active} directory={directory}
          team={team} currentUser={currentUser} onError={onError} onOpenTask={onOpenTask}
          onChanged={load}
          onDeleted={() => { setActiveId(null); load(); }} />
      ) : null}

      {creating && (
        <NameModal theme={theme} title="Новая диаграмма" onClose={() => setCreating(false)} onSave={create} />
      )}
    </div>
  );
}

/* ------------------------------------------------------- одна диаграмма */

function ChartView({ theme, chart, directory, team, currentUser, onError, onOpenTask, onChanged, onDeleted }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);   // запись или "new"
  const [membersOpen, setMembersOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);

  const canEdit = ["owner", "editor"].includes(chart.myRole);
  const isOwner = chart.myRole === "owner";

  const settings = useMemo(
    () => ({ ...DEFAULT_SETTINGS, ...(chart.settings || {}) }), [chart.settings]);

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await api.chartItems(chart.id)); }
    catch (e) { onError(e.message); }
    finally { setLoading(false); }
  }, [chart.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Чужие правки записей приходят событием без содержимого: связи
  // меняются пачкой, и перечитать список целиком надёжнее, чем сшивать
  // частичные изменения.
  useEffect(() => onRealtimeMessage("chartItems", (e) => {
    if (e.payload?.chartId === chart.id) load();
  }), [chart.id, load]);

  const saveItem = async (payload, id) => {
    try {
      if (id) {
        await api.updateChartItem(chart.id, id, payload);
        // Сроки, заданные в форме, подчиняются тому же правилу, что и
        // перетаскивание: следующие этапы не могут начинаться раньше,
        // чем закончится этот.
        if (payload.startsOn && payload.endsOn) {
          // Из формы сроки заданы оба сразу — сдвигать их целиком
          // нельзя, человек указал конкретные даты.
          await applySchedule(id, payload.startsOn, payload.endsOn, { keepLength: false });
        }
      } else {
        await api.createChartItem(chart.id, payload);
      }
      setEditing(null);
      load();
    } catch (e) { onError(e.message); }
  };

  const removeItem = async (id) => {
    try { await api.deleteChartItem(chart.id, id); setItems((p) => p.filter((i) => i.id !== id)); }
    catch (e) { onError(e.message); }
  };

  // Пересчёт сроков с оглядкой на связи.
  //
  // Правило одно: предшественник не может заканчиваться позже, чем
  // начинается следующий за ним этап. Но нарушить его можно с двух
  // сторон, и поступать в этих случаях надо по-разному.
  //
  // 1. Двигают предшественника, и он налез на следующий. Тогда
  //    следующие этапы сдвигаются вперёд целиком, сохраняя свою
  //    длительность, и так далее по цепочке.
  //
  // 2. Двигают следующего, и его начало уехало раньше, чем кончается
  //    предшественник. Предшественника при этом НЕ трогаем: он мог
  //    быть уже выполнен и сдан, и переписывать задним числом сроки
  //    законченной работы нельзя. Вместо этого начало ограничивается
  //    ближайшим допустимым днём. Длительность при переносе целиком
  //    сохраняется — этап просто не пускают раньше положенного; при
  //    растягивании за левый край он укорачивается до предела.
  //
  // Замкнуться цепочка не может — этого не допускает база (0021), — но
  // счётчик оборотов всё равно стоит: испорченные данные не должны
  // подвешивать браузер.
  const cascade = (changedId, startsOn, endsOn, { keepLength = true } = {}) => {
    const map = new Map(items.map((i) => [i.id, { ...i }]));
    const changed = new Map();

    const me = map.get(changedId);
    if (!me) return [];

    // Кто стоит перед этим этапом.
    const predecessors = items.filter((i) => (i.next || []).includes(changedId));
    let earliestStart = "";
    for (const p of predecessors) {
      const limit = addDays(p.endsOn, 1);
      if (limit > earliestStart) earliestStart = limit;
    }

    let s0 = startsOn;
    let e0 = endsOn;
    if (earliestStart && s0 < earliestStart) {
      if (keepLength) {
        // Перенос целиком: сдвигаем обе даты, длительность та же.
        const shift = daysBetween(s0, earliestStart);
        s0 = earliestStart;
        e0 = addDays(e0, shift);
      } else {
        // Тянут именно за начало — укорачиваем, но не заходим за
        // окончание.
        s0 = earliestStart > e0 ? e0 : earliestStart;
      }
    }

    me.startsOn = s0;
    me.endsOn = e0;
    changed.set(changedId, me);

    const queue = [changedId];
    for (let guard = 0; queue.length && guard < 500; guard++) {
      const cur = map.get(queue.shift());
      for (const nextId of cur.next || []) {
        const nx = map.get(nextId);
        if (!nx) continue;
        const earliest = addDays(cur.endsOn, 1);
        if (nx.startsOn >= earliest) continue;
        const shift = daysBetween(nx.startsOn, earliest);
        nx.startsOn = addDays(nx.startsOn, shift);
        nx.endsOn = addDays(nx.endsOn, shift);
        changed.set(nx.id, nx);
        queue.push(nx.id);
      }
    }
    return [...changed.values()];
  };

  // Сроки применяются сразу на экране и лишь потом уходят на сервер:
  // ждать ответа, держа полосу под курсором, неприятно, а правка
  // мелкая и почти никогда не отклоняется.
  const applySchedule = async (id, startsOn, endsOn, opts) => {
    const affected = cascade(id, startsOn, endsOn, opts);
    if (affected.length === 0) return;
    setItems((prev) => prev.map((i) => {
      const upd = affected.find((a) => a.id === i.id);
      return upd ? { ...i, startsOn: upd.startsOn, endsOn: upd.endsOn } : i;
    }));
    try {
      for (const a of affected) {
        await api.updateChartItem(chart.id, a.id, { startsOn: a.startsOn, endsOn: a.endsOn });
      }
    } catch (e) {
      onError(e.message);
    }
    load();
  };

  // Порядок строк. Меняется местами с соседом: «выше» и «ниже» —
  // ровно то, что нужно, когда этапы завели не в том порядке.
  const moveRow = async (id, dir) => {
    const idx = items.findIndex((i) => i.id === id);
    const other = idx + (dir === "up" ? -1 : 1);
    if (idx === -1 || other < 0 || other >= items.length) return;
    const a = items[idx];
    const b = items[other];
    // Позиции могли совпасть (например, после массового переноса) —
    // тогда простой обмен ничего не даст, и порядок задаётся заново по
    // месту в списке.
    const next = [...items];
    next[idx] = b;
    next[other] = a;
    setItems(next);
    try {
      await Promise.all(next.map((it, i) =>
        (it.position === i ? null : api.updateChartItem(chart.id, it.id, { position: i }))));
    } catch (e) { onError(e.message); }
    load();
  };

  // Границы всей диаграммы. Продолжительность считается по календарю,
  // от первого дня самого раннего этапа до последнего дня самого
  // позднего, включительно: на вопрос «сколько это займёт» отвечают
  // именно так, а не суммой длительностей этапов, которые
  // перекрываются.
  const span = useMemo(() => {
    if (items.length === 0) return null;
    let first = items[0];
    let last = items[0];
    for (const it of items) {
      if (it.startsOn < first.startsOn) first = it;
      if (it.endsOn > last.endsOn) last = it;
    }
    return { first, last, days: daysBetween(first.startsOn, last.endsOn) + 1 };
  }, [items]);

  const saveSettings = async (next) => {
    try { await api.updateChart(chart.id, { settings: next }); setSettingsOpen(false); onChanged(); }
    catch (e) { onError(e.message); }
  };

  return (
    <div>
      <div className="flex items-center gap-2 flex-wrap mb-1">
        <span style={{ color: theme.textMuted }} className="text-[11.5px]">
          {chart.myRole === "owner" ? "Владелец" : chart.myRole === "editor" ? "Редактор" : "Исполнитель"}
          {" · "}{items.length} {items.length === 1 ? "этап" : "этапов"}
        </span>

        <div className="ml-auto flex items-center gap-1.5 flex-wrap">
          <button onClick={async () => {
            const url = `${window.location.origin}/charts/${chart.id}`;
            if (await copyText(url)) {
              setLinkCopied(true);
              setTimeout(() => setLinkCopied(false), 2000);
            } else {
              onError("Не удалось скопировать. Ссылка на диаграмму: " + url);
            }
          }}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]"
            title="Скопировать ссылку на диаграмму">
            {linkCopied ? <Check size={13} /> : <Link2 size={13} />} {linkCopied ? "Скопировано" : "Ссылка"}
          </button>
          <button onClick={() => setInviteOpen(true)}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]"
            title="Позвать участников: созвон, письмо, уведомление">
            <Video size={13} /> Собрать
          </button>
          <button onClick={() => setSettingsOpen(true)}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="px-2.5 py-1.5 rounded-lg text-[12px]">Вид</button>
          {canEdit && (
            <>
              <button onClick={() => setEditing("new")}
                style={{ background: theme.accent, color: theme.accentText }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px] font-semibold">
                <Plus size={13} /> Запись
              </button>
              <button onClick={() => setMembersOpen(true)}
                style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[12px]">
                <UsersIcon size={13} /> Участники
              </button>
              <button onClick={() => setRenaming(true)} style={{ color: theme.textMuted }}
                className="p-1.5" title="Переименовать"><Pencil size={14} /></button>
            </>
          )}
          {isOwner && (
            <button onClick={() => setConfirmDelete(true)}
              style={{ color: theme.danger }} className="p-1.5" title="Удалить диаграмму">
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Сводка по срокам: с какого этапа всё начинается, каким
          заканчивается и сколько времени занимает целиком. Иначе эти
          три числа приходится вычитывать с полотна глазами, а на
          длинной диаграмме их просто не видно одновременно. */}
      {span && (
        <div style={{ color: theme.textMuted }}
          className="text-[11.5px] mb-3 flex flex-wrap items-center gap-x-4 gap-y-0.5">
          <span>
            Начало: <b style={{ color: theme.text }}>{fmtDate(span.first.startsOn)}</b>
            {" — "}{span.first.title}
          </span>
          <span>
            Окончание: <b style={{ color: theme.text }}>{fmtDate(span.last.endsOn)}</b>
            {" — "}{span.last.title}
          </span>
          <span>
            Продолжительность: <b style={{ color: theme.text }}>{span.days}</b> {plural(span.days)}
          </span>
        </div>
      )}

      {loading ? (
        <Spinner theme={theme} label="Загружаем этапы…" />
      ) : items.length === 0 ? (
        <p style={{ color: theme.textMuted }} className="text-[13px]">
          Записей пока нет. {canEdit ? "Добавьте первый этап работ." : ""}
        </p>
      ) : (
        <Gantt theme={theme} items={items} settings={settings} canEdit={canEdit}
          onEdit={(it) => setEditing(it)} onOpenTask={onOpenTask}
          onSchedule={applySchedule} onMoveRow={moveRow} />
      )}

      {editing && (
        <ItemModal theme={theme} theItem={editing === "new" ? null : editing}
          items={items} chartId={chart.id} directory={directory} currentUser={currentUser}
          canEdit={canEdit} onClose={() => setEditing(null)}
          onSave={(payload) => saveItem(payload, editing === "new" ? null : editing.id)}
          onDelete={editing === "new" ? null : () => { removeItem(editing.id); setEditing(null); }}
          onError={onError} />
      )}

      {membersOpen && (
        <MembersModal theme={theme} directory={directory} team={team} currentUser={currentUser}
          members={chart.members || []} isOwner={isOwner}
          title={`Участники диаграммы «${chart.title}»`}
          onClose={() => setMembersOpen(false)}
          onSave={async (list) => {
            try { await api.setChartMembers(chart.id, list); setMembersOpen(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {renaming && (
        <NameModal theme={theme} title="Название диаграммы" initial={chart.title}
          onClose={() => setRenaming(false)}
          onSave={async (title) => {
            try { await api.updateChart(chart.id, { title }); setRenaming(false); onChanged(); }
            catch (e) { onError(e.message); }
          }} />
      )}

      {settingsOpen && (
        <SettingsModal theme={theme} settings={settings} canEdit={canEdit}
          onClose={() => setSettingsOpen(false)} onSave={saveSettings} />
      )}

      {inviteOpen && (
        <InviteMembers theme={theme} kind="chart" object={chart} directory={directory}
          currentUser={currentUser} onClose={() => setInviteOpen(false)} onError={onError} />
      )}

      {confirmDelete && (
        <Modal theme={theme} onClose={() => setConfirmDelete(false)} width="max-w-sm">
          <ModalHeader theme={theme} title="Удалить диаграмму?" onClose={() => setConfirmDelete(false)} />
          <p style={{ color: theme.textMuted }} className="text-[13px] leading-relaxed mb-4">
            Диаграмма «{chart.title}» со всеми этапами, обсуждением и файлами исчезнет
            у всех участников. Отменить это нельзя.
          </p>
          <div className="flex gap-2">
            <button onClick={() => setConfirmDelete(false)}
              style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
              className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
            <button onClick={async () => {
              try { await api.deleteChart(chart.id); onDeleted(); }
              catch (e) { onError(e.message); }
            }} style={{ background: theme.danger, color: "#fff" }}
              className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold">Удалить</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* --------------------------------------------------------------- полотно */

function Gantt({ theme, items, settings, canEdit, onEdit, onOpenTask, onSchedule, onMoveRow }) {
  const scale = SCALES[settings.scale] || SCALES.week;
  const rowH = Number(settings.rowHeight) || 34;

  // Границы полотна — от самой ранней даты до самой поздней, с полями
  // по краям: полоса, упирающаяся в край, читается как обрезанная.
  const [from, to] = useMemo(() => {
    const starts = items.map((i) => i.startsOn).sort();
    const ends = items.map((i) => i.endsOn).sort();
    const a = addDays(starts[0] || ymd(new Date()), -3);
    const b = addDays(ends[ends.length - 1] || ymd(new Date()), 3);
    return [a, b];
  }, [items]);

  const totalDays = Math.max(1, daysBetween(from, to));
  const width = totalDays * scale.px;
  const today = ymd(new Date());

  // Мышью в области дней меняются только сроки. Три режима:
  //
  //   move  — тянут саму полосу: этап едет целиком, длительность та же;
  //   start — тянут левый кружок: двигается только начало;
  //   end   — правый кружок: только окончание.
  //
  // Окно правки отсюда не открывается вовсе. Раньше по нажатию на
  // полосу оно открывалось, а перетаскивание при этом продолжало
  // работать: нажатие на что-нибудь в открытом окне сдвигало этап на
  // другие сроки, и сам этап при этом было не отредактировать.
  // Теперь правка живёт на названии этапа, слева, где дней нет.
  const drag = useRef(null);
  const [dragState, setDragState] = useState(null); // { id, mode, days }

  // Слушатели мыши вешаются в момент нажатия, а не в useEffect.
  //
  // Раньше эффект без зависимостей проверял ссылку drag.current и,
  // если перетаскивание ещё не началось, слушателей не вешал вовсе.
  // Нажатие меняло только ссылку, а ссылка отрисовку не вызывает — и
  // слушатели появлялись, лишь если между нажатием и движением мыши
  // случалась посторонняя перерисовка. Отсюда и была «работает раз из
  // десяти»: поведение зависело от того, пришло ли в этот момент
  // событие по WebSocket или сработал ли чей-то таймер.
  //
  // Теперь порядок обычный: нажали — подписались, отпустили —
  // отписались. Ничего случайного в этой цепочке не осталось.
  const startDrag = (e, item, mode) => {
    if (!canEdit) return;
    e.preventDefault();
    e.stopPropagation();

    const startX = e.clientX;
    drag.current = { id: item.id, item, x: startX, mode, days: 0 };
    setDragState({ id: item.id, mode, days: 0 });

    const move = (ev) => {
      const d = drag.current;
      if (!d) return;
      const days = Math.round((ev.clientX - d.x) / scale.px);
      if (days === d.days) return;      // тот же день — не перерисовываем
      d.days = days;
      setDragState({ id: d.id, mode: d.mode, days });
    };

    const up = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
      const d = drag.current;
      drag.current = null;
      setDragState(null);
      if (!d || d.days === 0) return;

      const it = d.item;
      if (d.mode === "move") {
        // Перенос целиком: длительность сохраняется.
        onSchedule(it.id, addDays(it.startsOn, d.days), addDays(it.endsOn, d.days),
          { keepLength: true });
      } else if (d.mode === "start") {
        // Начало не может уехать за окончание: этап отрицательной
        // длительности нарисовать нечем, и база его не примет.
        const next = addDays(it.startsOn, d.days);
        onSchedule(it.id, next > it.endsOn ? it.endsOn : next, it.endsOn,
          { keepLength: false });
      } else {
        const next = addDays(it.endsOn, d.days);
        onSchedule(it.id, it.startsOn, next < it.startsOn ? it.startsOn : next,
          { keepLength: false });
      }
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  // Метки шкалы. Для дневного масштаба подписывается каждый день, для
  // недельного — понедельники, для месячного — первые числа.
  const ticks = useMemo(() => {
    const out = [];
    for (let i = 0; i <= totalDays; i++) {
      const d = parseDay(addDays(from, i));
      const isMonthStart = d.getDate() === 1;
      const isWeekStart = d.getDay() === 1;
      const show = settings.scale === "day" || (settings.scale === "week" ? isWeekStart : isMonthStart);
      if (!show) continue;
      out.push({
        x: i * scale.px,
        label: settings.scale === "month"
          ? d.toLocaleDateString("ru-RU", { month: "short", year: "2-digit" })
          : d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" }),
        strong: isMonthStart,
      });
    }
    return out;
  }, [from, totalDays, scale.px, settings.scale]);

  const byId = useMemo(() => new Map(items.map((i, idx) => [i.id, idx])), [items]);
  const barColor = (it) => it.color || settings.barColor || theme.accent;

  // Где полоса окажется с учётом того, что её сейчас тянут.
  const posOf = (it, idx) => {
    const st = dragState && dragState.id === it.id ? dragState : null;
    let startDays = daysBetween(from, it.startsOn);
    let lenDays = Math.max(1, daysBetween(it.startsOn, it.endsOn) + 1);
    if (st) {
      if (st.mode === "move") startDays += st.days;
      else if (st.mode === "start") {
        const d = Math.min(st.days, lenDays - 1);
        startDays += d;
        lenDays -= d;
      } else {
        lenDays = Math.max(1, lenDays + st.days);
      }
    }
    return { left: startDays * scale.px, width: lenDays * scale.px, top: idx * rowH + 6 };
  };

  return (
    <div style={{ background: theme.surface, border: `1px solid ${theme.border}` }}
      className="rounded-2xl overflow-hidden">
      <div className="flex">
        {/* Названия — отдельной неподвижной колонкой: прокручивая
            полотно на три месяца вперёд, нужно продолжать видеть, чья
            это полоса. */}
        <div style={{ borderColor: theme.border, background: theme.surfaceAlt }}
          className="shrink-0 border-r" >
          <div style={{ height: 30, borderColor: theme.border }}
            className="border-b flex items-center px-3">
            <span style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide">Этап</span>
          </div>
          {items.map((it, idx) => (
            <div key={it.id} style={{ height: rowH, borderColor: theme.border, width: 280 }}
              className="border-b flex items-center px-2 gap-1 group">
              {/* Порядок строк. Появляется по наведению: постоянные
                  стрелки у каждой строки создают рябь, а нужны они
                  редко. */}
              {canEdit && (
                <div className="flex flex-col opacity-0 group-hover:opacity-100 shrink-0">
                  <button onClick={() => onMoveRow(it.id, "up")} disabled={idx === 0}
                    style={{ color: theme.textMuted }} className="disabled:opacity-25 leading-none"
                    title="Выше"><ChevronUp size={12} /></button>
                  <button onClick={() => onMoveRow(it.id, "down")} disabled={idx === items.length - 1}
                    style={{ color: theme.textMuted }} className="disabled:opacity-25 leading-none"
                    title="Ниже"><ChevronDown size={12} /></button>
                </div>
              )}
              {/* Правка этапа — по названию. В области дней мышь занята
                  сроками, и нажатие там ничего не открывает. */}
              <button onClick={() => onEdit(it)}
                style={{ color: theme.text }}
                className="text-[12.5px] truncate flex-1 text-left hover:underline"
                title={`${it.title} — открыть этап`}>
                {it.title}
              </button>
              {/* Значки обсуждения и файлов — как в карточке задачи:
                  видно, что по этапу есть разговор, не открывая его. */}
              <span className="flex items-center gap-1.5 shrink-0" style={{ color: theme.textMuted }}>
                {it.commentCount > 0 && (
                  <span className="flex items-center gap-0.5 text-[10.5px]"
                    title={`Замечаний: ${it.commentCount}`}>
                    <MessageSquare size={11} />{it.commentCount}
                  </span>
                )}
                {it.fileCount > 0 && (
                  <span className="flex items-center gap-0.5 text-[10.5px]"
                    title={`Файлов: ${it.fileCount}`}>
                    <Paperclip size={11} />{it.fileCount}
                  </span>
                )}
                {it.tasks?.length > 0 && (
                  <Link2 size={11} title={`Ссылок на задачи: ${it.tasks.length}`} />
                )}
              </span>
            </div>
          ))}
        </div>

        <div className="flex-1 overflow-x-auto">
          <div style={{ width, position: "relative" }}>
            {/* Шкала */}
            <div style={{ height: 30, borderColor: theme.border }}
              className="border-b relative">
              {ticks.map((t, i) => (
                <div key={i} style={{ left: t.x, color: theme.textMuted }}
                  className="absolute top-0 h-full flex items-center pl-1 text-[10px] whitespace-nowrap">
                  {t.label}
                </div>
              ))}
            </div>

            <div style={{ height: items.length * rowH, position: "relative" }}>
              {/* Сетка и выходные */}
              {settings.showWeekends && scale.px >= 8 && Array.from({ length: totalDays + 1 }, (_, i) => {
                const d = parseDay(addDays(from, i));
                const weekend = d.getDay() === 0 || d.getDay() === 6;
                if (!weekend) return null;
                return (
                  <div key={i} style={{
                    left: i * scale.px, width: scale.px,
                    background: theme.dark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.035)",
                  }} className="absolute top-0 bottom-0" />
                );
              })}
              {ticks.map((t, i) => (
                <div key={`g${i}`} style={{ left: t.x, background: theme.border, opacity: t.strong ? 0.9 : 0.45 }}
                  className="absolute top-0 bottom-0 w-px" />
              ))}
              {/* Прошедшее время — приглушённой заливкой. Без неё
                  линия «сегодня» есть, но на глаз не видно, какая
                  часть работ уже позади. */}
              {today > from && (
                <div style={{
                  left: 0,
                  width: Math.min(totalDays, Math.max(0, daysBetween(from, today))) * scale.px,
                  background: theme.dark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)",
                }} className="absolute top-0 bottom-0" title="Уже прошло" />
              )}

              {settings.showToday && today >= from && today <= to && (
                <div style={{ left: daysBetween(from, today) * scale.px, background: theme.danger }}
                  className="absolute top-0 bottom-0 w-px z-10" title="Сегодня" />
              )}

              {/* Связи «за этой записью следует эта». Рисуются простой
                  ломаной: выход справа от предшественника, вход слева
                  у следующего. Кривые Безье выглядят наряднее, но на
                  плотной диаграмме путаются между собой. */}
              {settings.showLinks && (
                <svg width={width} height={items.length * rowH}
                  className="absolute inset-0 pointer-events-none">
                  {items.flatMap((it, idx) => (it.next || []).map((toId) => {
                    const j = byId.get(toId);
                    if (j === undefined) return null;
                    const a = posOf(it, idx);
                    const b = posOf(items[j], j);
                    const x1 = a.left + a.width;
                    const y1 = a.top + (rowH - 12) / 2;
                    const x2 = b.left;
                    const y2 = b.top + (rowH - 12) / 2;
                    const mx = Math.max(x1 + 8, x2 - 8);
                    return (
                      <g key={`${it.id}-${toId}`}>
                        <path d={`M ${x1} ${y1} H ${mx} V ${y2} H ${x2}`}
                          fill="none" stroke={theme.textMuted} strokeWidth="1.2" opacity="0.7" />
                        <path d={`M ${x2} ${y2} l -5 -3 v 6 z`} fill={theme.textMuted} opacity="0.9" />
                      </g>
                    );
                  }))}
                </svg>
              )}

              {/* Полосы */}
              {items.map((it, idx) => {
                const p = posOf(it, idx);
                const color = barColor(it);
                const dragging = dragState?.id === it.id;
                if (it.milestone) {
                  return (
                    <div key={it.id}
                      onMouseDown={(e) => startDrag(e, it, "move")}
                      style={{ left: p.left, top: p.top, background: color,
                        opacity: dragging ? 0.75 : 1, cursor: canEdit ? "grab" : "default" }}
                      className="absolute w-3 h-3 rotate-45"
                      title={`${it.title} · ${fmtDate(it.startsOn)}`} />
                  );
                }
                return (
                  <div key={it.id} className="absolute"
                    style={{ left: p.left, top: p.top, width: p.width, height: rowH - 12 }}>
                    <div
                      onMouseDown={(e) => startDrag(e, it, "move")}
                      style={{
                        background: color, opacity: dragging ? 0.75 : 1,
                        cursor: canEdit ? "grab" : "default",
                      }}
                      className="w-full h-full rounded-md overflow-hidden flex items-center px-2 relative"
                      title={`${it.title}: ${fmtDate(it.startsOn)} — ${fmtDate(it.endsOn)} · готово ${it.progress}%`}>
                      {it.progress > 0 && (
                        <div style={{ width: `${it.progress}%`, background: "rgba(255,255,255,0.35)" }}
                          className="absolute inset-y-0 left-0" />
                      )}
                      <span className="relative text-[11px] font-medium truncate" style={{ color: "#fff" }}>
                        {it.progress > 0 ? `${it.progress}% ` : ""}{it.title}
                      </span>
                    </div>

                    {/* Кружки начала и окончания. Двигаются порознь:
                        «этап начнётся позже, а сдать всё равно к
                        сроку» — обычный случай, и растягивать его
                        переносом всей полосы неудобно. */}
                    {canEdit && (
                      <>
                        <div onMouseDown={(e) => startDrag(e, it, "start")}
                          style={{ background: theme.surface, borderColor: color, left: -5,
                            top: (rowH - 12) / 2 - 5 }}
                          className="absolute w-2.5 h-2.5 rounded-full border-2 cursor-ew-resize"
                          title={`Начало: ${fmtDate(it.startsOn)}`} />
                        <div onMouseDown={(e) => startDrag(e, it, "end")}
                          style={{ background: theme.surface, borderColor: color, right: -5,
                            top: (rowH - 12) / 2 - 5 }}
                          className="absolute w-2.5 h-2.5 rounded-full border-2 cursor-ew-resize"
                          title={`Окончание: ${fmtDate(it.endsOn)}`} />
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Ссылки на задачи — списком под полотном, а не внутри полос:
          в полосу они не помещаются, а прятать их совсем значит
          лишить диаграмму связи с работой. */}
      {items.some((i) => i.tasks?.length) && (
        <div style={{ borderColor: theme.border }} className="border-t p-3">
          <div style={{ color: theme.textMuted }} className="text-[10.5px] uppercase tracking-wide mb-2">
            Связанные задачи
          </div>
          {items.filter((i) => i.tasks?.length).map((it) => (
            <div key={it.id} className="mb-1.5 flex items-start gap-2 flex-wrap">
              <span style={{ color: theme.text }} className="text-[12px] font-medium">{it.title}:</span>
              {it.tasks.map((t) => (t.visible ? (
                <button key={t.taskId} onClick={() => onOpenTask?.(t.taskId)}
                  style={{ color: theme.accent }} className="text-[12px] flex items-center gap-1">
                  <Link2 size={11} /> {t.title}
                  {t.boardTitle ? <span style={{ color: theme.textMuted }}> · {t.boardTitle}</span> : null}
                  {t.completed && <Check size={11} style={{ color: theme.success }} />}
                </button>
              ) : (
                // Задача есть, но смотрящий к ней не допущен. Говорим
                // об этом прямо: пустая строка или молчаливое
                // исчезновение ссылки выглядят как ошибка.
                <span key={t.taskId} style={{ color: theme.textMuted }}
                  className="text-[12px] flex items-center gap-1">
                  <Lock size={11} /> у вас отсутствует возможность просмотреть детальную информацию о задаче
                </span>
              )))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------- окна диаграммы */

function ItemModal({ theme, theItem, items, chartId, directory, currentUser, canEdit, onClose, onSave, onDelete, onError }) {
  const [form, setForm] = useState(() => ({
    title: theItem?.title || "",
    description: theItem?.description || "",
    startsOn: theItem?.startsOn || ymd(new Date()),
    endsOn: theItem?.endsOn || addDays(ymd(new Date()), 6),
    progress: theItem?.progress ?? 0,
    color: theItem?.color || "",
    milestone: theItem?.milestone || false,
    next: theItem?.next || [],
    tasks: (theItem?.tasks || []).map((t) => t.taskId),
  }));
  const [taskOptions, setTaskOptions] = useState(null);
  const [pickTask, setPickTask] = useState("");
  const [taskSearch, setTaskSearch] = useState("");
  const [tab, setTab] = useState("details");

  useEffect(() => {
    // Все доступные задачи, а не только «мои».
    //
    // Раньше запрашивались задачи, где человек автор или исполнитель, —
    // и этап нечем было связать с задачей, которую ведёт коллега, хотя
    // видеть её человек вправе. Для диаграммы важна именно видимость:
    // права на саму задачу это не меняет.
    let dead = false;
    const params = new URLSearchParams({ scope: "all", limit: "200", sort: "updated" });
    if (taskSearch.trim()) params.set("q", taskSearch.trim());
    api.allTasks(params.toString())
      .then((res) => { if (!dead) setTaskOptions(res?.items || []); })
      .catch(() => { if (!dead) setTaskOptions([]); });
    return () => { dead = true; };
  }, [taskSearch]);

  // Какие записи нельзя назначить следующими: те, из которых уже есть
  // путь в эту. Иначе получилась бы замкнутая цепочка «этап 1 → этап 2
  // → этап 1», которую невозможно выполнить. Сервер такую связь тоже
  // не примет, но подсветить её лучше заранее, а не сообщением об
  // ошибке после сохранения.
  const wouldCycle = useMemo(() => {
    const byId = new Map(items.map((i) => [i.id, i]));
    const reaches = (fromId, targetId, seen = new Set()) => {
      if (fromId === targetId) return true;
      if (seen.has(fromId)) return false;
      seen.add(fromId);
      const node = byId.get(fromId);
      return (node?.next || []).some((n) => reaches(n, targetId, seen));
    };
    const me = theItem?.id;
    const bad = new Set();
    if (me) {
      for (const it of items) {
        if (it.id !== me && reaches(it.id, me)) bad.add(it.id);
      }
    }
    return bad;
  }, [items, theItem?.id]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.title.trim()) return onError("Укажите название записи");
    if (form.endsOn < form.startsOn) return onError("Окончание раньше начала");
    onSave({
      title: form.title.trim(),
      description: form.description,
      startsOn: form.startsOn,
      // У вехи нет длительности: это событие, а не отрезок.
      endsOn: form.milestone ? form.startsOn : form.endsOn,
      progress: Number(form.progress) || 0,
      color: form.color,
      milestone: form.milestone,
      next: [...new Set(form.next)],
      tasks: [...new Set(form.tasks)],
    });
  };

  const others = items.filter((i) => i.id !== theItem?.id);
  const chosenTasks = (taskOptions || []).filter((t) => form.tasks.includes(t.id));
  // Отключённые поля приглушаются: иначе «только просмотр» заметен
  // лишь по тому, что ввод не работает.
  const fieldStyle = canEdit ? inputStyle(theme)
    : { ...inputStyle(theme), opacity: 0.65, cursor: "default" };

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-lg" geometryKey="chart-item">
      <ModalHeader theme={theme} title={theItem ? "Этап диаграммы" : "Новый этап"} onClose={onClose} />

      {/* Обсуждение и история появляются только у сохранённого этапа:
          писать комментарии к тому, чего ещё нет, некуда. */}
      {theItem && (
        <div style={{ borderColor: theme.border }} className="flex gap-1 border-b mb-3">
          {[["details", "Этап"], ["talk", "Обсуждение и файлы"], ["history", "История"]].map(([id, label]) => (
            <button key={id} onClick={() => setTab(id)}
              style={{
                color: tab === id ? theme.text : theme.textMuted,
                borderBottom: `2px solid ${tab === id ? theme.accent : "transparent"}`,
              }}
              className="px-2.5 py-1.5 text-[12.5px] font-medium -mb-px">{label}</button>
          ))}
        </div>
      )}

      {tab === "talk" && theItem ? (
        <ItemTalk theme={theme} chartId={chartId} item={theItem} directory={directory}
          currentUser={currentUser} onError={onError} />
      ) : tab === "history" && theItem ? (
        <ItemHistory theme={theme} chartId={chartId} item={theItem}
          directory={directory} onError={onError} />
      ) : (
      <>
      {/* Исполнителю этап доступен только для чтения.
          Раньше поля были обычными, но сохранить их он не мог: сервер
          отвергал правку, и человек терял набранное. Показывать
          изменяемое поле, зная, что изменение не примут, неправильно —
          поэтому поля просто не редактируются, а сверху сказано,
          почему. Обсуждение и файлы ему по-прежнему доступны. */}
      {!canEdit && (
        <div style={{ background: theme.surfaceAlt, color: theme.textMuted, border: `1px solid ${theme.border}` }}
          className="rounded-lg px-3 py-2 text-[12px] mb-3 flex items-center gap-2">
          <Lock size={13} /> Только просмотр: изменять этап может владелец или редактор
          диаграммы. Замечания и файлы — на вкладке «Обсуждение и файлы».
        </div>
      )}
      <Field label="Название" theme={theme}>
        <input value={form.title} onChange={(e) => set("title", e.target.value)} autoFocus
          disabled={!canEdit}
          style={fieldStyle} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
      </Field>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Начало" theme={theme}>
          <input type="date" value={form.startsOn} onChange={(e) => set("startsOn", e.target.value)}
            disabled={!canEdit}
            style={fieldStyle} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
        </Field>
        <Field label={form.milestone ? "Окончание (веха)" : "Окончание"} theme={theme}>
          <input type="date" value={form.milestone ? form.startsOn : form.endsOn}
            disabled={form.milestone || !canEdit}
            onChange={(e) => set("endsOn", e.target.value)}
            style={{ ...fieldStyle, opacity: (form.milestone || !canEdit) ? 0.5 : 1 }}
            className="w-full rounded-lg px-3 py-2 text-[13px] outline-none" />
        </Field>
      </div>

      <div className="flex items-center gap-4 mb-3 flex-wrap">
        <label className="flex items-center gap-2 text-[12.5px]" style={{ color: theme.text }}>
          <input type="checkbox" checked={form.milestone} disabled={!canEdit}
            onChange={(e) => set("milestone", e.target.checked)} />
          Веха (событие без длительности)
        </label>
        <div className="flex items-center gap-2">
          <span style={{ color: theme.textMuted }} className="text-[12px]">Готово, %</span>
          <input type="number" min="0" max="100" value={form.progress} disabled={!canEdit}
            onChange={(e) => set("progress", e.target.value)}
            style={fieldStyle} className="w-20 rounded-lg px-2 py-1 text-[12.5px] outline-none" />
        </div>
      </div>

      <Field label="Цвет полосы" theme={theme}>
        <div className="flex items-center gap-1.5 flex-wrap">
          {BAR_COLORS.map(([c, name]) => (
            <button key={c || "default"} onClick={() => set("color", c)} title={name} disabled={!canEdit}
              style={{
                background: c || theme.surfaceAlt,
                border: `1px solid ${theme.border}`,
                outline: form.color === c ? `2px solid ${theme.accent}` : "none",
                color: theme.text,
              }}
              className="h-7 min-w-[28px] px-2 rounded-lg text-[11px]">
              {c ? "" : "по умолчанию"}
            </button>
          ))}
        </div>
      </Field>

      <Field label="Описание" theme={theme}>
        <textarea value={form.description} onChange={(e) => set("description", e.target.value)}
          rows={2} disabled={!canEdit} style={fieldStyle}
          className="w-full rounded-lg px-3 py-2 text-[13px] outline-none resize-none" />
      </Field>

      {others.length > 0 && (
        <Field label="Следующие записи" theme={theme}
          hint="Стрелка на диаграмме: эта запись предшествует отмеченным.">
          <div className="flex flex-wrap gap-1.5">
            {others.map((o) => {
              const on = form.next.includes(o.id);
              const blocked = wouldCycle.has(o.id);
              return (
                <button key={o.id} disabled={blocked || !canEdit}
                  title={blocked ? "Эта запись уже ведёт к текущей — цепочка замкнулась бы" : undefined}
                  onClick={() => set("next", on ? form.next.filter((x) => x !== o.id) : [...form.next, o.id])}
                  style={{
                    background: on ? theme.accent : theme.surfaceAlt,
                    color: on ? theme.accentText : theme.text,
                    border: `1px solid ${theme.border}`,
                  }}
                  className="px-2.5 py-1 rounded-full text-[11.5px] flex items-center gap-1 disabled:opacity-40">
                  {on && <ArrowRight size={11} />} {o.title}
                </button>
              );
            })}
          </div>
        </Field>
      )}

      <Field label="Ссылки на задачи проектов" theme={theme}
        hint="Необязательно. Задача остаётся в своём проекте — диаграмма её не ведёт и сроки ей не меняет.">
        <div className="flex flex-wrap gap-1.5 mb-2">
          {form.tasks.length === 0 && (
            <span style={{ color: theme.textMuted }} className="text-[12px]">Ссылок нет</span>
          )}
          {form.tasks.map((id) => {
            const known = chosenTasks.find((t) => t.id === id)
              || (theItem?.tasks || []).find((t) => t.taskId === id);
            const label = known?.title || known?.taskId || "задача";
            return (
              <button key={id} disabled={!canEdit}
                onClick={() => set("tasks", form.tasks.filter((x) => x !== id))}
                style={{ background: theme.surfaceAlt, color: theme.text }}
                className="flex items-center gap-1 px-2 py-1 rounded-full text-[11.5px]"
                title="Убрать ссылку">
                {known?.visible === false ? "задача без доступа" : label} <X size={11} />
              </button>
            );
          })}
        </div>
        {canEdit && (
        <input value={taskSearch} onChange={(e) => setTaskSearch(e.target.value)}
          placeholder="Поиск задачи по названию"
          style={fieldStyle}
          className="w-full rounded-lg px-2.5 py-1.5 text-[12.5px] outline-none mb-1.5" />
        )}
        {canEdit && (
        <div className="flex gap-2">
          <select value={pickTask} onChange={(e) => setPickTask(e.target.value)}
            style={fieldStyle} className="flex-1 rounded-lg px-2 py-1.5 text-[12.5px] outline-none">
            <option value="">Выберите задачу…</option>
            {taskOptions === null && <option disabled>Загружаем…</option>}
            {taskOptions?.length === 0 && <option disabled>Задач не найдено</option>}
            {(taskOptions || []).filter((t) => !form.tasks.includes(t.id)).map((t) => (
              <option key={t.id} value={t.id}>{t.title}{t.boardTitle ? ` · ${t.boardTitle}` : ""}</option>
            ))}
          </select>
          <button onClick={() => {
            // Одна и та же задача не добавляется дважды: в списке
            // выбора она после этого пропадает, но нажать «Добавить»
            // со старым значением в поле было можно — и ссылка
            // появлялась второй раз.
            if (!pickTask || form.tasks.includes(pickTask)) { setPickTask(""); return; }
            set("tasks", [...form.tasks, pickTask]);
            setPickTask("");
          }}
            style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 text-[12.5px]">Добавить</button>
        </div>
        )}
      </Field>

      <div className="flex gap-2 mt-4">
        {onDelete && canEdit && (
          <button onClick={onDelete} style={{ color: theme.danger, border: `1px solid ${theme.border}` }}
            className="rounded-lg px-3 py-2.5 text-[13px] font-medium">Удалить</button>
        )}
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Закрыть</button>
        {canEdit && (
          <button onClick={submit} style={{ background: theme.accent, color: theme.accentText }}
            className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold">Сохранить</button>
        )}
      </div>
      </>
      )}
    </Modal>
  );
}

// Обсуждение этапа и файлы к нему.
//
// Устроено как у задач и по тем же причинам: договорённости по этапу
// должны лежать рядом с этапом, а не в переписке, где их потом никто
// не найдёт. Комментировать может любой участник диаграммы, включая
// исполнителя: разговор — не правка.
// История этапа. Устроена как история задачи: кто, когда и что
// изменил, новое сверху.
//
// Записи создаются сервером при самих изменениях, а не отдельной
// кнопкой: история, которую надо заполнять руками, не заполняется.
function ItemHistory({ theme, chartId, item, directory, onError }) {
  const [rows, setRows] = useState(null);

  const load = useCallback(async () => {
    try { setRows(await api.chartItemActivity(chartId, item.id)); }
    catch (e) { onError(e.message); setRows([]); }
  }, [chartId, item.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Правки приходят по тому же событию, что и список этапов: история
  // должна пополняться на глазах, а не после переоткрытия окна.
  useEffect(() => onRealtimeMessage("chartItems", () => { load(); }), [load]);
  useEffect(() => onRealtimeMessage("chartComment", (e) => {
    if (e.payload?.itemId === item.id) load();
  }), [item.id, load]);

  if (rows === null) {
    return <p style={{ color: theme.textMuted }} className="text-[12.5px]">Загружаем…</p>;
  }
  if (rows.length === 0) {
    return <p style={{ color: theme.textMuted }} className="text-[12.5px]">История пуста.</p>;
  }

  return (
    <div className="max-h-[46vh] overflow-y-auto">
      {rows.map((a) => {
        const u = a.actorId ? resolveUser(directory, a.actorId) : null;
        return (
          <div key={a.id} style={{ borderColor: theme.border }}
            className="flex items-start gap-2 py-2 border-b last:border-b-0">
            {u ? <Avatar user={u} size={22} theme={theme} />
              : <span style={{ background: theme.surfaceAlt }} className="w-[22px] h-[22px] rounded-full shrink-0" />}
            <div className="flex-1 min-w-0">
              <div style={{ color: theme.textMuted }} className="text-[11px]">
                {fmtDateTime(a.createdAt)}
                {u ? ` · ${u.fullName}` : ""}
              </div>
              <div style={{ color: theme.text }} className="text-[12.5px] leading-snug break-words">
                {a.body}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ItemTalk({ theme, chartId, item, directory, currentUser, onError }) {
  const [tab, setTab] = useState("comments");
  const [comments, setComments] = useState([]);
  const [files, setFiles] = useState([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const fileRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const d = await api.chartItemComments(chartId, item.id);
      setComments(d.comments || []);
      setFiles(d.files || []);
    } catch (e) { onError(e.message); }
  }, [chartId, item.id, onError]);

  useEffect(() => { load(); }, [load]);

  // Чужие замечания и файлы приходят событием: раньше окно этапа
  // показывало то, что было на момент открытия, и разговор двоих
  // превращался в переписку вслепую — каждый видел только себя, пока
  // не закроет и не откроет окно заново.
  useEffect(() => onRealtimeMessage("chartComment", (e) => {
    if (e.payload?.itemId !== item.id) return;
    load();
  }), [item.id, load]);

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    setText("");
    try { await api.addChartComment(chartId, item.id, body); load(); }
    catch (e) { onError(e.message); setText(body); }
  };

  const upload = async (file) => {
    if (!file) return;
    setBusy(true);
    try { await api.uploadChartFile(chartId, item.id, file); load(); }
    catch (e) { onError(e.message); }
    finally { setBusy(false); }
  };

  return (
    <div>
      {/* Две вкладки, как в задаче: разговор и файлы — разные вещи, и
          длинная переписка не должна прятать вложения в самый низ. */}
      <div className="flex gap-1 mb-2">
        {[["comments", `Обсуждение${comments.length ? ` · ${comments.length}` : ""}`],
          ["files", `Файлы${files.length ? ` · ${files.length}` : ""}`]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            style={{
              background: tab === id ? theme.accent : theme.surfaceAlt,
              color: tab === id ? theme.accentText : theme.text,
              border: `1px solid ${theme.border}`,
            }}
            className="px-2.5 py-1 rounded-lg text-[12px]">{label}</button>
        ))}
      </div>

      {tab === "comments" ? (
        <>
          <div className="max-h-[38vh] overflow-y-auto mb-3">
            {comments.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px]">
                Замечаний пока нет. Напишите первое — его увидят все участники диаграммы.
              </p>
            )}
            {comments.map((c) => {
              const u = resolveUser(directory, c.authorId);
              return (
                <div key={c.id} className="flex items-start gap-2 mb-2.5">
                  <Avatar user={u} size={24} theme={theme} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span style={{ color: theme.text }} className="text-[12px] font-medium">{u.fullName}</span>
                      <span style={{ color: theme.textMuted }} className="text-[11px]"
                        title={fmtDateTime(c.createdAt)}>{fmtRelative(c.createdAt)}</span>
                      {/* Удалять может только автор — его же замечание.
                          Признак приходит с сервера, а не считается
                          здесь: право решает политика, а не клиент. */}
                      {c.canEdit && (
                        <button onClick={async () => {
                          try { await api.deleteChartComment(chartId, item.id, c.id); load(); }
                          catch (e) { onError(e.message); }
                        }} style={{ color: theme.danger }} className="ml-auto" title="Удалить">
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                    <p style={{ color: theme.text }}
                      className="text-[13px] leading-snug whitespace-pre-wrap break-words">
                      {c.body}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-end gap-2">
            <textarea value={text} onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send(); }}
              rows={2} placeholder="Написать замечание. Ctrl+Enter — отправить"
              style={inputStyle(theme)}
              className="flex-1 rounded-lg px-3 py-2 text-[13px] outline-none resize-none" />
            <button onClick={send} style={{ background: theme.accent, color: theme.accentText }}
              className="rounded-lg p-2.5" title="Отправить"><Send size={15} /></button>
          </div>
        </>
      ) : (
        <>
          <div className="max-h-[38vh] overflow-y-auto mb-3">
            {files.length === 0 && (
              <p style={{ color: theme.textMuted }} className="text-[12.5px]">Файлов нет.</p>
            )}
            {files.map((f) => {
              const u = resolveUser(directory, f.authorId);
              return (
                <div key={f.id} style={{ borderColor: theme.border }}
                  className="flex items-center gap-2 py-2 border-b last:border-b-0">
                  <Paperclip size={14} style={{ color: theme.textMuted }} className="shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div style={{ color: theme.text }} className="text-[12.5px] font-medium truncate">
                      {f.filename}
                    </div>
                    <div style={{ color: theme.textMuted }} className="text-[11px] truncate">
                      {fmtSize(f.size)} · {u.fullName} · {fmtRelative(f.createdAt)}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {/* Предпросмотр в окне, а не в новой вкладке: она
                        уводит из диаграммы, а посмотреть вложение
                        обычно нужно не отрываясь от неё. */}
                    <button onClick={() => setPreview(f)} style={{ color: theme.textMuted }}
                      title="Посмотреть в окне"><ExternalLink size={14} /></button>
                    <button onClick={() => downloadFile(api.chartFileUrl(f.id, true), f.filename)}
                      style={{ color: theme.textMuted }} title="Скачать"><Download size={14} /></button>
                    {f.canEdit && (
                      <button onClick={async () => {
                        try { await api.deleteChartFile(chartId, item.id, f.id); load(); }
                        catch (e) { onError(e.message); }
                      }} style={{ color: theme.danger }} title="Удалить"><Trash2 size={13} /></button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <input ref={fileRef} type="file" className="hidden"
            onChange={(e) => { upload(e.target.files?.[0]); e.target.value = ""; }} />
          <button onClick={() => fileRef.current?.click()} disabled={busy}
            style={{ color: theme.accent, border: `1px dashed ${theme.border}` }}
            className="w-full flex items-center justify-center gap-1.5 text-[12.5px] font-medium rounded-lg py-2.5 disabled:opacity-50">
            <Upload size={14} /> {busy ? "Загружаем…" : "Загрузить файл"}
          </button>
        </>
      )}

      {preview && (
        <FilePreview theme={theme} title={preview.filename} filename={preview.filename}
          mime={preview.mime} path={api.chartFileUrl(preview.id)}
          pdfPath={api.chartFilePdfUrl(preview.id)}
          downloadPath={api.chartFileUrl(preview.id, true)}
          onClose={() => setPreview(null)} />
      )}
    </div>
  );
}

function SettingsModal({ theme, settings, canEdit, onClose, onSave }) {
  const [form, setForm] = useState(settings);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="chart-settings">
      <ModalHeader theme={theme} title="Вид диаграммы" onClose={onClose} />

      <Field label="Масштаб" theme={theme}>
        <div className="flex gap-1.5">
          {Object.entries(SCALES).map(([id, s]) => (
            <button key={id} onClick={() => set("scale", id)}
              style={{
                background: form.scale === id ? theme.accent : theme.surfaceAlt,
                color: form.scale === id ? theme.accentText : theme.text,
                border: `1px solid ${theme.border}`,
              }}
              className="px-3 py-1.5 rounded-lg text-[12.5px]">{s.label}</button>
          ))}
        </div>
      </Field>

      {[["showWeekends", "Выделять выходные"], ["showToday", "Линия сегодняшнего дня"],
        ["showLinks", "Показывать связи"]].map(([k, label]) => (
        <label key={k} className="flex items-center justify-between py-1.5 text-[13px]"
          style={{ color: theme.text }}>
          {label}
          <input type="checkbox" checked={Boolean(form[k])} onChange={(e) => set(k, e.target.checked)} />
        </label>
      ))}

      <Field label="Высота строки" theme={theme}>
        <input type="range" min="26" max="56" value={form.rowHeight}
          onChange={(e) => set("rowHeight", Number(e.target.value))} className="w-full" />
      </Field>

      <Field label="Цвет полос по умолчанию" theme={theme}
        hint="У записи может быть свой цвет — он важнее этого.">
        <div className="flex items-center gap-1.5 flex-wrap">
          {BAR_COLORS.map(([c, name]) => (
            <button key={c || "default"} onClick={() => set("barColor", c)} title={name}
              style={{
                background: c || theme.surfaceAlt,
                border: `1px solid ${theme.border}`,
                outline: (form.barColor || "") === c ? `2px solid ${theme.accent}` : "none",
                color: theme.text,
              }}
              className="h-7 min-w-[28px] px-2 rounded-lg text-[11px]">
              {c ? "" : "по умолчанию"}
            </button>
          ))}
        </div>
      </Field>

      <div className="flex gap-2 mt-4">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Закрыть</button>
        {canEdit && (
          <button onClick={() => onSave(form)} style={{ background: theme.accent, color: theme.accentText }}
            className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold">Сохранить</button>
        )}
      </div>
    </Modal>
  );
}

/* ------------------------------------------------ общие окна (и для досок) */

export function NameModal({ theme, title, initial = "", onClose, onSave }) {
  const [value, setValue] = useState(initial);
  return (
    <Modal theme={theme} onClose={onClose} width="max-w-sm" geometryKey="name-modal">
      <ModalHeader theme={theme} title={title} onClose={onClose} />
      <input value={value} onChange={(e) => setValue(e.target.value)} autoFocus
        onKeyDown={(e) => { if (e.key === "Enter" && value.trim()) onSave(value.trim()); }}
        style={inputStyle(theme)} className="w-full rounded-lg px-3 py-2 text-[13px] outline-none mb-4" />
      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={() => value.trim() && onSave(value.trim())} disabled={!value.trim()}
          style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold disabled:opacity-50">Сохранить</button>
      </div>
    </Modal>
  );
}

// Состав участников — те же роли, что в проектах: редактор правит,
// исполнитель смотрит. Владелец в списке не редактируется.
export function MembersModal({ theme, directory, team, members, isOwner, title, onClose, onSave }) {
  const [rows, setRows] = useState(
    () => members.filter((m) => m.role !== "owner").map((m) => ({ ...m })));

  const owner = members.find((m) => m.role === "owner");
  const candidates = (team || []).filter((id) => id !== owner?.userId);

  const roleOf = (id) => rows.find((r) => r.userId === id)?.role || "";
  const setRole = (id, role) => setRows((prev) => {
    const rest = prev.filter((r) => r.userId !== id);
    return role ? [...rest, { userId: id, role }] : rest;
  });

  return (
    <Modal theme={theme} onClose={onClose} width="max-w-md" geometryKey="members-modal">
      <ModalHeader theme={theme} title={title} onClose={onClose} />

      {owner && (
        <div className="flex items-center gap-2 mb-3">
          <Avatar user={resolveUser(directory, owner.userId)} size={24} theme={theme} />
          <span style={{ color: theme.text }} className="text-[13px]">
            {resolveUser(directory, owner.userId).fullName}
          </span>
          <span style={{ color: theme.textMuted }} className="text-[11.5px]">владелец</span>
        </div>
      )}

      {candidates.length === 0 && (
        <p style={{ color: theme.textMuted }} className="text-[12.5px] mb-3">
          В вашей команде пока никого нет — добавьте людей в команду, и они появятся здесь.
        </p>
      )}

      <div className="max-h-[46vh] overflow-y-auto mb-3">
        {candidates.map((id) => {
          const u = resolveUser(directory, id);
          const role = roleOf(id);
          return (
            <div key={id} className="flex items-center gap-2 py-1.5">
              <Avatar user={u} size={24} theme={theme} />
              <span style={{ color: theme.text }} className="text-[12.5px] flex-1 truncate">{u.fullName}</span>
              <div className="flex gap-1">
                {[["", "нет"], ["reader", "исполнитель"], ["editor", "редактор"]].map(([val, label]) => (
                  <button key={val || "none"} onClick={() => setRole(id, val)}
                    style={{
                      background: role === val ? theme.accent : theme.surfaceAlt,
                      color: role === val ? theme.accentText : theme.text,
                      border: `1px solid ${theme.border}`,
                    }}
                    className="px-2 py-1 rounded-lg text-[11px]">{label}</button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex gap-2">
        <button onClick={onClose}
          style={{ background: theme.surfaceAlt, color: theme.text, border: `1px solid ${theme.border}` }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-medium">Отмена</button>
        <button onClick={() => onSave(rows)} style={{ background: theme.accent, color: theme.accentText }}
          className="flex-1 rounded-lg py-2.5 text-[13px] font-semibold">Сохранить</button>
      </div>
    </Modal>
  );
}
