#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор набора значков для совместных досок.

Устройство: базовая форма (корпус, облако, документ, человек…) плюс
необязательная накладка-признак в углу (галочка, замок, молния…) плюс
необязательная анимация. Такой приём принят в иконочных наборах: он даёт
и единый стиль, и настоящее разнообразие смыслов — «сервер», «сервер
защищён», «сервер синхронизируется» — вместо перекрашенных копий.

Пишет frontend/src/lib/boardIcons.js.
"""
import sys

# ── палитра: основной, тёмный, светлый ───────────────────────────────
P = {
 "blue":("#3B82F6","#1D4ED8","#BFDBFE"), "sky":("#0EA5E9","#0369A1","#BAE6FD"),
 "cyan":("#06B6D4","#0E7490","#A5F3FC"), "teal":("#14B8A6","#0F766E","#99F6E4"),
 "green":("#22C55E","#15803D","#BBF7D0"), "lime":("#84CC16","#4D7C0F","#D9F99D"),
 "amber":("#F59E0B","#B45309","#FDE68A"), "orange":("#F97316","#C2410C","#FED7AA"),
 "red":("#EF4444","#B91C1C","#FECACA"), "rose":("#F43F5E","#BE123C","#FECDD3"),
 "pink":("#EC4899","#BE185D","#FBCFE8"), "purple":("#A855F7","#7E22CE","#E9D5FF"),
 "violet":("#8B5CF6","#6D28D9","#DDD6FE"), "indigo":("#6366F1","#4338CA","#C7D2FE"),
 "slate":("#64748B","#334155","#CBD5E1"), "stone":("#78716C","#44403C","#D6D3D1"),
 "brown":("#B45309","#78350F","#FDE68A"), "emerald":("#10B981","#047857","#A7F3D0"),
}
def m(c): return P.get(c, P["slate"])[0]
def d(c): return P.get(c, P["slate"])[1]
def l(c): return P.get(c, P["slate"])[2]

# ── примитивы ────────────────────────────────────────────────────────
def R(x,y,w,h,c,r=5,light=False,dark=False):
    f_=d(c) if dark else (l(c) if light else m(c))
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{f_}"/>'
def RD(x,y,w,h,c,r=5):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{d(c)}"/>'
def C(cx,cy,rr,c,light=False,dark=False):
    f_=d(c) if dark else (l(c) if light else m(c))
    return f'<circle cx="{cx}" cy="{cy}" r="{rr}" fill="{f_}"/>'
def CD(cx,cy,rr,c):
    return f'<circle cx="{cx}" cy="{cy}" r="{rr}" fill="{d(c)}"/>'
def O(cx,cy,rr,c,w=3.5,dark=False):
    return (f'<circle cx="{cx}" cy="{cy}" r="{rr}" fill="none" stroke="{d(c) if dark else m(c)}"'
            f' stroke-width="{w}"/>')
def E(cx,cy,rx,ry,c,light=False,dark=False):
    f = d(c) if dark else (l(c) if light else m(c))
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{f}"/>'
def PF(dd,c,dark=False,light=False):
    f = d(c) if dark else (l(c) if light else m(c))
    return f'<path d="{dd}" fill="{f}"/>'
def PS(dd,c,w=3.5,dark=False):
    return (f'<path d="{dd}" fill="none" stroke="{d(c) if dark else m(c)}" stroke-width="{w}"'
            f' stroke-linecap="round" stroke-linejoin="round"/>')
def W(dd,w=3):
    return f'<path d="{dd}" fill="none" stroke="#FFFFFF" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"/>'
def WF(dd): return f'<path d="{dd}" fill="#FFFFFF"/>'
def WR(x,y,w,h,r=2): return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="#FFFFFF"/>'
def WC(cx,cy,rr): return f'<circle cx="{cx}" cy="{cy}" r="{rr}" fill="#FFFFFF"/>'

# ── анимация ─────────────────────────────────────────────────────────
def A_op(dur="1.8s",begin="0s",lo="0.25"):
    return f'<animate attributeName="opacity" values="1;{lo};1" dur="{dur}" begin="{begin}" repeatCount="indefinite"/>'
def A_blink(dur="1.4s",begin="0s"):
    return f'<animate attributeName="opacity" values="0;1;0" dur="{dur}" begin="{begin}" repeatCount="indefinite"/>'
def A_scale(dur="2s",to="1.12"):
    return f'<animateTransform attributeName="transform" type="scale" additive="sum" values="1;{to};1" dur="{dur}" repeatCount="indefinite"/>'
def A_rot(cx,cy,dur="3s",rev=False):
    a,b=("360","0") if rev else ("0","360")
    return f'<animateTransform attributeName="transform" type="rotate" from="{a} {cx} {cy}" to="{b} {cx} {cy}" dur="{dur}" repeatCount="indefinite"/>'
def A_move(dx,dy,dur="2s"):
    return f'<animateTransform attributeName="transform" type="translate" additive="sum" values="0 0;{dx} {dy};0 0" dur="{dur}" repeatCount="indefinite"/>'
def A_dash(n=14,dur="1.1s"):
    return f'<animate attributeName="stroke-dashoffset" from="{n}" to="0" dur="{dur}" repeatCount="indefinite"/>'
def G(body,anim=""): return f'<g>{body}{anim}</g>'

def waves(cx,cy,c,anim,n=3,start=11,step=8,up=True):
    out=[]
    for i in range(n):
        r=start+i*step
        if up: dd=f"M {cx-r*0.72:.1f} {cy-r*0.58:.1f} A {r} {r} 0 0 1 {cx+r*0.72:.1f} {cy-r*0.58:.1f}"
        else:  dd=f"M {cx-r*0.72:.1f} {cy+r*0.58:.1f} A {r} {r} 0 0 0 {cx+r*0.72:.1f} {cy+r*0.58:.1f}"
        a=A_blink("1.9s",f"{i*0.32}s") if anim else ""
        op='0' if anim else '0.85'
        out.append(f'<path d="{dd}" fill="none" stroke="{m(c)}" stroke-width="3.4" stroke-linecap="round" opacity="{op}">{a}</path>')
    return "".join(out)

# ═══════════════════ базовые формы ═══════════════════════════════════
# Каждая: f(c, anim) -> svg-тело в координатах 0..64.
B = {}
def base(name):
    def deco(fn):
        B[name]=fn
        return fn
    return deco

# ── сеть и оборудование ─────────────────────────────────────────────
@base("router")
def _(c,a):
    body=E(32,42,24,9,c,dark=True)+R(8,24,48,18,c,0)+E(32,24,24,9,c,light=True)
    if a:
        return body+G(W("M 22 19 L 22 34 M 18 30 L 22 34 L 26 30",2.6),A_move(0,-3,"1.6s"))+\
               G(W("M 42 39 L 42 24 M 38 28 L 42 24 L 46 28",2.6),A_move(0,3,"1.6s"))
    return body+W("M 22 22 L 22 34 M 18 30 L 22 34 L 26 30",2.6)+W("M 42 36 L 42 24 M 38 28 L 42 24 L 46 28",2.6)

@base("switch")
def _(c,a):
    body=R(6,26,52,16,c,4)+f'<rect x="6" y="26" width="52" height="5" rx="2.5" fill="{l(c)}"/>'
    ports="".join(CD(13+i*8,38,2,c) for i in range(6))
    r1=W("M 18 34 L 27 34 M 24 31 L 27 34 L 24 37",2.2)
    r2=W("M 46 34 L 37 34 M 40 31 L 37 34 L 40 37",2.2)
    if a: return body+ports+f'<g opacity="0">{r1}{A_blink("1.4s")}</g><g opacity="0">{r2}{A_blink("1.4s","0.7s")}</g>'
    return body+ports+r1+r2

@base("hub")
def _(c,a):
    spokes="".join(PS(f"M 32 32 L {32+22*x} {32+22*y}",c,3,dark=True) for x,y in
        ((0,-1),(0,1),(-1,0),(1,0),(0.7,0.7),(-0.7,0.7),(0.7,-0.7),(-0.7,-0.7)))
    nodes="".join(C(32+22*x,32+22*y,4,c) for x,y in ((0,-1),(0,1),(-1,0),(1,0)))
    core=C(32,32,9,c)
    if a: return spokes+nodes+G(core,A_scale("2s","1.15"))
    return spokes+nodes+core

@base("firewall")
def _(c,a):
    rows=[]
    for i,y in enumerate((14,24,34)):
        off=0 if i%2==0 else 8
        for x in range(6-off,58,16):
            rows.append(f'<rect x="{x}" y="{y}" width="14" height="8" rx="2" fill="{m(c) if i%2==0 else d(c)}"/>')
    fl=PF("M 32 58 C 23 49 28 45 32 40 C 36 45 41 49 32 58","orange")
    return "".join(rows)+(G(fl,A_scale("1.2s","1.2")) if a else fl)

@base("cloud")
def _(c,a):
    dd="M 20 46 A 11 11 0 0 1 21 25 A 14 14 0 0 1 46 27 A 10 10 0 0 1 45 46 Z"
    body=PF(dd,c)+f'<path d="{dd}" fill="{l(c)}" opacity="0.3"/>'
    return G(body,A_move(0,-2,"2.8s")) if a else body

@base("ap")
def _(c,a):
    return waves(32,42,c,a,3,11,8)+R(24,42,16,12,c,3)+CD(32,48,2.5,c)

@base("antenna")
def _(c,a):
    return waves(32,28,c,a,3,10,8)+PS("M 32 52 L 32 26",c,3.5,dark=True)+\
           PS("M 24 56 L 40 56",c,3.5,dark=True)+C(32,24,4,c)

@base("tower")
def _(c,a):
    mast=PF("M 28 56 L 30 18 L 34 18 L 36 56 Z",c,dark=True)
    cross=PS("M 24 38 L 40 38 M 26 46 L 38 46",c,2.6)
    return waves(32,20,c,a,2,12,9)+mast+cross+C(32,14,4,c)

@base("satellite")
def _(c,a):
    body=R(26,26,12,12,c,3)+R(4,28,18,8,c,2,light=True)+R(42,28,18,8,c,2,light=True)+\
         PS("M 22 32 L 26 32 M 38 32 L 42 32",c,2.6,dark=True)
    sig=waves(32,22,c,a,2,10,8)
    return body+sig

@base("modem")
def _(c,a):
    body=R(8,34,48,16,c,4)+f'<rect x="8" y="34" width="48" height="5" rx="2.5" fill="{l(c)}"/>'
    leds="".join((f'<circle cx="{16+i*7}" cy="{44}" r="2" fill="{d(c)}">{A_blink("1.2s",f"{i*0.3}s")}</circle>'
                  if a else CD(16+i*7,44,2,c)) for i in range(3))
    return body+leds+PS("M 40 30 A 12 12 0 0 1 54 20",c,2.6)

@base("server")
def _(c,a):
    body=R(16,8,32,48,c,5)
    out=[body]
    for i,y in enumerate((14,26,38)):
        out.append(f'<rect x="21" y="{y}" width="22" height="9" rx="2" fill="{l(c)}"/>')
        out.append(f'<circle cx="39" cy="{y+4.5}" r="2" fill="{d(c)}">{A_blink(f"{1.1+i*0.3}s") if a else ""}</circle>')
    return "".join(out)

@base("rack")
def _(c,a):
    out=[R(10,6,44,52,c,5)]
    for i,y in enumerate((12,22,32,42)):
        out.append(f'<rect x="15" y="{y}" width="34" height="7" rx="2" fill="{l(c)}"/>')
        out.append(f'<circle cx="44" cy="{y+3.5}" r="1.8" fill="{d(c)}">{A_blink(f"{1+i*0.25}s") if a else ""}</circle>')
    return "".join(out)

@base("db")
def _(c,a):
    body=E(32,16,18,7,c,light=True)+PF("M 14 16 V 48 A 18 7 0 0 0 50 48 V 16 Z",c)+\
         E(32,16,18,7,c,light=True)
    rings=PS("M 14 30 A 18 7 0 0 0 50 30",c,2.4,dark=True)+PS("M 14 39 A 18 7 0 0 0 50 39",c,2.4,dark=True)
    if a:
        return body+rings+G(WC(32,16,3),A_op("1.6s"))
    return body+rings

@base("nas")
def _(c,a):
    out=[R(14,10,36,44,c,5)]
    for i in range(3):
        y=16+i*13
        out.append(f'<rect x="19" y="{y}" width="26" height="10" rx="2" fill="{l(c)}"/>')
        out.append(f'<circle cx="40" cy="{y+5}" r="2" fill="{d(c)}">{A_blink(f"{1.2+i*0.2}s") if a else ""}</circle>')
    return "".join(out)

@base("pc")
def _(c,a):
    scr=R(6,12,44,30,c,4)+f'<rect x="10" y="16" width="36" height="22" rx="2" fill="{l(c)}"/>'
    stand=PF("M 22 42 L 20 52 H 36 L 34 42 Z",c,dark=True)+RD(14,52,28,4,c,2)
    if a: return scr+G(WR(14,20,12,3),A_op("1.5s"))+G(WR(14,27,20,3),A_op("1.5s","0.4s"))+stand
    return scr+WR(14,20,12,3)+WR(14,27,20,3)+stand

@base("laptop")
def _(c,a):
    lid=R(12,14,40,26,c,3)+f'<rect x="16" y="18" width="32" height="18" rx="2" fill="{l(c)}"/>'
    base_=PF("M 6 48 H 58 L 54 40 H 10 Z",c,dark=True)
    return lid+base_

@base("phone")
def _(c,a):
    body=R(20,6,24,52,c,6)+f'<rect x="24" y="12" width="16" height="36" rx="2" fill="{l(c)}"/>'
    if a: return body+G(WR(27,18,10,2.5),A_op("1.6s"))+WC(32,52,2.5)
    return body+WR(27,18,10,2.5)+WC(32,52,2.5)

@base("tablet")
def _(c,a):
    return R(14,8,36,48,c,5)+f'<rect x="18" y="13" width="28" height="34" rx="2" fill="{l(c)}"/>'+WC(32,51,2.5)

@base("printer")
def _(c,a):
    top=R(18,8,28,12,c,2,light=True)
    body=R(8,20,48,22,c,4)
    paper=R(18,38,28,18,c,2,light=True)
    if a: return top+body+G(paper,A_move(0,3,"2.2s"))+CD(46,30,2.5,c)
    return top+body+paper+CD(46,30,2.5,c)

@base("cpu")
def _(c,a):
    pins="".join(PS(f"M {16+i*8} 8 L {16+i*8} 14",c,3,dark=True)+PS(f"M {16+i*8} 50 L {16+i*8} 56",c,3,dark=True)
                 for i in range(5))
    pins+="".join(PS(f"M 8 {16+i*8} L 14 {16+i*8}",c,3,dark=True)+PS(f"M 50 {16+i*8} L 56 {16+i*8}",c,3,dark=True)
                  for i in range(5))
    body=R(14,14,36,36,c,4)+f'<rect x="22" y="22" width="20" height="20" rx="3" fill="{l(c)}"/>'
    return pins+body+(G(WC(32,32,4),A_op("1.3s")) if a else "")

@base("chip")
def _(c,a):
    body=R(12,12,40,40,c,6)+f'<rect x="20" y="20" width="24" height="24" rx="3" fill="{l(c)}"/>'
    t="".join(PS(f"M {20+i*12} 4 L {20+i*12} 12",c,2.6,dark=True) for i in range(3))
    return body+t+(G(WC(32,32,3),A_blink("1.2s")) if a else WC(32,32,3))

@base("hdd")
def _(c,a):
    body=R(8,18,48,28,c,4)
    disc=C(30,32,10,c,light=True)+CD(30,32,3,c)
    arm=PS("M 44 22 L 34 30",c,3,dark=True)
    if a: return body+disc+G(arm,A_rot(44,22,"3s"))
    return body+disc+arm

@base("ram")
def _(c,a):
    body=R(6,22,52,20,c,3)
    chips="".join(f'<rect x="{12+i*11}" y="26" width="8" height="12" rx="1.5" fill="{l(c)}"/>' for i in range(4))
    teeth="".join(f'<rect x="{10+i*6}" y="42" width="4" height="4" fill="{d(c)}"/>' for i in range(8))
    return body+chips+teeth

@base("monitor")
def _(c,a):
    return B["pc"](c,a)

@base("cable")
def _(c,a):
    dd="M 8 44 C 20 44 20 20 32 20 C 44 20 44 44 56 44"
    p=(f'<path d="{dd}" fill="none" stroke="{m(c)}" stroke-width="5" stroke-linecap="round"'
       f' stroke-dasharray="8 6">{A_dash(14) if a else ""}</path>')
    return p+C(8,44,5,c,light=True)+C(56,44,5,c,light=True)

@base("port")
def _(c,a):
    return R(10,20,44,24,c,4)+f'<rect x="18" y="26" width="28" height="12" rx="2" fill="{l(c)}"/>'+\
           "".join(CD(23+i*6,32,1.8,c) for i in range(4))

@base("lan")
def _(c,a):
    box_=R(18,26,28,20,c,3)+f'<rect x="22" y="30" width="20" height="8" rx="1.5" fill="{l(c)}"/>'
    wire=PS("M 32 26 L 32 12 M 20 12 H 44",c,3,dark=True)
    dots="".join(C(20+i*12,12,3,c) for i in range(3))
    return wire+dots+box_

@base("vpn")
def _(c,a):
    tun=PF("M 10 40 A 22 22 0 0 1 54 40 L 54 50 L 10 50 Z",c,light=True)
    lock=R(26,30,12,14,c,3)+PS("M 29 30 V 26 A 3 3 0 0 1 35 26 V 30",c,2.6,dark=True)
    return tun+(G(lock,A_scale("2s","1.08")) if a else lock)

@base("proxy")
def _(c,a):
    l_=C(12,32,7,c)
    r_=C(52,32,7,c)
    mid=R(24,22,16,20,c,4)
    ar=PS("M 19 32 H 24 M 40 32 H 45",c,3,dark=True)
    if a: return l_+r_+ar+G(mid,A_op("1.8s"))
    return l_+r_+ar+mid

@base("balancer")
def _(c,a):
    src=C(10,32,6,c)
    outs="".join(C(54,16+i*16,5,c,light=True) for i in range(3))
    lines="".join(PS(f"M 16 32 C 34 32 34 {16+i*16} 49 {16+i*16}",c,2.6,dark=True) for i in range(3))
    return lines+src+outs

# ── данные и аналитика ──────────────────────────────────────────────
@base("chart-bar")
def _(c,a):
    bars=[]
    for i,(x,h) in enumerate(((12,18),(25,30),(38,24),(49,36))):
        y=52-h
        b=f'<rect x="{x}" y="{y}" width="9" height="{h}" rx="2" fill="{m(c) if i%2==0 else d(c)}"/>'
        bars.append(G(b,f'<animate attributeName="height" values="{h};{h*0.5:.0f};{h}" dur="{1.6+i*0.2}s" repeatCount="indefinite"/><animate attributeName="y" values="{y};{y+h*0.5:.0f};{y}" dur="{1.6+i*0.2}s" repeatCount="indefinite"/>') if a else b)
    return PS("M 8 56 H 58",c,3,dark=True)+"".join(bars)

@base("chart-line")
def _(c,a):
    dd="M 10 46 L 22 32 L 34 38 L 46 18 L 56 26"
    p=(f'<path d="{dd}" fill="none" stroke="{m(c)}" stroke-width="4" stroke-linecap="round"'
       f' stroke-linejoin="round" stroke-dasharray="90" >{A_dash(90,"2.4s") if a else ""}</path>')
    dots="".join(C(x,y,3.2,c,light=True) for x,y in ((22,32),(34,38),(46,18)))
    return PS("M 8 56 H 58 M 8 56 V 12",c,3,dark=True)+p+dots

@base("chart-pie")
def _(c,a):
    whole=C(32,32,22,c,light=True)
    seg=PF("M 32 32 L 32 10 A 22 22 0 0 1 51 43 Z",c)
    return whole+(G(seg,A_rot(32,32,"6s")) if a else seg)+CD(32,32,4,c)

@base("chart-area")
def _(c,a):
    area=PF("M 10 48 L 22 30 L 34 38 L 46 20 L 56 28 V 48 Z",c,light=True)
    line=PS("M 10 48 L 22 30 L 34 38 L 46 20 L 56 28",c,3.4)
    return PS("M 8 54 H 58",c,3,dark=True)+area+line

@base("chart-donut")
def _(c,a):
    r=O(32,32,18,c,9)
    arc=(f'<path d="M 32 14 A 18 18 0 0 1 50 32" fill="none" stroke="{d(c)}" stroke-width="9"'
         f' stroke-linecap="round"/>')
    return r+(G(arc,A_rot(32,32,"4s")) if a else arc)

@base("gauge")
def _(c,a):
    arc=f'<path d="M 12 44 A 20 20 0 0 1 52 44" fill="none" stroke="{l(c)}" stroke-width="8" stroke-linecap="round"/>'
    fill=f'<path d="M 12 44 A 20 20 0 0 1 32 24" fill="none" stroke="{m(c)}" stroke-width="8" stroke-linecap="round"/>'
    needle=PS("M 32 44 L 42 30",c,3.4,dark=True)
    return arc+fill+(G(needle,A_rot(32,44,"2.4s")) if a else needle)+CD(32,44,4,c)

@base("table")
def _(c,a):
    body=R(8,12,48,40,c,4,light=True)
    head=PF("M 8 16 A 4 4 0 0 1 12 12 H 52 A 4 4 0 0 1 56 16 V 24 H 8 Z",c)
    lines=PS("M 8 34 H 56 M 8 43 H 56 M 24 24 V 52 M 40 24 V 52",c,2,dark=True)
    return body+head+lines

@base("sheet")
def _(c,a):
    return B["table"](c,a)

@base("report")
def _(c,a):
    doc=PF("M 14 6 H 38 L 50 18 V 58 H 14 Z",c,light=True)+PF("M 38 6 V 18 H 50 Z",c)
    bars=PS("M 22 44 V 34 M 30 44 V 28 M 38 44 V 38",c,3.4)
    return doc+bars+PS("M 20 24 H 32",c,2.4,dark=True)

@base("filter")
def _(c,a):
    f=PF("M 10 12 H 54 L 38 32 V 52 L 26 46 V 32 Z",c)
    return f+(G(C(44,44,7,c,light=True)+WF("M 41 44 h 6 M 44 41 v 6"),A_op("1.8s")) if a else "")

@base("search")
def _(c,a):
    o=O(28,28,15,c,5)
    h=PS("M 39 39 L 54 54",c,5,dark=True)
    return (G(o,A_move(3,3,"2s")) if a else o)+h

@base("dataflow")
def _(c,a):
    n1=R(6,10,18,14,c,3); n2=R(40,10,18,14,c,3,light=True)
    n3=R(6,40,18,14,c,3,light=True); n4=R(40,40,18,14,c,3)
    arr=PS("M 24 17 H 40 M 15 24 V 40 M 49 24 V 40 M 24 47 H 40",c,2.6,dark=True)
    return arr+n1+n2+n3+n4

# ── безопасность ────────────────────────────────────────────────────
@base("shield")
def _(c,a):
    sh=PF("M 32 6 L 54 14 V 32 C 54 45 44 54 32 58 C 20 54 10 45 10 32 V 14 Z",c)
    ch=W("M 23 32 L 30 39 L 43 25",4)
    return sh+(G(ch,A_op("1.8s")) if a else ch)

@base("lock")
def _(c,a):
    body=R(14,28,36,26,c,5)
    arc=PS("M 22 28 V 20 A 10 10 0 0 1 42 20 V 28",c,4,dark=True)
    return arc+body+WC(32,40,4)+WR(30.5,42,3,7,1.5)

@base("unlock")
def _(c,a):
    body=R(14,28,36,26,c,5)
    arc=PS("M 22 28 V 20 A 10 10 0 0 1 42 20",c,4,dark=True)
    return arc+body+WC(32,40,4)

@base("key")
def _(c,a):
    o=O(20,24,10,c,5)
    st=PS("M 27 31 L 48 52 M 42 46 L 48 40 M 48 52 L 54 46",c,4.5,dark=True)
    return (G(o,A_rot(20,24,"4s")) if a else o)+st

@base("fingerprint")
def _(c,a):
    arcs=[]
    for i,r in enumerate((8,14,20)):
        arcs.append(f'<path d="M {32-r*0.7:.0f} {32+r*0.7:.0f} A {r} {r} 0 1 1 {32+r*0.7:.0f} {32+r*0.7:.0f}"'
                    f' fill="none" stroke="{m(c) if i%2==0 else d(c)}" stroke-width="3.2" stroke-linecap="round"'
                    f' opacity="{"0" if a else "1"}">{A_blink("2s",f"{i*0.3}s") if a else ""}</path>')
    return "".join(arcs)+C(32,34,3,c,light=True)

@base("bug")
def _(c,a):
    body=E(32,36,14,16,c)
    legs=PS("M 18 28 L 8 22 M 18 38 L 6 38 M 18 46 L 8 52 M 46 28 L 56 22 M 46 38 L 58 38 M 46 46 L 56 52",c,2.8,dark=True)
    head=C(32,18,8,c,light=True)+CD(28,17,1.8,c)+CD(36,17,1.8,c)
    if a: return G(legs,A_op("0.8s"))+body+head
    return legs+body+head

@base("virus")
def _(c,a):
    core=C(32,32,14,c)
    spikes="".join(PS(f"M {32+14*x:.1f} {32+14*y:.1f} L {32+21*x:.1f} {32+21*y:.1f}",c,3,dark=True)+
                   C(32+23*x,32+23*y,3,c,light=True)
                   for x,y in ((0,-1),(0,1),(-1,0),(1,0),(0.7,0.7),(-0.7,0.7),(0.7,-0.7),(-0.7,-0.7)))
    g=core+spikes
    return G(g,A_rot(32,32,"8s")) if a else g

@base("eye")
def _(c,a):
    e=PF("M 4 32 C 14 18 50 18 60 32 C 50 46 14 46 4 32 Z",c,light=True)
    ir=C(32,32,9,c)+CD(32,32,4,c)
    return e+(G(ir,A_move(4,0,"3s")) if a else ir)

# ── люди и общение ──────────────────────────────────────────────────
@base("user")
def _(c,a):
    return C(32,22,11,c)+PF("M 10 56 A 22 22 0 0 1 54 56 Z",c,light=True)

@base("users")
def _(c,a):
    return C(22,22,9,c)+PF("M 4 52 A 18 18 0 0 1 40 52 Z",c,light=True)+\
           C(44,24,8,c,light=True)+PF("M 30 52 A 15 15 0 0 1 60 52 Z",c)

@base("team")
def _(c,a):
    return B["users"](c,a)

@base("chat")
def _(c,a):
    b=PF("M 8 12 H 56 V 42 H 26 L 14 52 V 42 H 8 Z",c)
    dots="".join((f'<circle cx="{22+i*10}" cy="27" r="3" fill="#FFFFFF">{A_blink("1.2s",f"{i*0.25}s")}</circle>'
                  if a else WC(22+i*10,27,3)) for i in range(3))
    return b+dots

@base("mail")
def _(c,a):
    env=R(6,16,52,34,c,4)
    flap=PS("M 8 20 L 32 38 L 56 20",c,3.4,dark=True)
    return env+flap

@base("bell")
def _(c,a):
    b=PF("M 32 8 A 14 14 0 0 1 46 22 V 38 L 52 46 H 12 L 18 38 V 22 A 14 14 0 0 1 32 8 Z",c)
    cl=C(32,52,5,c,light=True)
    if a: return G(b,f'<animateTransform attributeName="transform" type="rotate" values="-8 32 12;8 32 12;-8 32 12" dur="0.9s" repeatCount="indefinite"/>')+cl
    return b+cl

@base("call")
def _(c,a):
    h=PF("M 14 8 L 24 8 L 28 22 L 22 26 C 24 34 30 40 38 42 L 42 36 L 56 40 L 56 50 C 40 54 10 34 14 8 Z",c)
    return G(h,A_scale("1.4s","1.1")) if a else h

@base("video")
def _(c,a):
    body=R(6,18,34,28,c,4)
    lens=PF("M 44 26 L 58 18 V 46 L 44 38 Z",c,dark=True)
    return body+lens+(G(WC(20,32,5),A_op("1.6s")) if a else WC(20,32,5))

@base("mic")
def _(c,a):
    cap=R(25,8,14,26,c,7)
    arc=PS("M 18 30 A 14 14 0 0 0 46 30",c,3.4,dark=True)
    st=PS("M 32 44 V 54 M 24 56 H 40",c,3.4,dark=True)
    return cap+arc+st+(waves(32,14,c,True,2,9,7) if a else "")

@base("hand")
def _(c,a):
    p=PF("M 22 54 V 30 A 4 4 0 0 1 30 30 V 16 A 4 4 0 0 1 38 16 V 32 L 46 34 A 6 6 0 0 1 50 40 V 50 A 8 8 0 0 1 42 58 H 30 A 8 8 0 0 1 22 54 Z",c)
    return G(p,A_move(0,-3,"1.8s")) if a else p

# ── документы ───────────────────────────────────────────────────────
@base("doc")
def _(c,a):
    return PF("M 14 6 H 38 L 50 18 V 58 H 14 Z",c,light=True)+PF("M 38 6 V 18 H 50 Z",c)+\
           PS("M 22 28 H 42 M 22 36 H 42 M 22 44 H 34",c,2.6)

@base("docs")
def _(c,a):
    back=PF("M 20 4 H 40 L 50 14 V 50 H 20 Z",c,light=True)
    front=PF("M 12 12 H 34 L 44 22 V 58 H 12 Z",c)
    return back+front+W("M 20 34 H 36 M 20 42 H 36 M 20 50 H 30",2.6)

@base("folder")
def _(c,a):
    tab=PF("M 6 14 H 26 L 30 20 H 6 Z",c,dark=True)
    body=PF("M 6 18 H 58 V 52 A 4 4 0 0 1 54 56 H 10 A 4 4 0 0 1 6 52 Z",c)
    return tab+body

@base("folder-open")
def _(c,a):
    back=PF("M 6 16 H 26 L 30 22 H 54 V 32 H 6 Z",c,dark=True)
    front=PF("M 6 30 H 58 L 52 56 H 12 Z",c)
    return back+(G(front,A_move(0,-2,"2.2s")) if a else front)

@base("archive")
def _(c,a):
    lid=R(6,12,52,12,c,3,light=True)
    body=R(10,24,44,32,c,3)
    return lid+body+WR(26,32,12,4,2)

@base("clipboard")
def _(c,a):
    body=R(12,10,40,48,c,5,light=True)
    clip=R(24,4,16,10,c,3)
    lines=PS("M 20 28 H 44 M 20 38 H 44 M 20 48 H 36",c,2.6)
    return body+clip+lines

@base("note")
def _(c,a):
    body=PF("M 8 8 H 56 V 44 L 44 56 H 8 Z",c)
    fold=PF("M 44 56 V 44 H 56 Z",c,dark=True)
    return body+fold+W("M 18 22 H 44 M 18 32 H 38",2.8)

@base("book")
def _(c,a):
    left=PF("M 8 12 C 18 8 26 10 32 14 V 54 C 26 50 18 48 8 52 Z",c)
    right=PF("M 56 12 C 46 8 38 10 32 14 V 54 C 38 50 46 48 56 52 Z",c,light=True)
    return left+right+PS("M 32 14 V 54",c,2.6,dark=True)

@base("calendar")
def _(c,a):
    body=R(8,14,48,44,c,5,light=True)
    head=PF("M 8 20 A 6 6 0 0 1 14 14 H 50 A 6 6 0 0 1 56 20 V 26 H 8 Z",c)
    pins=PS("M 20 8 V 18 M 44 8 V 18",c,3.4,dark=True)
    cells="".join(f'<rect x="{16+j*12}" y="{34+i*10}" width="8" height="7" rx="1.5" fill="{m(c)}" opacity="0.6"/>'
                  for i in range(2) for j in range(3))
    return pins+body+head+cells

@base("clock")
def _(c,a):
    face=C(32,32,24,c,light=True)+O(32,32,24,c,4)
    h=PS("M 32 32 V 18",c,3.4,dark=True)
    mi=PS("M 32 32 L 43 38",c,3,dark=True)
    if a:
        return face+G(h,A_rot(32,32,"12s"))+G(mi,A_rot(32,32,"3s"))+CD(32,32,3,c)
    return face+h+mi+CD(32,32,3,c)

@base("hourglass")
def _(c,a):
    body=PF("M 16 8 H 48 L 34 32 L 48 56 H 16 L 30 32 Z",c,light=True)
    sand=PF("M 20 12 H 44 L 33 30 H 31 Z",c)
    if a: return body+G(sand,A_op("2.4s"))+PS("M 14 8 H 50 M 14 56 H 50",c,3.4,dark=True)
    return body+sand+PS("M 14 8 H 50 M 14 56 H 50",c,3.4,dark=True)

@base("timer")
def _(c,a):
    face=C(32,36,20,c,light=True)+O(32,36,20,c,4)
    top=PS("M 26 12 H 38 M 32 12 V 16",c,3.4,dark=True)
    h=PS("M 32 36 V 24",c,3.4,dark=True)
    return top+face+(G(h,A_rot(32,36,"2s")) if a else h)+CD(32,36,3,c)

# ── бизнес ──────────────────────────────────────────────────────────
@base("briefcase")
def _(c,a):
    handle=PS("M 24 16 V 12 A 4 4 0 0 1 40 12 V 16",c,3.4,dark=True)
    body=R(6,16,52,34,c,5)
    lock=WR(28,30,8,6,2)
    return handle+body+lock

@base("building")
def _(c,a):
    body=R(12,10,40,48,c,4)
    win="".join(f'<rect x="{18+j*11}" y="{18+i*11}" width="8" height="8" rx="1.5" fill="{l(c)}"/>'
                for i in range(3) for j in range(3))
    return body+win

@base("factory")
def _(c,a):
    smoke=""
    if a:
        smoke="".join(f'<circle cx="{20+i*2}" cy="{14-i*4}" r="{4-i*0.6:.1f}" fill="{l(c)}" opacity="0">'
                      f'{A_blink("2.2s",f"{i*0.4}s")}</circle>' for i in range(3))
    stack=R(14,18,8,16,c,2,light=True)
    body=PF("M 6 34 L 22 34 L 22 24 L 36 34 L 36 24 L 50 34 V 56 H 6 Z",c)
    return smoke+stack+body+"".join(WR(14+i*12,44,8,8,1.5) for i in range(3))

@base("bank")
def _(c,a):
    roof=PF("M 32 8 L 58 22 H 6 Z",c)
    cols="".join(R(14+i*11,26,7,24,c,2,light=True) for i in range(4))
    base_=RD(8,50,48,6,c,2)
    return roof+cols+base_

@base("cart")
def _(c,a):
    body=PF("M 8 12 H 16 L 22 38 H 52 L 58 18 H 20",c,light=True)
    st=PS("M 8 12 H 16 L 22 38 H 52 L 58 18 H 20",c,3.4)
    wh=C(24,50,5,c)+C(46,50,5,c)
    if a: return st+G(wh,A_move(3,0,"2s"))
    return st+wh

@base("money")
def _(c,a):
    bill=R(6,18,52,30,c,4)
    circle=C(32,33,10,c,light=True)
    return bill+circle+PS("M 32 26 V 40 M 28 30 H 36 M 28 36 H 36",c,2.6,dark=True)

@base("card")
def _(c,a):
    body=R(6,16,52,32,c,5)
    strip=RD(6,24,52,7,c,0)
    chip=R(14,36,10,7,c,2,light=True)
    return body+strip+chip

@base("box")
def _(c,a):
    top=PF("M 32 8 L 56 18 L 32 28 L 8 18 Z",c,light=True)
    left=PF("M 8 18 L 32 28 V 56 L 8 44 Z",c)
    right=PF("M 56 18 L 32 28 V 56 L 56 44 Z",c,dark=True)
    g=top+left+right
    return G(g,A_move(0,-3,"2.4s")) if a else g

@base("truck")
def _(c,a):
    body=R(4,22,32,22,c,3)
    cab=PF("M 36 28 H 48 L 58 36 V 44 H 36 Z",c,dark=True)
    wh=C(16,48,6,c,light=True)+C(48,48,6,c,light=True)
    if a: return body+cab+G(wh,A_rot(16,48,"1.6s"))
    return body+cab+wh

@base("plane")
def _(c,a):
    p=PF("M 32 4 L 38 26 L 60 34 V 40 L 38 36 L 36 50 L 44 56 V 60 L 32 56 L 20 60 V 56 L 28 50 L 26 36 L 4 40 V 34 L 26 26 Z",c)
    return G(p,A_move(0,-3,"2.6s")) if a else p

@base("ship")
def _(c,a):
    hull=PF("M 6 40 H 58 L 50 54 H 14 Z",c)
    cab=R(24,22,16,18,c,light=True)
    mast=PS("M 32 22 V 12",c,3,dark=True)
    if a: return G(hull+cab+mast,A_move(0,2,"2.6s"))
    return hull+cab+mast

@base("train")
def _(c,a):
    body=R(10,12,44,34,c,5)
    win=R(16,18,32,12,c,2,light=True)
    wh=C(20,50,5,c,light=True)+C(44,50,5,c,light=True)
    return body+win+wh

@base("car")
def _(c,a):
    body=PF("M 6 42 L 10 30 H 18 L 24 20 H 40 L 48 30 H 56 L 58 42 Z",c)
    win=PF("M 24 24 H 38 L 43 30 H 22 Z",c,light=True)
    wh=C(18,46,6,c,dark=True)+C(46,46,6,c,dark=True)
    return body+win+wh

# ── инструменты ─────────────────────────────────────────────────────
@base("gear")
def _(c,a):
    teeth="".join(f'<rect x="29" y="4" width="6" height="12" rx="2" fill="{m(c)}"'
                  f' transform="rotate({i*45} 32 32)"/>' for i in range(8))
    ring_=O(32,32,16,c,8)
    g=teeth+ring_
    return G(g,A_rot(32,32,"6s")) if a else g

@base("wrench")
def _(c,a):
    p=PF("M 44 8 A 12 12 0 1 0 54 26 L 30 50 A 7 7 0 1 0 38 58 L 62 34 A 12 12 0 0 0 44 8 Z",c)
    return G(p,f'<animateTransform attributeName="transform" type="rotate" values="-10 32 32;10 32 32;-10 32 32" dur="1.6s" repeatCount="indefinite"/>') if a else p

@base("hammer")
def _(c,a):
    head=PF("M 10 14 L 34 8 L 38 20 L 14 26 Z",c)
    handle=PS("M 22 24 L 50 54",c,5,dark=True)
    return handle+head

@base("tools")
def _(c,a):
    w=PF("M 12 8 L 20 8 L 20 26 A 6 6 0 0 1 12 26 Z",c)
    sd=PS("M 44 10 L 52 18 L 30 44 L 22 36 Z",c,3)
    return w+sd+PS("M 16 30 V 56",c,4,dark=True)

@base("brush")
def _(c,a):
    handle=PS("M 44 10 L 56 22",c,5,dark=True)
    head=PF("M 38 16 L 48 26 L 26 48 L 16 38 Z",c)
    tip=PF("M 16 38 L 26 48 L 10 56 Z",c,light=True)
    return handle+head+tip

@base("palette")
def _(c,a):
    p=PF("M 32 8 A 24 24 0 1 0 32 56 A 6 6 0 0 0 32 44 A 6 6 0 0 1 32 32 H 48 A 8 8 0 0 0 56 24 A 20 20 0 0 0 32 8 Z",c,light=True)
    dots=C(22,22,4,"red")+C(36,18,4,"blue")+C(20,36,4,"green")+C(44,26,4,"amber")
    return p+dots

@base("ruler")
def _(c,a):
    body=f'<rect x="6" y="24" width="52" height="16" rx="3" fill="{m(c)}" transform="rotate(-20 32 32)"/>'
    ticks="".join(f'<rect x="{12+i*9}" y="24" width="2.5" height="7" fill="#FFFFFF" transform="rotate(-20 32 32)"/>' for i in range(5))
    return body+ticks

@base("bulb")
def _(c,a):
    g_=C(32,26,16,c,light=True)
    rays="".join(PS(f"M {32+20*x:.1f} {26+20*y:.1f} L {32+26*x:.1f} {26+26*y:.1f}",c,3)
                 for x,y in ((0,-1),(-0.7,-0.7),(0.7,-0.7),(-1,0),(1,0)))
    base_=RD(26,42,12,10,c,2)+PS("M 27 54 H 37",c,2.6,dark=True)
    if a: return G(rays,A_blink("1.6s"))+g_+base_
    return rays+g_+base_

@base("rocket")
def _(c,a):
    body=PF("M 32 4 C 42 14 44 30 42 44 H 22 C 20 30 22 14 32 4 Z",c)
    win=C(32,22,6,c,light=True)
    fins=PF("M 22 34 L 12 50 L 22 46 Z",c,dark=True)+PF("M 42 34 L 52 50 L 42 46 Z",c,dark=True)
    fl=PF("M 27 44 L 32 60 L 37 44 Z","orange")
    if a: return body+win+fins+G(fl,A_scale("0.7s","1.25"))
    return body+win+fins+fl

@base("flag")
def _(c,a):
    pole=PS("M 14 8 V 58",c,4,dark=True)
    cloth=PF("M 16 10 H 50 L 44 22 L 50 34 H 16 Z",c)
    return pole+(G(cloth,f'<animateTransform attributeName="transform" type="skewX" values="0;6;0" dur="2.2s" repeatCount="indefinite"/>') if a else cloth)

@base("pin")
def _(c,a):
    p=PF("M 32 4 A 18 18 0 0 1 50 22 C 50 36 32 60 32 60 C 32 60 14 36 14 22 A 18 18 0 0 1 32 4 Z",c)
    return (G(p,A_move(0,-3,"1.8s")) if a else p)+WC(32,22,7)

@base("globe")
def _(c,a):
    g_=C(32,32,23,c,light=True)+O(32,32,23,c,3.5,dark=True)
    lines=(f'<ellipse cx="32" cy="32" rx="9" ry="23" fill="none" stroke="{m(c)}" stroke-width="2.6"/>'
           +PS("M 10 32 H 54 M 15 20 H 49 M 15 44 H 49",c,2.4))
    return g_+(G(lines,A_rot(32,32,"14s")) if a else lines)

@base("star")
def _(c,a):
    p=PF("M 32 6 L 40 24 L 60 26 L 45 39 L 49 58 L 32 48 L 15 58 L 19 39 L 4 26 L 24 24 Z",c)
    return G(p,A_scale("2s","1.1")) if a else p

@base("heart")
def _(c,a):
    p=PF("M 32 56 C 10 40 6 26 14 18 C 22 10 32 18 32 24 C 32 18 42 10 50 18 C 58 26 54 40 32 56 Z",c)
    return G(p,A_scale("1.1s","1.12")) if a else p

@base("tag")
def _(c,a):
    p=PF("M 6 28 L 28 6 H 56 V 34 L 34 56 Z",c)
    return p+WC(44,18,5)

@base("battery")
def _(c,a):
    body=R(6,20,46,24,c,4,light=True)+O(0,0,0,c)
    cap=RD(52,27,6,10,c,2)
    fill=f'<rect x="10" y="24" width="22" height="16" rx="2" fill="{m(c)}">{A_blink("2s") if a else ""}</rect>'
    return body+cap+fill

@base("plug")
def _(c,a):
    body=R(20,24,24,22,c,4)
    pins=PS("M 26 24 V 12 M 38 24 V 12",c,4,dark=True)
    wire=PS("M 32 46 V 58",c,4,dark=True)
    return pins+body+wire

@base("bolt")
def _(c,a):
    p=PF("M 36 4 L 16 34 H 30 L 26 60 L 48 28 H 34 Z",c)
    return G(p,A_blink("1.1s")) if a else p

@base("fire")
def _(c,a):
    p=PF("M 32 58 C 18 50 14 38 22 26 C 26 20 28 14 26 6 C 38 12 46 22 46 34 C 46 46 40 54 32 58 Z",c)
    inner=PF("M 32 52 C 26 48 24 40 30 32 C 32 36 38 40 38 46 C 38 50 36 51 32 52 Z","amber")
    if a: return G(p,A_scale("1.3s","1.08"))+G(inner,A_op("0.9s"))
    return p+inner

@base("drop")
def _(c,a):
    p=PF("M 32 6 C 44 24 50 32 50 40 A 18 18 0 0 1 14 40 C 14 32 20 24 32 6 Z",c)
    return (G(p,A_scale("2.2s","1.06")) if a else p)+C(26,42,4,c,light=True)

@base("leaf")
def _(c,a):
    p=PF("M 12 52 C 12 24 32 8 56 8 C 56 32 40 52 12 52 Z",c)
    v=PS("M 16 50 C 28 38 40 26 52 14",c,2.6,dark=True)
    return (G(p,f'<animateTransform attributeName="transform" type="rotate" values="-4 16 50;4 16 50;-4 16 50" dur="2.6s" repeatCount="indefinite"/>') if a else p)+v

@base("thermo")
def _(c,a):
    tube=R(26,6,12,36,c,6,light=True)
    bulb=C(32,48,10,c,light=True)
    fill=f'<rect x="29" y="22" width="6" height="22" rx="3" fill="{m(c)}">{A_blink("2.4s") if a else ""}</rect>'
    return tube+bulb+fill+CD(32,48,6,c)

@base("valve")
def _(c,a):
    pipe=R(4,28,56,8,c,2,dark=True)
    body=C(32,32,13,c)
    handle=PS("M 32 32 V 12 M 24 12 H 40",c,4,dark=True)
    return pipe+body+(G(handle,A_rot(32,32,"4s")) if a else handle)

@base("pump")
def _(c,a):
    body=C(26,38,16,c)
    out=R(38,20,10,20,c,2,dark=True)
    imp=PS("M 26 28 V 48 M 16 38 H 36",c,3.5)
    return out+body+(G(imp,A_rot(26,38,"1.6s")) if a else imp)

@base("motor")
def _(c,a):
    body=R(10,20,36,26,c,4)
    shaft=RD(46,30,12,6,c,2)
    rot=O(28,33,8,c,3.5,dark=True)
    return body+shaft+(G(rot,A_rot(28,33,"1.2s")) if a else rot)

@base("sensor")
def _(c,a):
    body=R(22,32,20,22,c,4)
    return waves(32,28,c,a,3,10,7)+body+WC(32,42,3)

@base("robot")
def _(c,a):
    head=R(14,16,36,30,c,6)
    ant=PS("M 32 16 V 8",c,3,dark=True)+C(32,6,3.5,c)
    eyes=(f'<circle cx="24" cy="30" r="4" fill="#FFFFFF">{A_blink("2.4s") if a else ""}</circle>'
          f'<circle cx="40" cy="30" r="4" fill="#FFFFFF">{A_blink("2.4s") if a else ""}</circle>')
    mouth=WR(24,38,16,3,1.5)
    body=RD(20,46,24,10,c,3)
    return ant+head+eyes+mouth+body

@base("brain")
def _(c,a):
    p=PF("M 30 8 A 12 12 0 0 0 16 22 A 10 10 0 0 0 16 42 A 12 12 0 0 0 30 56 Z",c)
    p2=PF("M 34 8 A 12 12 0 0 1 48 22 A 10 10 0 0 1 48 42 A 12 12 0 0 1 34 56 Z",c,light=True)
    lines=PS("M 24 20 H 32 M 24 32 H 30 M 40 24 H 46 M 38 40 H 46",c,2.4,dark=True)
    if a: return p+p2+G(lines,A_blink("2s"))
    return p+p2+lines

@base("ai")
def _(c,a):
    body=R(12,12,40,40,c,8)
    nodes="".join(C(22+ (i%2)*20, 22+(i//2)*20, 4, c, light=True) for i in range(4))
    links=W("M 22 22 L 42 42 M 42 22 L 22 42",2.4)
    if a: return body+G(links,A_blink("1.8s"))+nodes
    return body+links+nodes

@base("code")
def _(c,a):
    body=R(6,12,52,40,c,5,light=True)
    br=PS("M 22 26 L 14 32 L 22 38 M 42 26 L 50 32 L 42 38 M 36 24 L 28 40",c,3.4)
    return body+br

@base("terminal")
def _(c,a):
    body=R(6,12,52,40,c,5)
    pr=W("M 16 26 L 22 32 L 16 38",3)
    cur=(f'<rect x="28" y="36" width="12" height="3" rx="1.5" fill="#FFFFFF">{A_blink("1s")}</rect>'
         if a else WR(28,36,12,3,1.5))
    return body+pr+cur

@base("branch")
def _(c,a):
    line=PS("M 20 12 V 52",c,3.4,dark=True)
    br=PS("M 20 30 C 32 30 44 26 44 18",c,3.4,dark=True)
    return line+br+C(20,12,6,c)+C(20,52,6,c,light=True)+C(44,14,6,c)

@base("container")
def _(c,a):
    body=R(8,20,48,30,c,3)
    bars="".join(f'<rect x="{14+i*11}" y="24" width="6" height="22" rx="1.5" fill="{l(c)}"/>' for i in range(4))
    return body+bars

@base("package")
def _(c,a):
    return B["box"](c,a)

@base("api")
def _(c,a):
    left=R(4,24,18,16,c,3); right=R(42,24,18,16,c,3,light=True)
    mid=PS("M 22 32 H 42",c,3.4,dark=True,)
    dots=(f'<circle cx="32" cy="32" r="4" fill="{m(c)}">{A_move(6,0,"1.4s") if a else ""}</circle>')
    return mid+left+right+dots

@base("sync")
def _(c,a):
    a1=f'<path d="M 14 32 A 18 18 0 0 1 46 20" fill="none" stroke="{m(c)}" stroke-width="4" stroke-linecap="round"/>'
    a2=f'<path d="M 50 32 A 18 18 0 0 1 18 44" fill="none" stroke="{d(c)}" stroke-width="4" stroke-linecap="round"/>'
    h1=PF("M 46 12 L 52 22 L 40 22 Z",c); h2=PF("M 18 52 L 12 42 L 24 42 Z",c,dark=True)
    g=a1+a2+h1+h2
    return G(g,A_rot(32,32,"1.8s")) if a else g

@base("upload")
def _(c,a):
    cl=PF("M 20 44 A 10 10 0 0 1 21 26 A 13 13 0 0 1 45 28 A 9 9 0 0 1 44 44 Z",c,light=True)
    ar=PS("M 32 52 V 32 M 24 38 L 32 30 L 40 38",c,3.6)
    return cl+(G(ar,A_move(0,-4,"1.6s")) if a else ar)

@base("download")
def _(c,a):
    cl=PF("M 20 38 A 10 10 0 0 1 21 20 A 13 13 0 0 1 45 22 A 9 9 0 0 1 44 38 Z",c,light=True)
    ar=PS("M 32 30 V 52 M 24 44 L 32 52 L 40 44",c,3.6)
    return cl+(G(ar,A_move(0,4,"1.6s")) if a else ar)

@base("link")
def _(c,a):
    a1=f'<path d="M 26 38 L 38 26" fill="none" stroke="{d(c)}" stroke-width="4" stroke-linecap="round"/>'
    r1=f'<rect x="4" y="30" width="26" height="14" rx="7" fill="none" stroke="{m(c)}" stroke-width="4" transform="rotate(-45 17 37)"/>'
    r2=f'<rect x="34" y="20" width="26" height="14" rx="7" fill="none" stroke="{m(c)}" stroke-width="4" transform="rotate(-45 47 27)"/>'
    return r1+r2+a1

@base("shuffle")
def _(c,a):
    p=PS("M 8 18 H 20 L 44 46 H 56 M 8 46 H 20 L 44 18 H 56",c,3.4)
    h=PF("M 56 12 L 62 18 L 56 24 Z",c)+PF("M 56 40 L 62 46 L 56 52 Z",c)
    return p+h

@base("target")
def _(c,a):
    rings=O(32,32,22,c,4)+O(32,32,14,c,4,dark=True)
    core=C(32,32,6,c)
    return rings+(G(core,A_scale("1.6s","1.2")) if a else core)

@base("award")
def _(c,a):
    med=C(32,24,16,c)+O(32,24,16,"amber",3)
    rib=PF("M 22 36 L 18 58 L 32 50 L 46 58 L 42 36 Z",c,dark=True)
    return rib+med+WF("M 32 16 l 3 6 h 6 l -5 5 2 7 -6 -4 -6 4 2 -7 -5 -5 h 6 z")

@base("checklist")
def _(c,a):
    body=R(10,8,44,48,c,5,light=True)
    rows=[]
    for i,y in enumerate((20,32,44)):
        rows.append(f'<rect x="16" y="{y-4}" width="9" height="9" rx="2" fill="{m(c)}"/>')
        rows.append(f'<rect x="30" y="{y-2}" width="18" height="4" rx="2" fill="{m(c)}" opacity="0.5"/>')
        ch=W(f"M 18 {y} l 2.5 2.5 L 24 {y-3}",2.2)
        rows.append(G(ch,A_blink("2.4s",f"{i*0.4}s")) if a else ch)
    return body+"".join(rows)

@base("kanban")
def _(c,a):
    cols="".join(R(8+i*18,10,14,44,c,3,light=True) for i in range(3))
    cards="".join(f'<rect x="{11+i*18}" y="{14+j*12}" width="8" height="9" rx="2" fill="{m(c)}"/>'
                  for i in range(3) for j in range(2 if i!=1 else 3))
    return cols+cards

@base("gantt")
def _(c,a):
    body=R(6,12,52,40,c,4,light=True)
    bars=[]
    for i,(x,w) in enumerate(((12,22),(20,26),(16,18))):
        b=f'<rect x="{x}" y="{20+i*10}" width="{w}" height="6" rx="3" fill="{m(c) if i%2==0 else d(c)}"/>'
        bars.append(G(b,f'<animate attributeName="width" values="{w};{w*0.6:.0f};{w}" dur="{2+i*0.3}s" repeatCount="indefinite"/>') if a else b)
    return body+"".join(bars)

@base("map")
def _(c,a):
    p=PF("M 6 16 L 24 10 L 42 16 L 58 10 V 50 L 42 56 L 24 50 L 6 56 Z",c,light=True)
    folds=PS("M 24 10 V 50 M 42 16 V 56",c,2.6,dark=True)
    rt=PS("M 14 44 C 24 34 34 40 44 24",c,3)
    return p+folds+rt

@base("layers")
def _(c,a):
    l1=PF("M 32 6 L 58 20 L 32 34 L 6 20 Z",c)
    l2=PF("M 32 26 L 58 40 L 32 54 L 6 40 Z",c,light=True)
    if a: return l2+G(l1,A_move(0,-3,"2.2s"))
    return l2+l1

@base("grid")
def _(c,a):
    return "".join(f'<rect x="{10+j*18}" y="{10+i*18}" width="14" height="14" rx="3" fill="{m(c) if (i+j)%2==0 else l(c)}"/>'
                   for i in range(3) for j in range(3))

@base("window")
def _(c,a):
    body=R(6,12,52,40,c,5,light=True)
    bar=PF("M 6 18 A 6 6 0 0 1 12 12 H 52 A 6 6 0 0 1 58 18 V 24 H 6 Z",c)
    dots="".join(WC(14+i*7,18,2.4) for i in range(3))
    return body+bar+dots

@base("dashboard")
def _(c,a):
    body=R(6,10,52,44,c,5,light=True)
    w1=R(11,16,18,14,c,3); w2=R(33,16,20,14,c,3,dark=True)
    w3=R(11,34,42,14,c,3)
    return body+w1+w2+w3

@base("settings")
def _(c,a):
    return B["gear"](c,a)

@base("power")
def _(c,a):
    arc=f'<path d="M 20 18 A 18 18 0 1 0 44 18" fill="none" stroke="{m(c)}" stroke-width="5" stroke-linecap="round"/>'
    st=PS("M 32 8 V 28",c,5,dark=True)
    return (G(arc+st,A_blink("2s")) if a else arc+st)

@base("wifi")
def _(c,a):
    return waves(32,44,c,a,3,12,9)+CD(32,46,4,c)

@base("wifi-off")
def _(c,a):
    return waves(32,42,c,False,3,11,8)+dot_slash(c)

def dot_slash(c):
    return PS("M 12 12 L 52 52","red",4)

@base("warning")
def _(c,a):
    t=PF("M 32 6 L 60 56 H 4 Z",c)
    return (G(t,A_blink("1.4s")) if a else t)+WF("M 30 22 h 4 v 16 h -4 z")+WC(32,46,3)

@base("info")
def _(c,a):
    return C(32,32,24,c)+WF("M 30 26 h 4 v 18 h -4 z")+WC(32,20,3)

@base("help")
def _(c,a):
    return C(32,32,24,c)+W("M 25 24 A 7 7 0 0 1 39 25 C 39 31 32 31 32 38",3.4)+WC(32,46,3)

@base("check")
def _(c,a):
    circ=C(32,32,24,c)
    ch=W("M 21 33 L 29 41 L 44 24",5)
    return circ+(G(ch,A_op("1.8s")) if a else ch)

@base("cross")
def _(c,a):
    return C(32,32,24,c)+W("M 23 23 L 41 41 M 41 23 L 23 41",5)

@base("plus")
def _(c,a):
    return C(32,32,24,c)+W("M 32 21 V 43 M 21 32 H 43",5)

@base("minus")
def _(c,a):
    return C(32,32,24,c)+W("M 21 32 H 43",5)

@base("arrow-right")
def _(c,a):
    p=PS("M 12 32 H 48 M 38 22 L 48 32 L 38 42",c,5)
    return G(p,A_move(5,0,"1.6s")) if a else p

@base("arrow-up")
def _(c,a):
    p=PS("M 32 52 V 16 M 22 26 L 32 16 L 42 26",c,5)
    return G(p,A_move(0,-5,"1.6s")) if a else p

@base("refresh")
def _(c,a):
    return B["sync"](c,a)

@base("trash")
def _(c,a):
    lid=R(12,14,40,7,c,3,dark=True)+R(26,8,12,6,c,2,dark=True)
    body=PF("M 16 22 H 48 L 45 56 H 19 Z",c)
    return lid+body+W("M 27 30 V 48 M 37 30 V 48",2.6)

@base("edit")
def _(c,a):
    pen=PF("M 40 8 L 56 24 L 26 54 L 10 54 L 10 38 Z",c)
    tip=PF("M 10 54 L 10 44 L 20 54 Z",c,dark=True)
    return pen+tip

@base("save")
def _(c,a):
    body=PF("M 8 8 H 46 L 56 18 V 56 H 8 Z",c)
    top=WR(20,12,24,14,2)
    bot=WR(16,36,32,20,2)
    return body+top+bot

@base("copy")
def _(c,a):
    back=R(18,8,38,38,c,4,light=True)
    front=R(8,18,38,38,c,4)
    return back+front

@base("share")
def _(c,a):
    nodes=C(50,14,7,c)+C(50,50,7,c)+C(14,32,7,c,light=True)
    lines=PS("M 20 28 L 44 17 M 20 36 L 44 47",c,3,dark=True)
    return lines+nodes

@base("attach")
def _(c,a):
    p=PS("M 42 18 L 22 38 A 8 8 0 0 0 34 50 L 50 34 A 13 13 0 0 0 32 16 L 16 32",c,4.5)
    return p

@base("image")
def _(c,a):
    body=R(6,12,52,40,c,4,light=True)
    sun=C(20,24,5,c)
    hills=PF("M 10 48 L 24 34 L 34 44 L 44 32 L 54 48 Z",c)
    return body+sun+hills

@base("film")
def _(c,a):
    body=R(6,14,52,36,c,4)
    holes="".join(WR(10+i*10,18,6,5,1) for i in range(5))+"".join(WR(10+i*10,41,6,5,1) for i in range(5))
    mid=WR(14,26,36,12,2)
    return body+holes+mid

@base("music")
def _(c,a):
    n1=C(20,46,8,c)+PS("M 28 46 V 14",c,4,dark=True)
    n2=C(44,40,8,c,light=True)+PS("M 52 40 V 8",c,4,dark=True)
    beam=PS("M 28 14 L 52 8",c,4,dark=True)
    g=n1+n2+beam
    return G(g,A_move(0,-2,"1.4s")) if a else g

@base("play")
def _(c,a):
    return C(32,32,24,c)+WF("M 26 20 L 46 32 L 26 44 Z")

@base("pause")
def _(c,a):
    return C(32,32,24,c)+WR(25,21,6,22,2)+WR(35,21,6,22,2)

@base("stop")
def _(c,a):
    return C(32,32,24,c)+WR(23,23,18,18,3)

@base("mail-open")
def _(c,a):
    body=PF("M 6 28 L 32 10 L 58 28 V 50 H 6 Z",c)
    letter=WR(18,20,28,20,2)
    flap=PS("M 6 28 L 32 44 L 58 28",c,3.4,dark=True)
    return body+letter+flap

@base("inbox")
def _(c,a):
    body=R(6,16,52,34,c,4)
    tray=WF("M 14 34 H 24 A 8 8 0 0 0 40 34 H 50 V 46 H 14 Z")
    return body+tray

@base("bookmark")
def _(c,a):
    p=PF("M 16 6 H 48 V 58 L 32 46 L 16 58 Z",c)
    return G(p,A_move(0,-2,"2.2s")) if a else p

@base("id")
def _(c,a):
    body=R(6,14,52,36,c,4,light=True)
    ph=C(22,28,8,c)+PF("M 12 44 A 12 12 0 0 1 32 44 Z",c)
    lines=PS("M 38 26 H 52 M 38 34 H 52",c,2.6,dark=True)
    return body+ph+lines

@base("scan")
def _(c,a):
    corners=PS("M 10 20 V 12 H 20 M 44 12 H 54 V 20 M 54 44 V 52 H 44 M 20 52 H 10 V 44",c,3.4)
    line=f'<rect x="10" y="30" width="44" height="4" rx="2" fill="{m(c)}">{A_move(0,10,"1.8s") if a else ""}</rect>'
    return corners+line

@base("qr")
def _(c,a):
    def blk(x,y):
        return (R(x,y,16,16,c,2)+WR(x+4,y+4,8,8,1))
    small="".join(f'<rect x="{34+ (i%3)*8}" y="{34+(i//3)*8}" width="6" height="6" fill="{m(c)}"/>'
                  for i in range(9) if i%2==0)
    return blk(6,6)+blk(42,6)+blk(6,42)+small

@base("barcode")
def _(c,a):
    bars="".join(f'<rect x="{8+i*5}" y="14" width="{3 if i%3 else 2}" height="36" fill="{m(c) if i%2==0 else d(c)}"/>'
                 for i in range(10))
    return bars

@base("shopping")
def _(c,a):
    bag=PF("M 12 22 H 52 L 48 56 H 16 Z",c)
    handle=PS("M 24 22 V 16 A 8 8 0 0 1 40 16 V 22",c,3.4,dark=True)
    return handle+bag

@base("gift")
def _(c,a):
    body=R(8,24,48,30,c,4)
    lid=R(6,16,52,10,c,3,dark=True)
    rib=WR(29,16,6,38,1)
    bow=C(26,14,6,c,light=True)+C(38,14,6,c,light=True)
    return body+lid+rib+bow

@base("flask")
def _(c,a):
    body=PF("M 26 8 H 38 V 24 L 50 52 A 4 4 0 0 1 46 58 H 18 A 4 4 0 0 1 14 52 Z",c,light=True)
    liq=PF("M 20 40 H 44 L 48 52 A 3 3 0 0 1 45 56 H 19 A 3 3 0 0 1 16 52 Z",c)
    bub=C(28,34,3,c) if not a else G(C(28,36,3,c),A_move(0,-8,"2.2s"))
    return body+liq+bub+PS("M 24 8 H 40",c,3,dark=True)

@base("atom")
def _(c,a):
    o1=f'<ellipse cx="32" cy="32" rx="24" ry="9" fill="none" stroke="{m(c)}" stroke-width="3"/>'
    o2=f'<ellipse cx="32" cy="32" rx="24" ry="9" fill="none" stroke="{m(c)}" stroke-width="3" transform="rotate(60 32 32)"/>'
    o3=f'<ellipse cx="32" cy="32" rx="24" ry="9" fill="none" stroke="{m(c)}" stroke-width="3" transform="rotate(-60 32 32)"/>'
    core=CD(32,32,6,c)
    if a: return G(o1+o2+o3,A_rot(32,32,"7s"))+core
    return o1+o2+o3+core

@base("shield-check")
def _(c,a):
    return B["shield"](c,a)

@base("cube")
def _(c,a):
    return B["box"](c,a)

@base("pyramid")
def _(c,a):
    left=PF("M 32 6 L 8 52 H 32 Z",c)
    right=PF("M 32 6 L 56 52 H 32 Z",c,dark=True)
    return left+right

@base("compass")
def _(c,a):
    face=C(32,32,23,c,light=True)+O(32,32,23,c,3.5)
    needle=PF("M 32 14 L 38 34 L 32 50 L 26 34 Z",c,dark=True)
    return face+(G(needle,A_rot(32,32,"5s")) if a else needle)

@base("anchor")
def _(c,a):
    ring_=O(32,12,6,c,3.5)
    st=PS("M 32 18 V 52",c,4,dark=True)
    arms=PS("M 12 38 A 20 20 0 0 0 52 38",c,4,dark=True)
    cross=PS("M 22 24 H 42",c,3.4)
    return ring_+st+arms+cross

@base("umbrella")
def _(c,a):
    dome=PF("M 6 34 A 26 26 0 0 1 58 34 Z",c)
    handle=PS("M 32 34 V 52 A 6 6 0 0 0 44 52",c,3.6,dark=True)
    return dome+handle

@base("sun")
def _(c,a):
    core=C(32,32,13,c)
    rays="".join(PS(f"M {32+18*x:.1f} {32+18*y:.1f} L {32+24*x:.1f} {32+24*y:.1f}",c,3.4)
                 for x,y in ((0,-1),(0,1),(-1,0),(1,0),(0.7,0.7),(-0.7,0.7),(0.7,-0.7),(-0.7,-0.7)))
    if a: return G(rays,A_rot(32,32,"14s"))+G(core,A_scale("2.4s","1.08"))
    return rays+core

@base("moon")
def _(c,a):
    return PF("M 40 6 A 26 26 0 1 0 40 58 A 20 20 0 0 1 40 6 Z",c)

@base("cloud-rain")
def _(c,a):
    cl=PF("M 18 36 A 10 10 0 0 1 19 18 A 13 13 0 0 1 43 20 A 9 9 0 0 1 42 36 Z",c)
    drops="".join((f'<path d="M {20+i*10} 42 V 52" stroke="{d(c)}" stroke-width="3" stroke-linecap="round">'
                   f'{A_blink("1.2s",f"{i*0.25}s")}</path>' if a
                   else PS(f"M {20+i*10} 42 V 52",c,3,dark=True)) for i in range(3))
    return cl+drops

@base("snow")
def _(c,a):
    fl=PS("M 32 8 V 56 M 12 20 L 52 44 M 52 20 L 12 44",c,3.4)
    return G(fl,A_rot(32,32,"9s")) if a else fl

# ── дополнительные формы для полноты набора ─────────────────────────
@base("badge")
def _(c,a):
    return C(32,32,22,c)+O(32,32,22,c,3,dark=True)+WF("M 32 20 l 3.5 7 8 1 -6 5.5 1.5 8 -7 -4 -7 4 1.5 -8 -6 -5.5 8 -1 z")

@base("crown")
def _(c,a):
    p=PF("M 8 44 L 12 18 L 24 30 L 32 12 L 40 30 L 52 18 L 56 44 Z",c)
    base_=RD(10,44,44,8,c,2)
    return p+base_

@base("ticket")
def _(c,a):
    body=R(6,18,52,28,c,5)
    notch=f'<circle cx="32" cy="18" r="5" fill="#00000000"/>'
    line=W("M 32 22 V 42",2.6)
    return body+line

@base("scale")
def _(c,a):
    post=PS("M 32 12 V 52 M 20 56 H 44",c,4,dark=True)
    beam=PS("M 12 20 H 52",c,3.4)
    pans=PF("M 6 22 H 22 L 18 32 H 10 Z",c)+PF("M 42 22 H 58 L 54 32 H 46 Z",c)
    if a: return post+G(beam+pans,f'<animateTransform attributeName="transform" type="rotate" values="-4 32 20;4 32 20;-4 32 20" dur="2.4s" repeatCount="indefinite"/>')
    return post+beam+pans

@base("pallet")
def _(c,a):
    boards="".join(R(6,40+i*8,52,5,c,1) for i in range(2))
    legs="".join(R(8+i*20,46,8,10,c,1,light=True) for i in range(3))
    load=R(14,18,36,22,c,3,dark=True)
    return load+legs+boards

@base("crane")
def _(c,a):
    mast=PS("M 16 56 V 10 M 16 10 H 50",c,4,dark=True)
    hook=PS("M 44 10 V 26",c,3)
    load=R(38,26,12,10,c,3)
    if a: return mast+hook+G(load,A_move(0,6,"2.4s"))
    return mast+hook+load

@base("helmet")
def _(c,a):
    dome=PF("M 10 40 A 22 22 0 0 1 54 40 Z",c)
    brim=RD(6,40,52,7,c,3)
    return dome+brim

@base("shield-lock")
def _(c,a):
    sh=PF("M 32 6 L 54 14 V 32 C 54 45 44 54 32 58 C 20 54 10 45 10 32 V 14 Z",c)
    lock=WR(25,30,14,13,2)+W("M 28 30 V 26 A 4 4 0 0 1 36 26 V 30",2.4)
    return sh+lock

# ═══════════════════ накладки-признаки ═══════════════════════════════
# Маленький значок в углу: «защищено», «ошибка», «синхронизируется».
# Именно они дают набору смысловое разнообразие: одна и та же форма с
# разными накладками — это разные состояния одной сущности, а не
# перекрашенная копия.
BADGE = {}
def badge(name):
    def deco(fn):
        BADGE[name] = fn
        return fn
    return deco

def _bg(c, anim=False):
    """Кружок-подложка накладки в правом нижнем углу."""
    inner = f'<circle cx="48" cy="48" r="14" fill="#FFFFFF"/><circle cx="48" cy="48" r="11.5" fill="{m(c)}"/>'
    return inner

@badge("ok")
def _(a):      return _bg("green")+W("M 43 48 L 47 52 L 54 44",3)
@badge("err")
def _(a):      return _bg("red")+W("M 43 43 L 53 53 M 53 43 L 43 53",3)
@badge("warn")
def _(a):
    b=_bg("amber")+WF("M 46.5 41 h 3 v 8 h -3 z")+WC(48,54,1.8)
    return G(b,A_blink("1.3s")) if a else b
@badge("lock")
def _(a):      return _bg("slate")+WR(43,47,10,9,1.5)+W("M 45 47 V 44 A 3 3 0 0 1 51 44 V 47",2)
@badge("plus")
def _(a):      return _bg("blue")+W("M 48 42 V 54 M 42 48 H 54",3)
@badge("minus")
def _(a):      return _bg("slate")+W("M 42 48 H 54",3)
@badge("up")
def _(a):
    b=_bg("emerald")+W("M 48 54 V 42 M 43 47 L 48 42 L 53 47",2.8)
    return G(b,A_move(0,-2,"1.4s")) if a else b
@badge("down")
def _(a):
    b=_bg("rose")+W("M 48 42 V 54 M 43 49 L 48 54 L 53 49",2.8)
    return G(b,A_move(0,2,"1.4s")) if a else b
@badge("sync")
def _(a):
    arc=(f'<circle cx="48" cy="48" r="14" fill="#FFFFFF"/><circle cx="48" cy="48" r="11.5" fill="{m("sky")}"/>'
         f'<path d="M 42 48 A 6 6 0 0 1 54 46" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round"/>'
         f'<path d="M 54 50 A 6 6 0 0 1 42 52" fill="none" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round"/>')
    return G(arc,A_rot(48,48,"1.4s")) if a else arc
@badge("clock")
def _(a):
    b=_bg("violet")+W("M 48 43 V 48 L 52 51",2.4)
    return b
@badge("bolt")
def _(a):
    b=_bg("amber")+WF("M 50 41 L 44 49 h 4 l -1 7 6 -9 h -4 z")
    return G(b,A_blink("1s")) if a else b
@badge("cloud")
def _(a):      return _bg("cyan")+WF("M 43 51 a 4 4 0 0 1 1 -7 a 5 5 0 0 1 9 1 a 3.5 3.5 0 0 1 0 6 z")
@badge("gear")
def _(a):
    b=(f'<circle cx="48" cy="48" r="14" fill="#FFFFFF"/><circle cx="48" cy="48" r="11.5" fill="{m("slate")}"/>'
       +"".join(f'<rect x="46.6" y="39" width="2.8" height="5" rx="1" fill="#FFFFFF" transform="rotate({i*60} 48 48)"/>' for i in range(6))
       +f'<circle cx="48" cy="48" r="4" fill="none" stroke="#FFFFFF" stroke-width="2.2"/>')
    return G(b,A_rot(48,48,"4s")) if a else b
@badge("star")
def _(a):      return _bg("amber")+WF("M 48 41 l 2 4.5 5 .6 -3.6 3.4 .9 4.9 -4.3 -2.4 -4.3 2.4 .9 -4.9 -3.6 -3.4 5 -.6 z")
@badge("eye")
def _(a):      return _bg("indigo")+WF("M 40 48 c 3 -4.4 13 -4.4 16 0 c -3 4.4 -13 4.4 -16 0 z")+f'<circle cx="48" cy="48" r="2.4" fill="{m("indigo")}"/>'
@badge("question")
def _(a):      return _bg("violet")+W("M 45 45 A 3.2 3.2 0 0 1 51 46 C 51 49 48 49 48 51",2.4)+WC(48,55,1.6)

# ═══════════════════ каталог ═════════════════════════════════════════
# Строка: (имя, раздел, подпись, базовая форма, цвет, накладка, анимация)
CAT = []
def I(name, group, title, form, color, bdg=None, anim=False):
    CAT.append((name, group, title, form, color, bdg, anim))

# ── Сеть: обозначения схем (форма общепринятая, рисунок собственный) ─
NETW = [
 ("router","Маршрутизатор","router","blue"),
 ("router-core","Маршрутизатор ядра","router","indigo"),
 ("router-edge","Пограничный маршрутизатор","router","violet"),
 ("router-wifi","Маршрутизатор Wi-Fi","router","cyan"),
 ("router-voice","Голосовой шлюз","router","teal"),
 ("switch","Коммутатор","switch","teal"),
 ("switch-l3","Коммутатор L3","switch","emerald"),
 ("switch-access","Коммутатор доступа","switch","green"),
 ("switch-core","Коммутатор ядра","switch","indigo"),
 ("switch-poe","Коммутатор PoE","switch","amber"),
 ("hub","Концентратор","hub","slate"),
 ("hub-mesh","Ячеистая сеть","hub","violet"),
 ("firewall","Межсетевой экран","firewall","red"),
 ("firewall-ngfw","Экран нового поколения","firewall","rose"),
 ("cloud","Облако","cloud","sky"),
 ("cloud-public","Публичное облако","cloud","cyan"),
 ("cloud-private","Частное облако","cloud","indigo"),
 ("internet","Интернет","globe","sky"),
 ("wan","Сеть WAN","cloud","slate"),
 ("ap","Точка доступа","ap","cyan"),
 ("ap-outdoor","Точка доступа уличная","ap","teal"),
 ("antenna","Антенна","antenna","blue"),
 ("tower","Вышка связи","tower","slate"),
 ("satellite","Спутниковый канал","satellite","violet"),
 ("modem","Модем","modem","stone"),
 ("server","Сервер","server","slate"),
 ("server-web","Веб-сервер","server","blue"),
 ("server-app","Сервер приложений","server","indigo"),
 ("server-mail","Почтовый сервер","server","amber"),
 ("server-dns","Сервер DNS","server","teal"),
 ("server-file","Файловый сервер","server","brown"),
 ("server-backup","Сервер резервных копий","server","emerald"),
 ("rack","Серверная стойка","rack","stone"),
 ("nas","Сетевое хранилище","nas","cyan"),
 ("san","Хранилище SAN","nas","indigo"),
 ("db","База данных","db","blue"),
 ("db-replica","Реплика базы","db","sky"),
 ("db-cluster","Кластер баз","db","indigo"),
 ("pc","Рабочая станция","pc","slate"),
 ("pc-admin","Рабочее место администратора","pc","indigo"),
 ("laptop","Ноутбук","laptop","stone"),
 ("phone-ip","IP-телефон","phone","teal"),
 ("phone-mobile","Мобильный телефон","phone","violet"),
 ("tablet","Планшет","tablet","sky"),
 ("printer","Принтер","printer","stone"),
 ("printer-net","Сетевой принтер","printer","blue"),
 ("cpu","Процессор","cpu","violet"),
 ("chip","Микросхема","chip","purple"),
 ("hdd","Жёсткий диск","hdd","slate"),
 ("ram","Оперативная память","ram","emerald"),
 ("cable","Кабель","cable","amber"),
 ("patch","Патч-панель","port","stone"),
 ("lan","Локальная сеть","lan","blue"),
 ("vpn","Туннель VPN","vpn","emerald"),
 ("proxy","Прокси-сервер","proxy","amber"),
 ("balancer","Балансировщик","balancer","teal"),
 ("ids","Система обнаружения вторжений","shield","rose"),
 ("dmz","Зона DMZ","firewall","orange"),
 ("gateway","Шлюз","proxy","indigo"),
 ("bridge","Мост","link","slate"),
 ("repeater","Повторитель","ap","lime"),
 ("controller","Контроллер сети","dashboard","violet"),
 ("sdwan","Сеть SD-WAN","cloud","purple"),
 ("ups","Источник питания","battery","amber"),
 ("pdu","Блок розеток","plug","stone"),
]
for name, title, form, color in NETW:
    I(name, "Сеть", title, form, color)
# анимированные парные версии — «работает», «идёт обмен»
for name, title, form, color in NETW:
    if form in ("router","switch","cloud","ap","antenna","server","rack","db","nas","hub",
                "cable","vpn","proxy","balancer","modem","satellite","tower","firewall",
                "globe","link","battery","dashboard","shield","plug","port","lan",
                "pc","phone","printer","cpu","chip","hdd","laptop","tablet","ram"):
        I(name+"-live", "Сеть · в работе", title+" (работает)", form, color, None, True)


# ── Остальные разделы ────────────────────────────────────────────────
GROUPS = [
 ("Данные и отчёты", [
   ("chart-bar","Столбцы","chart-bar","blue"), ("chart-line","График","chart-line","emerald"),
   ("chart-pie","Круговая","chart-pie","violet"), ("chart-area","Область","chart-area","cyan"),
   ("chart-donut","Кольцевая","chart-donut","indigo"), ("gauge","Индикатор","gauge","amber"),
   ("table","Таблица","table","slate"), ("report","Отчёт","report","blue"),
   ("dashboard","Сводка","dashboard","indigo"), ("dataflow","Поток данных","dataflow","teal"),
   ("filter","Фильтр","filter","purple"), ("search","Поиск","search","sky"),
   ("kanban","Канбан-доска","kanban","teal"), ("gantt","Диаграмма Ганта","gantt","blue"),
   ("checklist","Контрольный список","checklist","green"), ("layers","Слои","layers","violet"),
   ("grid","Сетка","grid","slate"), ("scan","Сканирование","scan","cyan"),
   ("qr","QR-код","qr","slate"), ("barcode","Штрихкод","barcode","stone"),
 ]),
 ("Безопасность", [
   ("shield","Защита","shield","emerald"), ("shield-lock","Защита с замком","shield-lock","teal"),
   ("lock","Замок","lock","slate"), ("unlock","Замок открыт","unlock","amber"),
   ("key","Ключ","key","amber"), ("fingerprint","Отпечаток","fingerprint","indigo"),
   ("bug","Ошибка","bug","red"), ("virus","Вредоносный код","virus","rose"),
   ("eye","Наблюдение","eye","indigo"), ("warning","Внимание","warning","amber"),
   ("id","Удостоверение","id","blue"), ("badge","Знак","badge","amber"),
 ]),
 ("Люди и общение", [
   ("user","Сотрудник","user","blue"), ("users","Группа","users","indigo"),
   ("team","Команда","team","violet"), ("chat","Обсуждение","chat","teal"),
   ("mail","Письмо","mail","amber"), ("mail-open","Письмо открыто","mail-open","orange"),
   ("inbox","Входящие","inbox","sky"), ("bell","Уведомление","bell","amber"),
   ("call","Звонок","call","green"), ("video","Видеосвязь","video","rose"),
   ("mic","Микрофон","mic","violet"), ("hand","Рука","hand","amber"),
   ("share","Поделиться","share","sky"), ("crown","Руководитель","crown","amber"),
 ]),
 ("Документы", [
   ("doc","Документ","doc","blue"), ("docs","Документы","docs","sky"),
   ("folder","Папка","folder","amber"), ("folder-open","Папка открыта","folder-open","orange"),
   ("archive","Архив","archive","stone"), ("clipboard","Планшет с бумагой","clipboard","teal"),
   ("note","Заметка","note","lime"), ("book","Книга","book","brown"),
   ("bookmark","Закладка","bookmark","rose"), ("attach","Вложение","attach","slate"),
   ("save","Сохранить","save","blue"), ("copy","Копия","copy","slate"),
   ("edit","Правка","edit","amber"), ("trash","Удалить","trash","red"),
   ("image","Изображение","image","cyan"), ("film","Видеофайл","film","violet"),
   ("music","Звук","music","pink"), ("ticket","Заявка","ticket","teal"),
 ]),
 ("Время и планы", [
   ("calendar","Календарь","calendar","blue"), ("clock","Часы","clock","indigo"),
   ("hourglass","Песочные часы","hourglass","amber"), ("timer","Таймер","timer","rose"),
   ("map","Карта","map","green"), ("pin","Метка","pin","red"),
   ("flag","Флаг","flag","blue"), ("target","Цель","target","rose"),
   ("award","Награда","award","amber"), ("star","Звезда","star","amber"),
 ]),
 ("Работа и производство", [
   ("briefcase","Портфель","briefcase","brown"), ("building","Здание","building","slate"),
   ("factory","Производство","factory","stone"), ("bank","Банк","bank","emerald"),
   ("money","Деньги","money","green"), ("card","Карта оплаты","card","indigo"),
   ("cart","Корзина","cart","amber"), ("shopping","Покупки","shopping","pink"),
   ("gift","Подарок","gift","rose"), ("box","Груз","box","brown"),
   ("pallet","Паллета","pallet","amber"), ("truck","Доставка","truck","blue"),
   ("plane","Авиаперевозка","plane","sky"), ("ship","Морская перевозка","ship","teal"),
   ("train","Железная дорога","train","slate"), ("car","Автомобиль","car","indigo"),
   ("crane","Кран","crane","amber"), ("helmet","Каска","helmet","orange"),
   ("scale","Весы","scale","stone"),
 ]),
 ("Инструменты", [
   ("gear","Настройка","gear","slate"), ("tools","Инструменты","tools","stone"),
   ("wrench","Гаечный ключ","wrench","slate"), ("hammer","Молоток","hammer","brown"),
   ("brush","Кисть","brush","violet"), ("palette","Палитра","palette","pink"),
   ("ruler","Линейка","ruler","amber"), ("bulb","Идея","bulb","amber"),
   ("rocket","Запуск","rocket","rose"), ("power","Питание","power","emerald"),
   ("plug","Розетка","plug","stone"), ("battery","Аккумулятор","battery","green"),
   ("bolt","Электричество","bolt","amber"), ("valve","Задвижка","valve","teal"),
   ("pump","Насос","pump","cyan"), ("motor","Двигатель","motor","slate"),
   ("sensor","Датчик","sensor","lime"), ("thermo","Температура","thermo","red"),
   ("flask","Лаборатория","flask","purple"), ("atom","Атом","atom","indigo"),
 ]),
 ("Разработка", [
   ("code","Код","code","indigo"), ("terminal","Терминал","terminal","slate"),
   ("branch","Ветка","branch","violet"), ("container","Контейнер","container","sky"),
   ("api","Интерфейс API","api","teal"), ("sync","Синхронизация","sync","blue"),
   ("upload","Отправка","upload","emerald"), ("download","Загрузка","download","sky"),
   ("link","Ссылка","link","blue"), ("shuffle","Перемешать","shuffle","violet"),
   ("window","Окно","window","slate"), ("robot","Робот","robot","indigo"),
   ("brain","Мышление","brain","pink"), ("ai","Искусственный интеллект","ai","violet"),
 ]),
 ("Состояния", [
   ("check","Готово","check","green"), ("cross","Отказ","cross","red"),
   ("plus","Добавить","plus","blue"), ("minus","Убрать","minus","slate"),
   ("info","Сведения","info","sky"), ("help","Вопрос","help","violet"),
   ("arrow-right","Далее","arrow-right","blue"), ("arrow-up","Рост","arrow-up","emerald"),
   ("refresh","Обновить","refresh","cyan"), ("play","Пуск","play","green"),
   ("pause","Пауза","pause","amber"), ("stop","Остановка","stop","red"),
   ("fire","Срочно","fire","orange"), ("drop","Капля","drop","sky"),
   ("leaf","Экология","leaf","green"), ("sun","День","sun","amber"),
   ("moon","Ночь","moon","indigo"), ("cloud-rain","Дождь","cloud-rain","sky"),
   ("snow","Снег","snow","cyan"), ("globe","Мир","globe","blue"),
   ("compass","Направление","compass","teal"), ("anchor","Якорь","anchor","slate"),
   ("umbrella","Защита от риска","umbrella","rose"), ("cube","Объём","cube","violet"),
   ("pyramid","Пирамида","pyramid","amber"), ("tag","Метка-ярлык","tag","teal"),
   ("heart","Избранное","heart","rose"), ("settings","Параметры","settings","slate"),
 ]),
]
for gname, rows in GROUPS:
    for name, title, form, color in rows:
        I(name, gname, title, form, color)

# ── цветные варианты: та же форма в другом цвете, другой смысл ────────
VARIANTS = [
 ("server","Сервер","slate",[("blue","резервный"),("emerald","в работе"),("amber","обслуживание"),("rose","авария")]),
 ("db","База данных","blue",[("emerald","основная"),("amber","архивная"),("violet","аналитическая")]),
 ("cloud","Облако","sky",[("violet","вычисления"),("emerald","хранение"),("amber","сервисы")]),
 ("user","Сотрудник","blue",[("emerald","в сети"),("amber","занят"),("slate","не в сети"),("rose","заблокирован")]),
 ("folder","Папка","amber",[("blue","рабочая"),("emerald","общая"),("rose","закрытая"),("slate","архивная")]),
 ("doc","Документ","blue",[("emerald","согласован"),("amber","на правке"),("rose","отклонён"),("slate","черновик")]),
 ("chart-bar","Столбцы","blue",[("emerald","рост"),("rose","спад"),("amber","план")]),
 ("box","Груз","brown",[("blue","в пути"),("emerald","доставлен"),("amber","на складе"),("rose","задержан")]),
 ("shield","Защита","emerald",[("blue","политика"),("amber","предупреждение"),("rose","нарушение")]),
 ("gear","Настройка","slate",[("blue","параметры"),("violet","автоматизация"),("amber","обслуживание")]),
 ("flag","Флаг","blue",[("emerald","начало"),("rose","важное"),("amber","внимание")]),
 ("pin","Метка","red",[("blue","объект"),("emerald","готово"),("violet","интерес")]),
 ("building","Здание","slate",[("blue","офис"),("emerald","филиал"),("brown","склад")]),
 ("truck","Доставка","blue",[("emerald","в срок"),("amber","в пути"),("rose","опоздание")]),
 ("bulb","Идея","amber",[("emerald","принята"),("violet","на обсуждении"),("slate","отложена")]),
 ("code","Код","indigo",[("emerald","проверен"),("amber","на правке"),("rose","с ошибкой")]),
 ("chat","Обсуждение","teal",[("blue","переписка"),("amber","ожидает ответа"),("rose","спор")]),
 ("clock","Часы","indigo",[("emerald","в срок"),("amber","скоро срок"),("rose","просрочено")]),
 ("money","Деньги","green",[("amber","ожидание"),("rose","убыток"),("blue","бюджет")]),
 ("factory","Производство","stone",[("emerald","работает"),("amber","наладка"),("rose","простой")]),
]
for form, base_title, _c, rows in VARIANTS:
    for color, suffix in rows:
        I(f"{form}-{color}", "Цветные варианты", f"{base_title} — {suffix}", form, color)

# ── с накладками: состояния сущностей ────────────────────────────────
BADGED = [
 ("server","Сервер",["ok","err","warn","lock","sync","gear","clock","bolt","cloud","eye"]),
 ("db","База данных",["ok","err","warn","lock","sync","up","down","clock"]),
 ("cloud","Облако",["ok","err","sync","lock","up","down","warn"]),
 ("user","Сотрудник",["ok","err","plus","minus","lock","star","clock","question"]),
 ("users","Группа",["ok","plus","minus","lock","star"]),
 ("doc","Документ",["ok","err","warn","lock","plus","minus","clock","eye","star","question"]),
 ("folder","Папка",["ok","err","lock","plus","minus","sync","eye","star"]),
 ("router","Маршрутизатор",["ok","err","warn","lock","sync","bolt"]),
 ("switch","Коммутатор",["ok","err","warn","bolt","gear"]),
 ("firewall","Межсетевой экран",["ok","err","warn","lock","eye"]),
 ("pc","Рабочая станция",["ok","err","warn","lock","sync","gear","cloud"]),
 ("laptop","Ноутбук",["ok","err","lock","sync","cloud"]),
 ("phone","Телефон",["ok","err","lock","bell" if "bell" in BADGE else "warn"]),
 ("box","Груз",["ok","err","clock","up","down","warn"]),
 ("truck","Доставка",["ok","warn","clock","err"]),
 ("calendar","Календарь",["ok","plus","minus","warn","clock","star"]),
 ("chart-bar","Столбцы",["ok","up","down","warn","eye"]),
 ("chart-line","График",["up","down","ok","warn"]),
 ("shield","Защита",["ok","err","warn","lock","eye"]),
 ("lock","Замок",["ok","err","warn","question"]),
 ("key","Ключ",["ok","err","plus","minus"]),
 ("mail","Письмо",["ok","err","plus","lock","clock","warn"]),
 ("chat","Обсуждение",["ok","plus","warn","lock","clock"]),
 ("code","Код",["ok","err","warn","sync","gear","eye"]),
 ("container","Контейнер",["ok","err","sync","warn","gear"]),
 ("api","Интерфейс API",["ok","err","lock","sync","warn"]),
 ("gear","Настройка",["ok","err","warn","lock"]),
 ("building","Здание",["ok","warn","lock","plus"]),
 ("money","Деньги",["ok","err","up","down","clock","warn"]),
 ("card","Карта оплаты",["ok","err","lock","warn"]),
 ("bulb","Идея",["ok","err","plus","star","question"]),
 ("target","Цель",["ok","err","up","clock"]),
 ("robot","Робот",["ok","err","gear","bolt","warn"]),
 ("ai","Искусственный интеллект",["ok","err","gear","sync","eye"]),
 ("image","Изображение",["ok","err","plus","lock","eye"]),
 ("nas","Сетевое хранилище",["ok","err","warn","lock","sync","up","down"]),
 ("rack","Серверная стойка",["ok","err","warn","gear","bolt"]),
 ("printer","Принтер",["ok","err","warn","clock"]),
 ("ap","Точка доступа",["ok","err","warn","lock","bolt"]),
 ("battery","Аккумулятор",["ok","warn","err","bolt"]),
 ("map","Карта",["ok","plus","pin" if "pin" in BADGE else "star","eye"]),
 ("flask","Лаборатория",["ok","err","warn","eye"]),
 ("sensor","Датчик",["ok","err","warn","bolt","eye"]),
 ("valve","Задвижка",["ok","err","warn","lock"]),
 ("motor","Двигатель",["ok","err","warn","bolt","gear"]),
 ("briefcase","Портфель",["ok","lock","plus","clock"]),
]
BASE_COLOR = {}
for gname, rows in GROUPS:
    for name, title, form, color in rows:
        BASE_COLOR.setdefault(form, color)
for name, title, form, color in NETW:
    BASE_COLOR.setdefault(form, color)

BADGE_TITLE = {
 "ok":"готово","err":"ошибка","warn":"предупреждение","lock":"защищено","plus":"добавить",
 "minus":"убрать","up":"рост","down":"снижение","sync":"синхронизация","clock":"по времени",
 "bolt":"питание","cloud":"в облаке","gear":"настройка","star":"важное","eye":"наблюдение",
 "question":"уточнить",
}
for form, title, badges in BADGED:
    for b in badges:
        if b not in BADGE:
            continue
        I(f"{form}-{b}", "Состояния объектов", f"{title} — {BADGE_TITLE.get(b,b)}",
          form, BASE_COLOR.get(form,"slate"), b)

# ── анимированные (во всех разделах) ────────────────────────────────
ANIMATED = [
 ("sync","Синхронизация","blue"),("upload","Отправка","emerald"),("download","Загрузка","sky"),
 ("cloud","Облако","sky"),("bell","Уведомление","amber"),("call","Звонок","green"),
 ("chat","Печатает","teal"),("gear","Настройка","slate"),("clock","Часы","indigo"),
 ("timer","Таймер","rose"),("hourglass","Песочные часы","amber"),("chart-bar","Столбцы","blue"),
 ("chart-line","График","emerald"),("chart-pie","Круговая","violet"),("chart-donut","Кольцевая","indigo"),
 ("gauge","Индикатор","amber"),("gantt","Диаграмма Ганта","blue"),("checklist","Список","green"),
 ("search","Поиск","sky"),("scan","Сканирование","cyan"),("shield","Защита","emerald"),
 ("lock","Замок","slate"),("key","Ключ","amber"),("fingerprint","Отпечаток","indigo"),
 ("bug","Ошибка","red"),("virus","Вредоносный код","rose"),("eye","Наблюдение","indigo"),
 ("fire","Срочно","orange"),("bolt","Электричество","amber"),("power","Питание","emerald"),
 ("battery","Заряд","green"),("rocket","Запуск","rose"),("bulb","Идея","amber"),
 ("star","Звезда","amber"),("heart","Избранное","rose"),("flag","Флаг","blue"),
 ("pin","Метка","red"),("globe","Мир","blue"),("compass","Направление","teal"),
 ("sun","День","amber"),("cloud-rain","Дождь","sky"),("snow","Снег","cyan"),
 ("drop","Капля","sky"),("leaf","Экология","green"),("atom","Атом","indigo"),
 ("brain","Мышление","pink"),("ai","Искусственный интеллект","violet"),("robot","Робот","indigo"),
 ("terminal","Терминал","slate"),("api","Обмен","teal"),("cable","Кабель","amber"),
 ("link","Ссылка","blue"),("box","Груз","brown"),("truck","Доставка","blue"),
 ("plane","Авиаперевозка","sky"),("ship","Морская перевозка","teal"),("crane","Кран","amber"),
 ("scale","Весы","stone"),("factory","Производство","stone"),("pump","Насос","cyan"),
 ("motor","Двигатель","slate"),("valve","Задвижка","teal"),("sensor","Датчик","lime"),
 ("thermo","Температура","red"),("flask","Лаборатория","purple"),("wrench","Гаечный ключ","slate"),
 ("printer","Печать","stone"),("hdd","Жёсткий диск","slate"),("cpu","Процессор","violet"),
 ("chip","Микросхема","purple"),("server","Сервер","slate"),("rack","Стойка","stone"),
 ("nas","Хранилище","cyan"),("db","База данных","blue"),("mic","Микрофон","violet"),
 ("video","Видеосвязь","rose"),("music","Звук","pink"),("hand","Рука","amber"),
 ("warning","Внимание","amber"),("check","Готово","green"),("arrow-right","Далее","blue"),
 ("arrow-up","Рост","emerald"),("target","Цель","rose"),("layers","Слои","violet"),
 ("folder-open","Папка открыта","orange"),("bookmark","Закладка","rose"),("filter","Фильтр","purple"),
 ("cart","Корзина","amber"),("dataflow","Поток данных","teal"),("proxy","Прокси","amber"),
 ("hub","Концентратор","slate"),("ap","Точка доступа","cyan"),("antenna","Антенна","blue"),
 ("wifi","Сигнал Wi-Fi","cyan"),("satellite","Спутник","violet"),("tower","Вышка","slate"),
 ("modem","Модем","stone"),("vpn","Туннель VPN","emerald"),("firewall","Межсетевой экран","red"),
 ("router","Маршрутизатор","blue"),("switch","Коммутатор","teal"),("balancer","Балансировщик","teal"),
 ("pc","Рабочая станция","slate"),("phone","Телефон","violet"),("shuffle","Перемешать","violet"),
]
for form, title, color in ANIMATED:
    I(f"{form}-anim", "Анимированные", title+" (анимация)", form, color, None, True)

# анимированные с накладкой — «идёт, но есть замечание»
ANIM_BADGED = [
 ("server","Сервер","warn"),("server","Сервер","sync"),("db","База данных","sync"),
 ("cloud","Облако","sync"),("cloud","Облако","warn"),("router","Маршрутизатор","warn"),
 ("switch","Коммутатор","warn"),("firewall","Межсетевой экран","warn"),("nas","Хранилище","sync"),
 ("pc","Рабочая станция","sync"),("code","Код","sync"),("container","Контейнер","sync"),
 ("api","Обмен","warn"),("truck","Доставка","clock"),("box","Груз","clock"),
 ("factory","Производство","warn"),("motor","Двигатель","warn"),("pump","Насос","warn"),
 ("sensor","Датчик","warn"),("thermo","Температура","warn"),("battery","Заряд","warn"),
 ("bulb","Идея","star"),("chart-bar","Столбцы","up"),("chart-line","График","down"),
 ("target","Цель","ok"),("checklist","Список","ok"),("gear","Настройка","warn"),
 ("shield","Защита","warn"),("lock","Замок","err"),("ai","Интеллект","gear"),
 ("robot","Робот","gear"),("printer","Печать","warn"),("rack","Стойка","bolt"),
 ("ap","Точка доступа","bolt"),("vpn","Туннель VPN","lock"),("mail","Письмо","clock"),
 ("chat","Обсуждение","plus"),("calendar","Календарь","clock"),("clock","Часы","warn"),
 ("money","Деньги","up"),("money","Деньги","down"),("scale","Весы","warn"),
 ("crane","Кран","ok"),("plane","Авиаперевозка","clock"),("ship","Перевозка","clock"),
]
for form, title, b in ANIM_BADGED:
    I(f"{form}-{b}-anim", "Анимированные · состояния",
      f"{title} — {BADGE_TITLE.get(b,b)} (анимация)", form,
      BASE_COLOR.get(form,"slate"), b, True)

# ═══════════════════ сборка модуля ═══════════════════════════════════
def build():
    seen, items, order = set(), {}, []
    for name, group, title, form, color, bdg, anim in CAT:
        if name in seen:
            continue
        fn = B.get(form)
        if fn is None:
            print("нет формы:", form, file=sys.stderr)
            continue
        body = fn(color, anim)
        if bdg and bdg in BADGE:
            body += BADGE[bdg](anim)
        # Значок, заявленный анимированным, но без анимации — это копия
        # статичного: у формы просто нечему двигаться. В набор он не
        # попадает, иначе в разделе «Анимированные» лежали бы
        # неподвижные картинки.
        if anim and "<animate" not in body:
            continue
        seen.add(name)
        items[name] = dict(title=title, group=group, body=body, anim=bool(anim))
        order.append((group, name))

    groups, gorder = {}, []
    for group, name in order:
        if group not in groups:
            groups[group] = []
            gorder.append(group)
        groups[group].append(name)

    out = []
    out.append('''// Набор значков для совместных досок. ФАЙЛ СОБРАН АВТОМАТИЧЕСКИ.
//
// Значки нарисованы для этого проекта: базовая форма (корпус, облако,
// документ, человек…), необязательная накладка-признак в углу
// (галочка, замок, молния…) и необязательная анимация. Такой приём
// принят в иконочных наборах — он даёт единый стиль и при этом
// настоящее разнообразие смыслов: «сервер», «сервер защищён», «сервер
// синхронизируется» вместо перекрашенных копий одного рисунка.
//
// Почему не сторонние наборы: значки icons8, Cisco и подобных
// защищены лицензией и товарным знаком, и встраивать их в исходный код
// нельзя. Формы сетевого оборудования здесь — общепринятые обозначения
// схем (цилиндр со стрелками, плоский корпус с портами), рисунок
// собственный. Свои наборы можно загрузить: в окне значков есть
// «Загрузить значки», в том числе папкой целиком, и поддерживаются
// SVG, PNG, APNG и GIF — анимация в них сохраняется.
//
// Анимация — штатная SMIL внутри SVG: работает без скриптов, в <img> и
// в вёрстке, и не требует ничего от сборки.
//
// Значки в координатах 0…64 по обеим осям.''')
    out.append("")
    out.append("const S = {")
    for name in items:
        b = items[name]["body"].replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")
        out.append(f'  {json_key(name)}: `{b}`,')
    out.append("};")
    out.append("")
    out.append("// Подписи значков.")
    out.append("const T = {")
    for name, it in items.items():
        out.append(f'  {json_key(name)}: {js_str(it["title"])},')
    out.append("};")
    out.append("")
    out.append("// Разделы панели значков, в порядке показа.")
    out.append("export const ICON_GROUPS = [")
    for g in gorder:
        out.append(f'  {{ title: {js_str(g)}, icons: [')
        for name in groups[g]:
            out.append(f'    [{js_str(name)}, T[{js_str(name)}]],')
        out.append("  ] },")
    out.append("];")
    out.append("")
    out.append("export const ICON_TITLES = T;")
    out.append("")
    out.append("// Какие значки анимированные — панель помечает их, чтобы выбор")
    out.append("// анимации был осознанным: на схеме для печати она не нужна.")
    out.append("export const ANIMATED_ICONS = new Set([")
    anim_names = [n for n, it in items.items() if it["anim"]]
    for i in range(0, len(anim_names), 6):
        out.append("  " + ", ".join(js_str(n) for n in anim_names[i:i+6]) + ",")
    out.append("]);")
    out.append("")
    out.append('''// Содержимое значка. Неизвестное имя даёт пустую строку, а не ошибку:
// значок мог исчезнуть из набора после обновления, а доска с ним —
// остаться.
export function iconBody(name) {
  return S[name] || "";
}

export function hasIcon(name) {
  return Boolean(S[name]);
}

export const ICON_COUNT = Object.keys(S).length;''')
    return "\n".join(out) + "\n", len(items), len(anim_names), gorder, groups

def json_key(s):
    return '"' + s + '"'
def js_str(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'

if __name__ == "__main__":
    text, n, na, gorder, groups = build()
    with open("/home/claude/proj/kanban/frontend/src/lib/boardIcons.js", "w", encoding="utf-8") as f:
        f.write(text)
    print(f"значков: {n}, анимированных: {na}")
    for g in gorder:
        print(f"  {g}: {len(groups[g])}")
