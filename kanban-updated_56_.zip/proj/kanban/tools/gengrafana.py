#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка дашбордов Grafana для «Команды».

Панели собираются из общих заготовок, поэтому оба дашборда выглядят
одинаково: та же сетка, те же единицы, та же палитра. Палитра
категориальная, проверенная на различимость при дальтонизме.
"""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "..", "deploy", "monitoring", "grafana", "dashboards")

DS = {"type": "prometheus", "uid": "${DS_PROMETHEUS}"}

# Проверенная категориальная палитра: порядок закреплён, не цикличный.
P = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7"]
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET = P

_id = [0]


def nid():
    _id[0] += 1
    return _id[0]


def tgt(expr, legend="", ref="A", instant=False, fmt="time_series"):
    t = {
        "datasource": DS,
        "editorMode": "code",
        "expr": expr,
        "legendFormat": legend or "__auto",
        "range": not instant,
        "instant": instant,
        "refId": ref,
    }
    if fmt != "time_series":
        t["format"] = fmt
    return t


REFS = "ABCDEFGH"


def targets(qs):
    out = []
    for i, q in enumerate(qs):
        if isinstance(q, str):
            out.append(tgt(q, ref=REFS[i]))
        else:
            expr, legend = q[0], q[1]
            extra = q[2] if len(q) > 2 else {}
            out.append(tgt(expr, legend, ref=REFS[i], **extra))
    return out


def overrides(colors):
    """Закрепляет цвет за конкретным рядом: цвет следует сущности."""
    return [
        {
            "matcher": {"id": "byName", "options": name},
            "properties": [{"id": "color", "value": {"mode": "fixed", "fixedColor": c}}],
        }
        for name, c in colors.items()
    ]


def base(title, gp, descr=""):
    return {
        "id": nid(),
        "title": title,
        "description": descr,
        "datasource": DS,
        "gridPos": gp,
    }


def ts(title, gp, qs, unit="short", descr="", stack=False, fill=8,
       colors=None, minv=None, maxv=None, width=2, legend="list",
       calcs=None, points=False, decimals=None):
    """График по времени. Тонкие линии, ненавязчивая сетка, легенда снизу."""
    p = base(title, gp, descr)
    p["type"] = "timeseries"
    p["targets"] = targets(qs)
    cust = {
        "drawStyle": "line",
        "lineInterpolation": "smooth",
        "lineWidth": width,
        "fillOpacity": fill if stack else (fill // 2 if fill else 0),
        "gradientMode": "opacity" if fill else "none",
        "showPoints": "always" if points else "never",
        "pointSize": 8,
        "spanNulls": True,
        "axisBorderShow": False,
        "axisGridShow": True,
        "stacking": {"mode": "normal" if stack else "none", "group": "A"},
        "thresholdsStyle": {"mode": "off"},
        "scaleDistribution": {"type": "linear"},
    }
    fc = {"unit": unit, "custom": cust,
          "color": {"mode": "palette-classic"},
          "thresholds": {"mode": "absolute", "steps": [{"color": "text", "value": None}]}}
    if minv is not None:
        fc["min"] = minv
    if maxv is not None:
        fc["max"] = maxv
    if decimals is not None:
        fc["decimals"] = decimals
    p["fieldConfig"] = {"defaults": fc, "overrides": overrides(colors or {})}
    p["options"] = {
        "legend": {"displayMode": legend, "placement": "bottom",
                   "showLegend": True,
                   "calcs": calcs or ([] if legend == "list" else ["mean", "max", "lastNotNull"])},
        "tooltip": {"mode": "multi", "sort": "desc"},
    }
    return p


def stat(title, gp, qs, unit="short", descr="", steps=None, graph=True,
         color=None, decimals=None, text_size=36, calc="lastNotNull"):
    p = base(title, gp, descr)
    p["type"] = "stat"
    p["targets"] = targets(qs)
    fc = {
        "unit": unit,
        "color": {"mode": "fixed", "fixedColor": color or BLUE} if not steps
        else {"mode": "thresholds"},
        "thresholds": {"mode": "absolute",
                       "steps": steps or [{"color": "text", "value": None}]},
        "mappings": [],
    }
    if decimals is not None:
        fc["decimals"] = decimals
    p["fieldConfig"] = {"defaults": fc, "overrides": []}
    p["options"] = {
        "colorMode": "value",
        "graphMode": "area" if graph else "none",
        "justifyMode": "auto",
        "orientation": "auto",
        "reduceOptions": {"calcs": [calc], "fields": "", "values": False},
        "textMode": "auto",
        "text": {"valueSize": text_size},
    }
    return p


def gauge(title, gp, qs, unit="percent", descr="", steps=None, maxv=100, minv=0):
    p = base(title, gp, descr)
    p["type"] = "gauge"
    p["targets"] = targets(qs)
    p["fieldConfig"] = {"defaults": {
        "unit": unit, "min": minv, "max": maxv, "decimals": 1,
        "color": {"mode": "thresholds"},
        "thresholds": {"mode": "absolute", "steps": steps or [
            {"color": GREEN, "value": None},
            {"color": YELLOW, "value": 70},
            {"color": ORANGE, "value": 85},
            {"color": "red", "value": 95}]},
    }, "overrides": []}
    p["options"] = {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                    "showThresholdLabels": False, "showThresholdMarkers": True}
    return p


def bars(title, gp, qs, unit="short", descr="", color=BLUE, steps=None,
         horiz=True, maxv=None):
    p = base(title, gp, descr)
    p["type"] = "bargauge"
    p["targets"] = targets(qs)
    fc = {"unit": unit, "min": 0,
          "color": {"mode": "fixed", "fixedColor": color} if not steps
          else {"mode": "thresholds"},
          "thresholds": {"mode": "absolute",
                         "steps": steps or [{"color": "text", "value": None}]}}
    if maxv is not None:
        fc["max"] = maxv
    p["fieldConfig"] = {"defaults": fc, "overrides": []}
    p["options"] = {
        "displayMode": "gradient",
        "orientation": "horizontal" if horiz else "vertical",
        "reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
        "showUnfilled": True,
        "valueMode": "color",
        "minVizHeight": 16, "minVizWidth": 8, "namePlacement": "left",
        "sizing": "auto",
    }
    return p


def heat(title, gp, expr, descr="", unit="s"):
    p = base(title, gp, descr)
    p["type"] = "heatmap"
    p["targets"] = [dict(tgt(expr, "{{le}}"), format="heatmap")]
    p["options"] = {
        "calculate": False,
        "cellGap": 2,
        "cellValues": {"unit": "short"},
        "color": {"mode": "scheme", "scheme": "Blues", "steps": 64,
                  "fill": BLUE, "exponent": 0.5, "reverse": False},
        "exemplars": {"color": ORANGE},
        "filterValues": {"le": 1e-09},
        "legend": {"show": True},
        "rowsFrame": {"layout": "auto", "value": "Запросов"},
        "tooltip": {"mode": "single", "showColorScale": True, "yHistogram": True},
        "yAxis": {"axisPlacement": "left", "reverse": False, "unit": unit},
    }
    p["fieldConfig"] = {"defaults": {"custom": {"hideFrom": {}, "scaleDistribution": {"type": "linear"}}},
                        "overrides": []}
    return p


def table(title, gp, qs, rename, units, descr="", sort_by=None, desc=True,
          cell_bars=()):
    p = base(title, gp, descr)
    p["type"] = "table"
    p["targets"] = [tgt(q[0], q[1], ref=REFS[i], instant=True, fmt="table")
                    for i, q in enumerate(qs)]
    p["transformations"] = [
        {"id": "filterFieldsByName", "options": {"exclude": {"pattern": "^Time$"}}},
        {"id": "joinByField", "options": {"byField": rename["__key"], "mode": "outer"}},
        {"id": "organize", "options": {"excludeByName": {}, "indexByName": {},
                                       "renameByName": {k: v for k, v in rename.items()
                                                        if k != "__key"}}},
    ]
    p["fieldConfig"] = {
        "defaults": {
            "custom": {"align": "auto", "cellOptions": {"type": "auto"},
                       "inspect": False, "filterable": True},
            "color": {"mode": "thresholds"},
            "thresholds": {"mode": "absolute", "steps": [{"color": "text", "value": None}]},
        },
        "overrides": [
            {"matcher": {"id": "byName", "options": name},
             "properties": [{"id": "unit", "value": u},
                            {"id": "decimals", "value": 2 if u in ("s", "percent") else 0}]}
            for name, u in units.items()
        ] + [
            {"matcher": {"id": "byName", "options": name},
             "properties": [{"id": "custom.cellOptions",
                             "value": {"type": "gauge", "mode": "gradient"}},
                            {"id": "color", "value": {"mode": "continuous-BlPu"}}]}
            for name in cell_bars
        ],
    }
    p["options"] = {"cellHeight": "sm", "footer": {"show": False, "reducer": ["sum"]},
                    "showHeader": True,
                    "sortBy": ([{"desc": desc, "displayName": sort_by}] if sort_by else [])}
    return p


def row(title, y):
    return {"id": nid(), "type": "row", "title": title, "collapsed": False,
            "gridPos": {"h": 1, "w": 24, "x": 0, "y": y}, "panels": []}


def gp(h, w, x, y):
    return {"h": h, "w": w, "x": x, "y": y}


def dash(uid, title, descr, panels, tags, refresh="10s"):
    return {
        "annotations": {"list": [{
            "builtIn": 1, "type": "dashboard", "hide": True,
            "name": "Annotations & Alerts",
            "datasource": {"type": "grafana", "uid": "-- Grafana --"},
            "iconColor": "rgba(0, 211, 255, 1)", "enable": True,
        }]},
        "editable": True,
        "fiscalYearStartMonth": 0,
        "graphTooltip": 1,
        "links": [],
        "panels": panels,
        "preload": False,
        "refresh": refresh,
        "schemaVersion": 39,
        "tags": tags,
        "templating": {"list": [{
            # Источник данных — переменная: дашборд одинаково работает и при
            # автоматической раскладке файлами, и при импорте руками.
            "name": "DS_PROMETHEUS", "label": "Источник данных",
            "type": "datasource", "query": "prometheus",
            "current": {}, "options": [], "refresh": 1, "regex": "", "hide": 0,
        }, {
            "name": "instance", "label": "Экземпляр", "type": "query",
            "datasource": DS,
            "definition": "label_values(kanban_uptime_seconds, instance)",
            "query": {"query": "label_values(kanban_uptime_seconds, instance)",
                      "refId": "StandardVariableQuery"},
            "multi": True, "includeAll": True, "allValue": ".*",
            "current": {"selected": True, "text": ["All"], "value": ["$__all"]},
            "options": [], "refresh": 2, "sort": 1, "hide": 0,
        }]},
        "time": {"from": "now-6h", "to": "now"},
        "timepicker": {"refresh_intervals": ["5s", "10s", "30s", "1m", "5m", "15m"]},
        "timezone": "browser",
        "title": title,
        "description": descr,
        "uid": uid,
        "version": 1,
        "weekStart": "",
    }


I = '{instance=~"$instance"}'


def lb(extra=""):
    """Селектор с фильтром по экземпляру и дополнительными метками."""
    inner = 'instance=~"$instance"' + (("," + extra) if extra else "")
    return "{" + inner + "}"


# ══════════════════════ дашборд приложения ══════════════════════════
def app_dashboard():
    _id[0] = 0
    RI = "$__rate_interval"
    req = "kanban_http_requests_total"
    dur = "kanban_http_request_duration_seconds"
    sz = "kanban_http_response_bytes"
    L5 = lb("status=~'5..'")
    L45 = lb("status=~'[45]..'")
    L23 = lb("status=~'[23]..'")
    P_ = []

    y = 0
    P_.append(row("Сводка", y)); y += 1
    P_.append(stat("Запросов в секунду", gp(5, 4, 0, y),
                   [(f"sum(rate({req}{lb()}[{RI}]))", "RPS")],
                   unit="reqps", decimals=2, color=BLUE,
                   descr="Суммарный поток запросов ко всем маршрутам."))
    P_.append(stat("Доля ошибок", gp(5, 4, 4, y),
                   [(f'100 * sum(rate({req}{L5}[{RI}]))'
                     f' / clamp_min(sum(rate({req}{lb()}[{RI}])), 0.0001)', "5xx")],
                   unit="percent", decimals=2,
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 1},
                          {"color": ORANGE, "value": 3},
                          {"color": "red", "value": 5}],
                   descr="Доля ответов 5xx в общем потоке."))
    P_.append(stat("Задержка p95", gp(5, 4, 8, y),
                   [(f"histogram_quantile(0.95, sum by (le) "
                     f"(rate({dur}_bucket{lb()}[{RI}])))", "p95")],
                   unit="s", decimals=3,
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 0.3},
                          {"color": ORANGE, "value": 1},
                          {"color": "red", "value": 3}],
                   descr="95 % запросов обрабатываются быстрее этого времени."))
    P_.append(stat("Задержка p99", gp(5, 4, 12, y),
                   [(f"histogram_quantile(0.99, sum by (le) "
                     f"(rate({dur}_bucket{lb()}[{RI}])))", "p99")],
                   unit="s", decimals=3,
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 1},
                          {"color": ORANGE, "value": 3},
                          {"color": "red", "value": 10}]))
    P_.append(stat("Запросов в обработке", gp(5, 4, 16, y),
                   [(f"sum(kanban_http_requests_in_flight{lb()})", "сейчас")],
                   color=VIOLET, descr="Сколько запросов выполняется прямо сейчас."))
    P_.append(stat("Время работы", gp(5, 4, 20, y),
                   [(f"max(kanban_uptime_seconds{lb()})", "uptime")],
                   unit="dtdurations", graph=False, color=AQUA, text_size=26,
                   descr="Время с последнего перезапуска."))
    y += 5

    P_.append(row("Поток запросов", y)); y += 1
    P_.append(ts("Запросы по маршрутам", gp(9, 16, 0, y),
                 [(f"topk(10, sum by (route) (rate({req}{lb()}[{RI}])))", "{{route}}")],
                 unit="reqps", legend="table", calcs=["mean", "max", "lastNotNull"],
                 descr="Десять самых нагруженных маршрутов. Метка route — шаблон "
                       "маршрута, а не конкретный путь: иначе метки Prometheus не "
                       "выдержат числа задач."))
    P_.append(ts("Запросы по статусам", gp(9, 8, 16, y),
                 [(f'sum by (status) (rate({req}{lb()}[{RI}]))', "{{status}}")],
                 unit="reqps", stack=True, fill=70,
                 colors={"200": GREEN, "201": AQUA, "204": AQUA, "304": BLUE,
                         "400": YELLOW, "401": YELLOW, "403": ORANGE,
                         "404": ORANGE, "409": ORANGE, "422": ORANGE,
                         "429": MAGENTA, "500": "red", "502": "red", "503": "red"},
                 descr="Накопительно: видно и общий поток, и вклад ошибок."))
    y += 9

    P_.append(ts("Перцентили времени ответа", gp(8, 12, 0, y),
                 [(f"histogram_quantile(0.5, sum by (le) (rate({dur}_bucket{lb()}[{RI}])))", "p50"),
                  (f"histogram_quantile(0.9, sum by (le) (rate({dur}_bucket{lb()}[{RI}])))", "p90"),
                  (f"histogram_quantile(0.95, sum by (le) (rate({dur}_bucket{lb()}[{RI}])))", "p95"),
                  (f"histogram_quantile(0.99, sum by (le) (rate({dur}_bucket{lb()}[{RI}])))", "p99"),
                  (f"sum(rate({dur}_sum{lb()}[{RI}])) / clamp_min(sum(rate({dur}_count{lb()}[{RI}])), 0.0001)", "среднее")],
                 unit="s", minv=0,
                 colors={"p50": BLUE, "p90": AQUA, "p95": ORANGE, "p99": "red",
                         "среднее": VIOLET},
                 descr="Среднее прячет выбросы, поэтому рядом с ним — перцентили."))
    P_.append(heat("Распределение времени ответа", gp(8, 12, 12, y),
                   f"sum by (le) (rate({dur}_bucket{lb()}[{RI}]))",
                   descr="Тёмная полоса — где сосредоточена основная масса "
                         "запросов; отдельные пятна вверху — выбросы."))
    y += 8

    P_.append(table("Маршруты: нагрузка и задержка", gp(9, 14, 0, y),
                    [(f"topk(15, sum by (route) (rate({req}{lb()}[{RI}])))", "{{route}}"),
                     (f"sum by (route) (rate({dur}_sum{lb()}[{RI}])) / clamp_min(sum by (route) (rate({dur}_count{lb()}[{RI}])), 0.0001)", ""),
                     (f"histogram_quantile(0.95, sum by (le, route) (rate({dur}_bucket{lb()}[{RI}])))", ""),
                     (f"histogram_quantile(0.99, sum by (le, route) (rate({dur}_bucket{lb()}[{RI}])))", ""),
                     (f'sum by (route) (rate({req}{L45}[{RI}]))', "")],
                    rename={"__key": "route", "route": "Маршрут",
                            "Value #A": "Запросов/с", "Value #B": "Среднее",
                            "Value #C": "p95", "Value #D": "p99",
                            "Value #E": "Ошибок/с"},
                    units={"Запросов/с": "reqps", "Среднее": "s", "p95": "s",
                           "p99": "s", "Ошибок/с": "reqps"},
                    sort_by="Запросов/с", cell_bars=("Запросов/с",),
                    descr="Сводная таблица по маршрутам: сортируется по любой колонке."))
    P_.append(bars("Самые медленные маршруты (p95)", gp(9, 10, 14, y),
                   [(f"topk(10, histogram_quantile(0.95, sum by (le, route) "
                     f"(rate({dur}_bucket{lb()}[{RI}]))))", "{{route}}")],
                   unit="s", steps=[{"color": GREEN, "value": None},
                                    {"color": YELLOW, "value": 0.3},
                                    {"color": ORANGE, "value": 1},
                                    {"color": "red", "value": 3}],
                   descr="Куда смотреть в первую очередь при жалобах на скорость."))
    y += 9

    P_.append(row("Ошибки", y)); y += 1
    P_.append(ts("Ошибки по маршрутам", gp(8, 12, 0, y),
                 [(f'topk(10, sum by (route, status) (rate({req}{L45}[{RI}])))',
                   "{{status}} {{route}}")],
                 unit="reqps", stack=True, fill=70))
    P_.append(ts("Доля успешных ответов", gp(8, 12, 12, y),
                 [(f'100 * sum(rate({req}{L23}[{RI}]))'
                   f' / clamp_min(sum(rate({req}{lb()}[{RI}])), 0.0001)', "успешно")],
                 unit="percent", minv=0, maxv=100, fill=16,
                 colors={"успешно": GREEN},
                 descr="Полка ниже 100 % — повод посмотреть левый график."))
    y += 8

    P_.append(row("Ответы и трафик", y)); y += 1
    P_.append(ts("Размер ответа", gp(8, 12, 0, y),
                 [(f"histogram_quantile(0.5, sum by (le) (rate({sz}_bucket{lb()}[{RI}])))", "p50"),
                  (f"histogram_quantile(0.95, sum by (le) (rate({sz}_bucket{lb()}[{RI}])))", "p95"),
                  (f"histogram_quantile(0.99, sum by (le) (rate({sz}_bucket{lb()}[{RI}])))", "p99")],
                 unit="bytes", minv=0,
                 colors={"p50": BLUE, "p95": ORANGE, "p99": "red"}))
    P_.append(ts("Исходящий трафик", gp(8, 12, 12, y),
                 [(f"sum(rate({sz}_sum{lb()}[{RI}]))", "всего"),
                  (f"topk(5, sum by (route) (rate({sz}_sum{lb()}[{RI}])))", "{{route}}")],
                 unit="Bps", colors={"всего": VIOLET},
                 descr="Сколько байт в секунду отдаёт приложение и какие "
                       "маршруты дают основной объём."))
    y += 8

    P_.append(row("Совместная работа", y)); y += 1
    P_.append(ts("События WebSocket", gp(8, 12, 0, y),
                 [(f"sum by (type) (rate(kanban_ws_events_total{lb()}[{RI}]))", "{{type}}")],
                 unit="ops", stack=True, fill=70,
                 descr="Поток событий реального времени: доски, чат, "
                       "уведомления."))
    P_.append(ts("Подключения", gp(8, 6, 12, y),
                 [(f"sum(kanban_ws_connections{lb()})", "соединений"),
                  (f"sum(kanban_ws_users{lb()})", "пользователей")],
                 fill=16, colors={"соединений": BLUE, "пользователей": AQUA},
                 descr="У одного пользователя может быть несколько вкладок, "
                       "поэтому соединений обычно больше."))
    P_.append(ts("Прикладные события", gp(8, 6, 18, y),
                 [(f"sum by (event) (rate(kanban_app_events_total{lb()}[{RI}]))", "{{event}}")],
                 unit="ops", stack=True, fill=70))
    y += 8

    P_.append(bars("Объектов в системе", gp(9, 24, 0, y),
                   [(f"kanban_entities{lb()}", "{{kind}}")],
                   color=VIOLET,
                   descr="Счётчики снимаются с базы раз в 15 секунд: "
                         "задачи, проекты, комментарии, файлы и прочее."))

    return dash("kanban-app", "Команда · приложение",
                "Время исполнения запросов, RPS, ошибки, события реального "
                "времени. Данные снимает встроенный экспортёр /metrics.",
                P_, ["kanban", "команда", "приложение"])


# ══════════════════════ дашборд базы данных ═════════════════════════
def db_dashboard():
    _id[0] = 0
    RI = "$__rate_interval"
    P_ = []
    y = 0

    P_.append(row("Сводка", y)); y += 1
    P_.append(stat("Размер базы", gp(5, 4, 0, y),
                   [(f"max(pg_database_size_bytes{lb()})", "{{datname}}")],
                   unit="bytes", color=BLUE))
    P_.append(stat("Попадания в кэш", gp(5, 4, 4, y),
                   [(f"100 * sum(rate(pg_blks_hit_total{lb()}[{RI}])) / "
                     f"clamp_min(sum(rate(pg_blks_hit_total{lb()}[{RI}])) + "
                     f"sum(rate(pg_blks_read_total{lb()}[{RI}])), 0.0001)", "hit ratio")],
                   unit="percent", decimals=2,
                   steps=[{"color": "red", "value": None},
                          {"color": ORANGE, "value": 90},
                          {"color": YELLOW, "value": 97},
                          {"color": GREEN, "value": 99}],
                   descr="Ниже 99 % на устоявшейся нагрузке — мало shared_buffers "
                         "либо не хватает индексов."))
    P_.append(stat("Соединений", gp(5, 4, 8, y),
                   [(f"sum(pg_connections{lb()})", "занято"),
                    (f"max(pg_max_connections{lb()})", "предел")],
                   color=VIOLET))
    P_.append(stat("Доля откатов", gp(5, 4, 12, y),
                   [(f"100 * sum(rate(pg_xact_rollback_total{lb()}[{RI}])) / "
                     f"clamp_min(sum(rate(pg_xact_commit_total{lb()}[{RI}])) + "
                     f"sum(rate(pg_xact_rollback_total{lb()}[{RI}])), 0.0001)", "rollback")],
                   unit="percent", decimals=2,
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 2},
                          {"color": ORANGE, "value": 5},
                          {"color": "red", "value": 10}]))
    P_.append(stat("Самая долгая транзакция", gp(5, 4, 16, y),
                   [(f"max(pg_longest_transaction_seconds{lb()})", "сек")],
                   unit="s", decimals=1,
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 5},
                          {"color": ORANGE, "value": 30},
                          {"color": "red", "value": 120}],
                   descr="Долгая транзакция держит снимок и мешает VACUUM."))
    P_.append(stat("Блокировок в ожидании", gp(5, 4, 20, y),
                   [(f"sum(pg_locks_waiting{lb()})", "ждут")],
                   steps=[{"color": GREEN, "value": None},
                          {"color": YELLOW, "value": 1},
                          {"color": "red", "value": 5}]))
    y += 5

    P_.append(row("Пул соединений приложения", y)); y += 1
    P_.append(ts("Соединения пула", gp(8, 12, 0, y),
                 [(f"sum(kanban_db_pool_total{lb()})", "всего"),
                  (f"sum(kanban_db_pool_acquired{lb()})", "занято"),
                  (f"sum(kanban_db_pool_idle{lb()})", "свободно"),
                  (f"max(kanban_db_pool_max{lb()})", "предел")],
                 minv=0, fill=10,
                 colors={"всего": BLUE, "занято": ORANGE, "свободно": AQUA,
                         "предел": MAGENTA},
                 descr="«Занято» вплотную к «пределу» — запросы начнут ждать "
                       "свободное соединение."))
    P_.append(gauge("Загрузка пула", gp(8, 5, 12, y),
                    [(f"100 * sum(kanban_db_pool_acquired{lb()}) / "
                      f"clamp_min(sum(kanban_db_pool_max{lb()}), 1)", "занято")],
                    descr="Доля занятых соединений от предела пула."))
    P_.append(ts("Ожидания пустого пула", gp(8, 7, 17, y),
                 [(f"sum(rate(kanban_db_pool_empty_acquires{lb()}[{RI}]))", "ожиданий/с")],
                 unit="ops", colors={"ожиданий/с": ORANGE}, fill=16,
                 descr="Каждое ожидание — задержка запроса. Если линия не на "
                       "нуле, пул пора увеличивать."))
    y += 8

    P_.append(ts("Транзакции приложения", gp(8, 12, 0, y),
                 [(f"sum by (op) (rate(kanban_db_queries_total{lb()}[{RI}]))", "{{op}}")],
                 unit="ops", stack=True, fill=70,
                 descr="op — крупная операция (транзакция пользователя или "
                       "служебная), а не текст запроса."))
    P_.append(ts("Время транзакции", gp(8, 12, 12, y),
                 [(f"histogram_quantile(0.5, sum by (le) (rate(kanban_db_query_duration_seconds_bucket{lb()}[{RI}])))", "p50"),
                  (f"histogram_quantile(0.95, sum by (le) (rate(kanban_db_query_duration_seconds_bucket{lb()}[{RI}])))", "p95"),
                  (f"histogram_quantile(0.99, sum by (le) (rate(kanban_db_query_duration_seconds_bucket{lb()}[{RI}])))", "p99"),
                  (f"histogram_quantile(0.95, sum by (le, op) (rate(kanban_db_query_duration_seconds_bucket{lb()}[{RI}])))", "p95 {{op}}")],
                 unit="s", minv=0,
                 colors={"p50": BLUE, "p95": ORANGE, "p99": "red"}))
    y += 8

    P_.append(ts("Ошибки при работе с базой", gp(6, 12, 0, y),
                 [(f"sum(rate(kanban_db_errors_total{lb()}[{RI}]))", "ошибок/с")],
                 unit="ops", colors={"ошибок/с": "red"}, fill=16))
    P_.append(ts("Взаимные блокировки", gp(6, 12, 12, y),
                 [(f"sum(rate(pg_deadlocks_total{lb()}[{RI}]))", "deadlock/с")],
                 unit="ops", colors={"deadlock/с": "red"}, fill=16,
                 descr="Любое ненулевое значение требует разбора: два "
                       "обработчика берут блокировки в разном порядке."))
    y += 6

    P_.append(row("PostgreSQL", y)); y += 1
    P_.append(ts("Фиксации и откаты", gp(8, 8, 0, y),
                 [(f"sum(rate(pg_xact_commit_total{lb()}[{RI}]))", "commit"),
                  (f"sum(rate(pg_xact_rollback_total{lb()}[{RI}]))", "rollback")],
                 unit="ops", colors={"commit": GREEN, "rollback": ORANGE}, fill=16))
    P_.append(ts("Блоки: кэш и диск", gp(8, 8, 8, y),
                 [(f"sum(rate(pg_blks_hit_total{lb()}[{RI}]))", "из кэша"),
                  (f"sum(rate(pg_blks_read_total{lb()}[{RI}]))", "с диска")],
                 unit="ops", colors={"из кэша": AQUA, "с диска": ORANGE}, fill=16))
    P_.append(ts("Строки", gp(8, 8, 16, y),
                 [(f"sum(rate(pg_tup_returned_total{lb()}[{RI}]))", "просмотрено"),
                  (f"sum(rate(pg_tup_fetched_total{lb()}[{RI}]))", "возвращено")],
                 unit="ops", colors={"просмотрено": BLUE, "возвращено": GREEN},
                 fill=16,
                 descr="Большой разрыв между линиями — запросы читают лишнее: "
                       "скорее всего не хватает индекса."))
    y += 8

    P_.append(ts("Соединения по состоянию", gp(8, 12, 0, y),
                 [(f"sum by (state) (pg_connections{lb()})", "{{state}}")],
                 stack=True, fill=70,
                 colors={"active": BLUE, "idle": AQUA,
                         "idle in transaction": ORANGE,
                         "idle in transaction (aborted)": "red"}))
    P_.append(ts("Долгие операции", gp(8, 12, 12, y),
                 [(f"max(pg_longest_query_seconds{lb()})", "запрос"),
                  (f"max(pg_longest_transaction_seconds{lb()})", "транзакция"),
                  (f"max(pg_idle_in_transaction_seconds{lb()})", "простой в транзакции")],
                 unit="s", minv=0,
                 colors={"запрос": BLUE, "транзакция": ORANGE,
                         "простой в транзакции": "red"},
                 descr="«Простой в транзакции» — открытая транзакция без "
                       "работы: держит блокировки и тормозит очистку."))
    y += 8

    P_.append(row("Таблицы", y)); y += 1
    P_.append(table("Таблицы: объём и очистка", gp(10, 14, 0, y),
                    [("topk(20, pg_table_size_bytes" + lb() + ")", "{{table}}"),
                     ("pg_table_live_rows" + lb(), ""),
                     ("pg_table_dead_rows" + lb(), ""),
                     ("100 * pg_table_dead_rows" + lb() + " / clamp_min(pg_table_live_rows" + lb() + " + pg_table_dead_rows" + lb() + ", 1)", ""),
                     ("pg_table_vacuum_age_seconds" + lb(), "")],
                    rename={"__key": "table", "table": "Таблица",
                            "Value #A": "Размер", "Value #B": "Живых строк",
                            "Value #C": "Мёртвых строк", "Value #D": "Мёртвых, %",
                            "Value #E": "Очистка была"},
                    units={"Размер": "bytes", "Живых строк": "short",
                           "Мёртвых строк": "short", "Мёртвых, %": "percent",
                           "Очистка была": "dtdurations"},
                    sort_by="Размер", cell_bars=("Размер",),
                    descr="Двадцать крупнейших таблиц схемы app. Высокая доля "
                          "мёртвых строк вместе со старой очисткой — autovacuum "
                          "не справляется."))
    P_.append(bars("Крупнейшие таблицы", gp(10, 10, 14, y),
                   [("topk(12, pg_table_size_bytes" + lb() + ")", "{{table}}")],
                   unit="bytes", color=BLUE))
    y += 10

    P_.append(ts("Чтения: последовательные и по индексу", gp(8, 12, 0, y),
                 [("topk(8, sum by (table) (rate(pg_table_seq_scan_total" + lb() + f"[{RI}])))",
                   "seq {{table}}"),
                  ("topk(8, sum by (table) (rate(pg_table_idx_scan_total" + lb() + f"[{RI}])))",
                   "idx {{table}}")],
                 unit="ops",
                 descr="Растущие seq-чтения по большой таблице — прямой "
                       "указатель на отсутствующий индекс."))
    P_.append(bars("Мёртвые строки", gp(8, 6, 12, y),
                   [("topk(10, pg_table_dead_rows" + lb() + ")", "{{table}}")],
                   color=ORANGE))
    P_.append(bars("Давность очистки", gp(8, 6, 18, y),
                   [("topk(10, pg_table_vacuum_age_seconds" + lb() + ")", "{{table}}")],
                   unit="s", steps=[{"color": GREEN, "value": None},
                                    {"color": YELLOW, "value": 86400},
                                    {"color": ORANGE, "value": 259200},
                                    {"color": "red", "value": 604800}]))

    return dash("kanban-db", "Команда · база данных",
                "Пул соединений, время транзакций, кэш, блокировки, объём и "
                "очистка таблиц PostgreSQL.",
                P_, ["kanban", "команда", "postgresql"], refresh="30s")


os.makedirs(OUT, exist_ok=True)
for name, d in (("kanban-app.json", app_dashboard()),
                ("kanban-db.json", db_dashboard())):
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(name, "панелей:", sum(1 for p in d["panels"] if p["type"] != "row"))
