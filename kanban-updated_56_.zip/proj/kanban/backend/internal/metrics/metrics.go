// Package metrics — сбор и выдача метрик в формате Prometheus.
//
// Почему без prometheus/client_golang: библиотека тянет protobuf,
// expfmt и ещё десяток модулей. Приложение собирается одной командой на
// машине без доступа в интернет — это его свойство, и терять его ради
// того, что здесь занимает триста строк, не стоит. Формат выдачи
// текстовый и описан публично; ничего, кроме счётчиков, гистограмм и
// датчиков, нам не нужно.
//
// Что собирается:
//
//   - запросы: число, длительность по гистограмме, размер ответа,
//     сколько сейчас в обработке — с разбивкой по методу, маршруту и
//     коду ответа;
//   - база: состояние пула соединений, время и число запросов к ней;
//   - WebSocket: живые соединения и отправленные события;
//   - прикладное: уведомления, вход в систему, загрузки файлов.
//
// Маршрут в метках — это ШАБЛОН роута (/api/tasks/:taskID), а не
// фактический путь. С фактическими путями метки размножаются по числу
// задач в системе, и Prometheus такую серию не выдержит.
package metrics

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Границы гистограммы длительности, в секундах.
//
// Подобраны под веб-приложение: основная масса ответов укладывается в
// 5–50 мс, поэтому в этой области ступени частые, а дальше идут редкие
// — до десяти секунд, после которых запрос уже всё равно считается
// неудачным.
var durationBuckets = []float64{
	0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10,
}

// Границы гистограммы размера ответа, в байтах: от крошечного JSON до
// выгрузки на десятки мегабайт.
var sizeBuckets = []float64{
	256, 1024, 4096, 16384, 65536, 262144, 1048576, 4194304, 16777216,
}

type labels struct {
	method string
	route  string
	status string
}

func (l labels) key() string { return l.method + "\x00" + l.route + "\x00" + l.status }

// histogram — счётчики по ступеням плюс сумма и общее число.
//
// Хранится в целых числах: суммы наносекунд и байтов складываются
// атомарно, без блокировок. Для float64 пришлось бы брать мьютекс на
// каждый запрос.
type histogram struct {
	counts []uint64 // по ступеням, без последней «+Inf»
	total  uint64
	sumNs  uint64 // сумма в наносекундах либо байтах
}

func newHistogram(n int) *histogram {
	return &histogram{counts: make([]uint64, n)}
}

func (h *histogram) observe(v float64, bounds []float64, scale float64) {
	atomic.AddUint64(&h.total, 1)
	atomic.AddUint64(&h.sumNs, uint64(v*scale))
	// Линейный поиск: ступеней чуть больше десятка, и он быстрее
	// двоичного на таких размерах.
	for i, b := range bounds {
		if v <= b {
			atomic.AddUint64(&h.counts[i], 1)
			return
		}
	}
	// Больше последней границы — попадает только в «+Inf», то есть в
	// total, который уже увеличен.
}

// Registry хранит все метрики приложения.
type Registry struct {
	mu sync.RWMutex

	// Запросы.
	reqTotal    map[string]*uint64     // method|route|status → число
	reqDuration map[string]*histogram  // method|route → длительность
	reqSize     map[string]*histogram  // method|route → размер ответа
	reqInFlight int64                  // сейчас в обработке

	// База данных.
	dbQueries  map[string]*uint64    // операция → число
	dbDuration map[string]*histogram // операция → длительность
	dbErrors   uint64

	// WebSocket и прикладное.
	wsEvents   map[string]*uint64 // тип события → число
	appCounter map[string]*uint64 // произвольные прикладные счётчики

	// Датчики заполняются перед выдачей — их значения живут не здесь,
	// а в пуле соединений и хабе.
	gaugeFn map[string]func() float64

	started time.Time
}

func New() *Registry {
	return &Registry{
		reqTotal:    map[string]*uint64{},
		reqDuration: map[string]*histogram{},
		reqSize:     map[string]*histogram{},
		dbQueries:   map[string]*uint64{},
		dbDuration:  map[string]*histogram{},
		wsEvents:    map[string]*uint64{},
		appCounter:  map[string]*uint64{},
		gaugeFn:     map[string]func() float64{},
		started:     time.Now(),
	}
}

// Gauge регистрирует датчик, значение которого считывается в момент
// выдачи метрик: состояние пула соединений и число живых сокетов
// меняются постоянно, и копить их историю в приложении незачем.
func (r *Registry) Gauge(name string, fn func() float64) {
	r.mu.Lock()
	r.gaugeFn[name] = fn
	r.mu.Unlock()
}

func (r *Registry) counter(m map[string]*uint64, key string) *uint64 {
	r.mu.RLock()
	c, ok := m[key]
	r.mu.RUnlock()
	if ok {
		return c
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if c, ok = m[key]; ok {
		return c
	}
	c = new(uint64)
	m[key] = c
	return c
}

func (r *Registry) hist(m map[string]*histogram, key string, n int) *histogram {
	r.mu.RLock()
	h, ok := m[key]
	r.mu.RUnlock()
	if ok {
		return h
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if h, ok = m[key]; ok {
		return h
	}
	h = newHistogram(n)
	m[key] = h
	return h
}

// ── запросы ──────────────────────────────────────────────────────────

func (r *Registry) RequestStarted() { atomic.AddInt64(&r.reqInFlight, 1) }
func (r *Registry) RequestEnded()   { atomic.AddInt64(&r.reqInFlight, -1) }

// Request записывает завершённый запрос.
func (r *Registry) Request(method, route string, status int, d time.Duration, size int) {
	l := labels{method: method, route: route, status: strconv.Itoa(status)}
	atomic.AddUint64(r.counter(r.reqTotal, l.key()), 1)

	mr := method + "\x00" + route
	r.hist(r.reqDuration, mr, len(durationBuckets)).
		observe(d.Seconds(), durationBuckets, float64(time.Second))
	if size > 0 {
		r.hist(r.reqSize, mr, len(sizeBuckets)).
			observe(float64(size), sizeBuckets, 1)
	}
}

// ── база данных ──────────────────────────────────────────────────────

// DBQuery записывает обращение к базе. op — крупная операция («tx»,
// «service_tx»), а не текст запроса: текстов тысячи, и метки по ним
// Prometheus не выдержит.
func (r *Registry) DBQuery(op string, d time.Duration, err bool) {
	atomic.AddUint64(r.counter(r.dbQueries, op), 1)
	r.hist(r.dbDuration, op, len(durationBuckets)).
		observe(d.Seconds(), durationBuckets, float64(time.Second))
	if err {
		atomic.AddUint64(&r.dbErrors, 1)
	}
}

// ── события и прикладные счётчики ────────────────────────────────────

func (r *Registry) WSEvent(kind string) {
	atomic.AddUint64(r.counter(r.wsEvents, kind), 1)
}

// Inc — прикладной счётчик: уведомления, входы, загрузки файлов.
func (r *Registry) Inc(name string) {
	atomic.AddUint64(r.counter(r.appCounter, name), 1)
}

// ── выдача ───────────────────────────────────────────────────────────

func esc(v string) string {
	v = strings.ReplaceAll(v, `\`, `\\`)
	v = strings.ReplaceAll(v, `"`, `\"`)
	v = strings.ReplaceAll(v, "\n", `\n`)
	return v
}

// Render возвращает все метрики в текстовом формате Prometheus.
func (r *Registry) Render() string {
	r.mu.RLock()
	defer r.mu.RUnlock()

	var b strings.Builder

	// Запросы: число.
	b.WriteString("# HELP kanban_http_requests_total Обработано HTTP-запросов\n")
	b.WriteString("# TYPE kanban_http_requests_total counter\n")
	for _, k := range sortedKeys(r.reqTotal) {
		p := strings.Split(k, "\x00")
		fmt.Fprintf(&b, "kanban_http_requests_total{method=\"%s\",route=\"%s\",status=\"%s\"} %d\n",
			esc(p[0]), esc(p[1]), esc(p[2]), atomic.LoadUint64(r.reqTotal[k]))
	}

	// Запросы: длительность.
	b.WriteString("# HELP kanban_http_request_duration_seconds Время обработки запроса\n")
	b.WriteString("# TYPE kanban_http_request_duration_seconds histogram\n")
	for _, k := range sortedHistKeys(r.reqDuration) {
		p := strings.Split(k, "\x00")
		lbl := fmt.Sprintf("method=\"%s\",route=\"%s\"", esc(p[0]), esc(p[1]))
		writeHistogram(&b, "kanban_http_request_duration_seconds", lbl,
			r.reqDuration[k], durationBuckets, float64(time.Second))
	}

	// Запросы: размер ответа.
	b.WriteString("# HELP kanban_http_response_bytes Размер ответа\n")
	b.WriteString("# TYPE kanban_http_response_bytes histogram\n")
	for _, k := range sortedHistKeys(r.reqSize) {
		p := strings.Split(k, "\x00")
		lbl := fmt.Sprintf("method=\"%s\",route=\"%s\"", esc(p[0]), esc(p[1]))
		writeHistogram(&b, "kanban_http_response_bytes", lbl, r.reqSize[k], sizeBuckets, 1)
	}

	b.WriteString("# HELP kanban_http_requests_in_flight Запросов в обработке сейчас\n")
	b.WriteString("# TYPE kanban_http_requests_in_flight gauge\n")
	fmt.Fprintf(&b, "kanban_http_requests_in_flight %d\n", atomic.LoadInt64(&r.reqInFlight))

	// База.
	b.WriteString("# HELP kanban_db_queries_total Транзакций к базе\n")
	b.WriteString("# TYPE kanban_db_queries_total counter\n")
	for _, k := range sortedKeys(r.dbQueries) {
		fmt.Fprintf(&b, "kanban_db_queries_total{op=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.dbQueries[k]))
	}
	b.WriteString("# HELP kanban_db_query_duration_seconds Время транзакции к базе\n")
	b.WriteString("# TYPE kanban_db_query_duration_seconds histogram\n")
	for _, k := range sortedHistKeys(r.dbDuration) {
		writeHistogram(&b, "kanban_db_query_duration_seconds",
			fmt.Sprintf("op=\"%s\"", esc(k)), r.dbDuration[k],
			durationBuckets, float64(time.Second))
	}
	b.WriteString("# HELP kanban_db_errors_total Ошибок при работе с базой\n")
	b.WriteString("# TYPE kanban_db_errors_total counter\n")
	fmt.Fprintf(&b, "kanban_db_errors_total %d\n", atomic.LoadUint64(&r.dbErrors))

	// События.
	b.WriteString("# HELP kanban_ws_events_total Отправлено событий по WebSocket\n")
	b.WriteString("# TYPE kanban_ws_events_total counter\n")
	for _, k := range sortedKeys(r.wsEvents) {
		fmt.Fprintf(&b, "kanban_ws_events_total{type=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.wsEvents[k]))
	}

	// Прикладные счётчики.
	b.WriteString("# HELP kanban_app_events_total Прикладные события\n")
	b.WriteString("# TYPE kanban_app_events_total counter\n")
	for _, k := range sortedKeys(r.appCounter) {
		fmt.Fprintf(&b, "kanban_app_events_total{event=\"%s\"} %d\n",
			esc(k), atomic.LoadUint64(r.appCounter[k]))
	}

	// Датчики.
	for _, name := range sortedGauges(r.gaugeFn) {
		fmt.Fprintf(&b, "# TYPE %s gauge\n%s %g\n", name, name, r.gaugeFn[name]())
	}

	b.WriteString("# HELP kanban_uptime_seconds Время работы процесса\n")
	b.WriteString("# TYPE kanban_uptime_seconds gauge\n")
	fmt.Fprintf(&b, "kanban_uptime_seconds %.0f\n", time.Since(r.started).Seconds())

	return b.String()
}

// writeHistogram выводит ступени, сумму и число наблюдений.
//
// Ступени Prometheus кумулятивные: в каждой — число наблюдений не
// больше её границы. Мы храним попадания в саму ступень, поэтому здесь
// суммируем на ходу.
func writeHistogram(b *strings.Builder, name, lbl string, h *histogram,
	bounds []float64, scale float64) {

	var acc uint64
	for i, bound := range bounds {
		acc += atomic.LoadUint64(&h.counts[i])
		fmt.Fprintf(b, "%s_bucket{%s,le=\"%s\"} %d\n", name, lbl, fmtFloat(bound), acc)
	}
	total := atomic.LoadUint64(&h.total)
	fmt.Fprintf(b, "%s_bucket{%s,le=\"+Inf\"} %d\n", name, lbl, total)
	fmt.Fprintf(b, "%s_sum{%s} %g\n", name, lbl, float64(atomic.LoadUint64(&h.sumNs))/scale)
	fmt.Fprintf(b, "%s_count{%s} %d\n", name, lbl, total)
}

func fmtFloat(v float64) string {
	return strconv.FormatFloat(v, 'g', -1, 64)
}

func sortedKeys(m map[string]*uint64) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func sortedHistKeys(m map[string]*histogram) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func sortedGauges(m map[string]func() float64) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
