package metrics

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// PGCollector снимает метрики самой базы данных.
//
// Почему своим опросом, а не postgres_exporter: экспортёр — ещё один
// процесс, которому нужны своя строка подключения, свои права и свой
// присмотр. Нам же нужно десятка полтора чисел, и приложение уже
// подключено к базе. Запрос раз в пятнадцать секунд базу не нагружает.
//
// Что собирается:
//
//   - размер базы и крупнейших таблиц — видно, что растёт;
//   - соединения по состояниям: активные, простаивающие, «idle in
//     transaction» (последние особенно важны: такая транзакция держит
//     блокировки и не даёт работать автоочистке);
//   - попадание в кэш, фиксации и откаты, взаимные блокировки;
//   - мёртвые строки по таблицам — по ним видно, что автоочистка
//     отстаёт;
//   - длительность самого долгого запроса и самой долгой транзакции —
//     ровно то, из-за чего всё встаёт;
//   - ожидание репликации, если она настроена.
//
// Опрос идёт от имени приложения. Часть представлений (pg_stat_*)
// суперпользователю показывает больше, но нам хватает и доступного:
// размеры, соединения, фиксации, мёртвые строки видны всем.
type PGCollector struct {
	pool *pgxpool.Pool
	reg  *Registry

	mu   sync.RWMutex
	text string // готовый текст метрик, обновляется опросом
}

func NewPGCollector(pool *pgxpool.Pool, reg *Registry) *PGCollector {
	return &PGCollector{pool: pool, reg: reg}
}

// Start запускает опрос. Интервал в пятнадцать секунд совпадает с
// обычным шагом сбора у Prometheus: чаще — лишняя нагрузка, реже —
// график с дырами.
func (c *PGCollector) Start(ctx context.Context) {
	go func() {
		c.collect(ctx) // первый снимок сразу, чтобы /metrics не был пустым
		t := time.NewTicker(15 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				c.collect(ctx)
			}
		}
	}()
}

// Text возвращает последний снимок метрик базы.
func (c *PGCollector) Text() string {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.text
}

func (c *PGCollector) collect(ctx context.Context) {
	ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	var b strings.Builder

	// ── размер базы ──────────────────────────────────────────────────
	var dbName string
	var dbSize int64
	if err := c.pool.QueryRow(ctx,
		`SELECT current_database(), pg_database_size(current_database())`).
		Scan(&dbName, &dbSize); err == nil {
		b.WriteString("# HELP pg_database_size_bytes Размер базы данных\n# TYPE pg_database_size_bytes gauge\n")
		fmt.Fprintf(&b, "pg_database_size_bytes{datname=\"%s\"} %d\n", esc(dbName), dbSize)
	} else {
		slog.Debug("метрики базы: размер", "error", err)
	}

	// ── соединения по состояниям ─────────────────────────────────────
	if rows, err := c.pool.Query(ctx, `
		SELECT COALESCE(state, 'unknown'), count(*)
		  FROM pg_stat_activity
		 WHERE datname = current_database()
		 GROUP BY 1`); err == nil {
		b.WriteString("# HELP pg_connections Соединения с базой по состояниям\n# TYPE pg_connections gauge\n")
		for rows.Next() {
			var state string
			var n int64
			if rows.Scan(&state, &n) == nil {
				fmt.Fprintf(&b, "pg_connections{state=\"%s\"} %d\n", esc(state), n)
			}
		}
		rows.Close()
	}

	// Предел соединений — чтобы на графике было видно, насколько близко
	// к потолку.
	var maxConn int64
	if err := c.pool.QueryRow(ctx,
		`SELECT setting::bigint FROM pg_settings WHERE name = 'max_connections'`).
		Scan(&maxConn); err == nil {
		b.WriteString("# HELP pg_max_connections Предел соединений\n# TYPE pg_max_connections gauge\n")
		fmt.Fprintf(&b, "pg_max_connections %d\n", maxConn)
	}

	// ── фиксации, откаты, кэш, блокировки ────────────────────────────
	var commits, rollbacks, blksRead, blksHit, deadlocks, tupReturned, tupFetched int64
	if err := c.pool.QueryRow(ctx, `
		SELECT xact_commit, xact_rollback, blks_read, blks_hit,
		       deadlocks, tup_returned, tup_fetched
		  FROM pg_stat_database WHERE datname = current_database()`).
		Scan(&commits, &rollbacks, &blksRead, &blksHit, &deadlocks,
			&tupReturned, &tupFetched); err == nil {

		b.WriteString("# HELP pg_xact_commit_total Зафиксированных транзакций\n# TYPE pg_xact_commit_total counter\n")
		fmt.Fprintf(&b, "pg_xact_commit_total %d\n", commits)
		b.WriteString("# HELP pg_xact_rollback_total Откатов транзакций\n# TYPE pg_xact_rollback_total counter\n")
		fmt.Fprintf(&b, "pg_xact_rollback_total %d\n", rollbacks)
		b.WriteString("# HELP pg_blks_read_total Блоков прочитано с диска\n# TYPE pg_blks_read_total counter\n")
		fmt.Fprintf(&b, "pg_blks_read_total %d\n", blksRead)
		b.WriteString("# HELP pg_blks_hit_total Блоков прочитано из кэша\n# TYPE pg_blks_hit_total counter\n")
		fmt.Fprintf(&b, "pg_blks_hit_total %d\n", blksHit)
		b.WriteString("# HELP pg_deadlocks_total Взаимных блокировок\n# TYPE pg_deadlocks_total counter\n")
		fmt.Fprintf(&b, "pg_deadlocks_total %d\n", deadlocks)
		b.WriteString("# HELP pg_tup_returned_total Строк просмотрено\n# TYPE pg_tup_returned_total counter\n")
		fmt.Fprintf(&b, "pg_tup_returned_total %d\n", tupReturned)
		b.WriteString("# HELP pg_tup_fetched_total Строк выбрано\n# TYPE pg_tup_fetched_total counter\n")
		fmt.Fprintf(&b, "pg_tup_fetched_total %d\n", tupFetched)
	}

	// ── самый долгий запрос и транзакция ─────────────────────────────
	//
	// Именно эти два числа отвечают на вопрос «почему всё медленно».
	// Долгая транзакция вдобавок блокирует автоочистку, и база пухнет.
	var longestQuery, longestXact, idleInTx float64
	if err := c.pool.QueryRow(ctx, `
		SELECT COALESCE(max(EXTRACT(epoch FROM now() - query_start))
		         FILTER (WHERE state = 'active'), 0),
		       COALESCE(max(EXTRACT(epoch FROM now() - xact_start)), 0),
		       COALESCE(max(EXTRACT(epoch FROM now() - state_change))
		         FILTER (WHERE state = 'idle in transaction'), 0)
		  FROM pg_stat_activity
		 WHERE datname = current_database() AND pid <> pg_backend_pid()`).
		Scan(&longestQuery, &longestXact, &idleInTx); err == nil {

		b.WriteString("# HELP pg_longest_query_seconds Самый долгий активный запрос\n# TYPE pg_longest_query_seconds gauge\n")
		fmt.Fprintf(&b, "pg_longest_query_seconds %g\n", longestQuery)
		b.WriteString("# HELP pg_longest_transaction_seconds Самая долгая транзакция\n# TYPE pg_longest_transaction_seconds gauge\n")
		fmt.Fprintf(&b, "pg_longest_transaction_seconds %g\n", longestXact)
		b.WriteString("# HELP pg_idle_in_transaction_seconds Самая долгая простаивающая транзакция\n# TYPE pg_idle_in_transaction_seconds gauge\n")
		fmt.Fprintf(&b, "pg_idle_in_transaction_seconds %g\n", idleInTx)
	}

	// ── блокировки в ожидании ────────────────────────────────────────
	var waiting int64
	if err := c.pool.QueryRow(ctx,
		`SELECT count(*) FROM pg_locks WHERE NOT granted`).Scan(&waiting); err == nil {
		b.WriteString("# HELP pg_locks_waiting Запросов, ждущих блокировку\n# TYPE pg_locks_waiting gauge\n")
		fmt.Fprintf(&b, "pg_locks_waiting %d\n", waiting)
	}

	// ── таблицы: размер, строки, мёртвые строки, автоочистка ─────────
	//
	// Только схема приложения и только двадцать крупнейших таблиц:
	// метрика на каждую таблицу системного каталога даёт сотни серий
	// без всякой пользы.
	if rows, err := c.pool.Query(ctx, `
		SELECT relname,
		       pg_total_relation_size(relid),
		       COALESCE(n_live_tup, 0), COALESCE(n_dead_tup, 0),
		       COALESCE(seq_scan, 0), COALESCE(idx_scan, 0),
		       COALESCE(EXTRACT(epoch FROM now() - GREATEST(last_autovacuum, last_vacuum)), -1)
		  FROM pg_stat_user_tables
		 WHERE schemaname = 'app'
		 ORDER BY pg_total_relation_size(relid) DESC
		 LIMIT 20`); err == nil {

		b.WriteString("# HELP pg_table_size_bytes Размер таблицы с индексами\n# TYPE pg_table_size_bytes gauge\n")
		var sizes, live, dead, seqs, idxs, vac strings.Builder
		for rows.Next() {
			var name string
			var size, l, dd, sc, ic int64
			var since float64
			if rows.Scan(&name, &size, &l, &dd, &sc, &ic, &since) != nil {
				continue
			}
			fmt.Fprintf(&sizes, "pg_table_size_bytes{table=\"%s\"} %d\n", esc(name), size)
			fmt.Fprintf(&live, "pg_table_live_rows{table=\"%s\"} %d\n", esc(name), l)
			fmt.Fprintf(&dead, "pg_table_dead_rows{table=\"%s\"} %d\n", esc(name), dd)
			fmt.Fprintf(&seqs, "pg_table_seq_scan_total{table=\"%s\"} %d\n", esc(name), sc)
			fmt.Fprintf(&idxs, "pg_table_idx_scan_total{table=\"%s\"} %d\n", esc(name), ic)
			if since >= 0 {
				fmt.Fprintf(&vac, "pg_table_vacuum_age_seconds{table=\"%s\"} %g\n", esc(name), since)
			}
		}
		rows.Close()
		b.WriteString(sizes.String())
		b.WriteString("# HELP pg_table_live_rows Живых строк в таблице\n# TYPE pg_table_live_rows gauge\n")
		b.WriteString(live.String())
		b.WriteString("# HELP pg_table_dead_rows Мёртвых строк (отставание автоочистки)\n# TYPE pg_table_dead_rows gauge\n")
		b.WriteString(dead.String())
		b.WriteString("# HELP pg_table_seq_scan_total Полных просмотров таблицы\n# TYPE pg_table_seq_scan_total counter\n")
		b.WriteString(seqs.String())
		b.WriteString("# HELP pg_table_idx_scan_total Просмотров по индексу\n# TYPE pg_table_idx_scan_total counter\n")
		b.WriteString(idxs.String())
		b.WriteString("# HELP pg_table_vacuum_age_seconds Сколько прошло с последней очистки\n# TYPE pg_table_vacuum_age_seconds gauge\n")
		b.WriteString(vac.String())
	}

	// ── прикладные объёмы ────────────────────────────────────────────
	//
	// Сколько в системе проектов, задач, досок: по этим числам видно,
	// как приложение растёт, и они же объясняют изменения в нагрузке.
	if rows, err := c.pool.Query(ctx, `
		SELECT 'boards', count(*) FROM app.boards WHERE NOT archived
		UNION ALL SELECT 'tasks', count(*) FROM app.tasks WHERE NOT archived
		UNION ALL SELECT 'tasks_open', count(*) FROM app.tasks
		          WHERE NOT archived AND completed_at IS NULL
		UNION ALL SELECT 'tasks_overdue', count(*) FROM app.tasks
		          WHERE NOT archived AND completed_at IS NULL
		            AND due_date IS NOT NULL AND due_date < current_date
		UNION ALL SELECT 'users_active', count(*) FROM app.users
		          WHERE is_active AND deleted_at IS NULL
		UNION ALL SELECT 'comments', count(*) FROM app.comments
		UNION ALL SELECT 'attachments', count(*) FROM app.attachments
		UNION ALL SELECT 'charts', count(*) FROM app.charts
		UNION ALL SELECT 'whiteboards', count(*) FROM app.whiteboards
		UNION ALL SELECT 'notifications_unread', count(*) FROM app.notifications
		          WHERE read_at IS NULL`); err == nil {

		b.WriteString("# HELP kanban_entities Количество объектов в системе\n# TYPE kanban_entities gauge\n")
		for rows.Next() {
			var kind string
			var n int64
			if rows.Scan(&kind, &n) == nil {
				fmt.Fprintf(&b, "kanban_entities{kind=\"%s\"} %d\n", esc(kind), n)
			}
		}
		rows.Close()
	}

	c.mu.Lock()
	c.text = b.String()
	c.mu.Unlock()
}
