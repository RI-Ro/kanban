package handlers

import (
	"path/filepath"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/fiber/v2/middleware/requestid"
	"github.com/gofiber/websocket/v2"
	"github.com/google/uuid"

	"github.com/example/kanban/internal/auth"
	"github.com/example/kanban/internal/config"
	"github.com/example/kanban/internal/database"
	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/metrics"
	mw "github.com/example/kanban/internal/middleware"
	"github.com/example/kanban/internal/realtime"
	"github.com/example/kanban/internal/storage"
)

type Server struct {
	cfg   *config.Config
	db    *database.DB
	auth  *auth.Manager
	files *storage.Local
	hub   *realtime.Hub
	// Метрики и опрос базы. Могут быть nil: тогда измерения просто не
	// ведутся, и приложение работает как раньше.
	metrics *metrics.Registry
	pgStats *metrics.PGCollector
}

func New(cfg *config.Config, db *database.DB, am *auth.Manager, files *storage.Local, hub *realtime.Hub) *Server {
	return &Server{cfg: cfg, db: db, auth: am, files: files, hub: hub}
}

// WithMetrics подключает сбор метрик. Вызывается из main после того,
// как поднят пул соединений: датчики читают его состояние напрямую.
func (s *Server) WithMetrics(reg *metrics.Registry, pg *metrics.PGCollector) *Server {
	s.metrics = reg
	s.pgStats = pg
	if reg == nil {
		return s
	}

	// Состояние пула — датчиками: это мгновенные значения, и копить их
	// в приложении незачем, Prometheus сам снимает их при опросе.
	reg.Gauge("kanban_db_pool_total", func() float64 { return float64(s.db.Stats().TotalConns()) })
	reg.Gauge("kanban_db_pool_acquired", func() float64 { return float64(s.db.Stats().AcquiredConns()) })
	reg.Gauge("kanban_db_pool_idle", func() float64 { return float64(s.db.Stats().IdleConns()) })
	reg.Gauge("kanban_db_pool_max", func() float64 { return float64(s.db.Stats().MaxConns()) })
	// Сколько запросов ждали соединения: если это число растёт, пул мал.
	reg.Gauge("kanban_db_pool_empty_acquires", func() float64 {
		return float64(s.db.Stats().EmptyAcquireCount())
	})
	reg.Gauge("kanban_ws_users", func() float64 { return float64(s.hub.ConnectedUsers()) })
	reg.Gauge("kanban_ws_connections", func() float64 { return float64(s.hub.Connections()) })

	s.db.SetObserver(func(op string, d time.Duration, failed bool) {
		reg.DBQuery(op, d, failed)
	})
	s.hub.SetObserver(func(kind string) { reg.WSEvent(kind) })
	return s
}

// App собирает Fiber-приложение целиком.
//
// Prefork по умолчанию выключен, и на одной машине он обычно не нужен:
// fasthttp обслуживает каждое соединение своей горутиной и сам
// занимает все ядра. Он включается настройкой для тех случаев, когда
// процессов действительно хочется несколько.
//
// Важно понимать цену. Prefork поднимает независимые процессы со своей
// памятью: у каждого свой список соединений WebSocket, свой счётчик
// ограничителя частоты и свой фоновый опрос напоминаний. Первое
// лечится общей шиной (Redis), третье — блокировкой в базе (см.
// reminders.go), второе остаётся: фактический предел частоты
// умножается на число процессов, и его стоит поделить в настройке.
func (s *Server) App() *fiber.App {
	app := fiber.New(fiber.Config{
		AppName:               "Команда",
		DisableStartupMessage: false,

		// Число процессов задаётся через GOMAXPROCS в main: Fiber
		// плодит ровно столько детей, сколько их у процесса.
		Prefork: s.cfg.Prefork,

		// За обратным прокси адрес клиента приходит в X-Forwarded-For,
		// а в самом соединении стоит адрес прокси. Без этих настроек
		// c.IP() возвращал бы адрес прокси для ВСЕХ запросов, и общий
		// лимит частоты складывался бы на всех пользователей сразу:
		// достаточно активный сотрудник исчерпывал бы его за остальных.
		//
		// Доверять заголовку можно только от известных адресов — иначе
		// любой клиент подделает его и обойдёт лимит. Поэтому проверка
		// включается лишь при заданном TRUSTED_PROXIES.
		ProxyHeader:             proxyHeader(s.cfg.TrustedProxies),
		EnableTrustedProxyCheck: len(s.cfg.TrustedProxies) > 0,
		TrustedProxies:          s.cfg.TrustedProxies,
		BodyLimit:             int(s.cfg.MaxUploadBytes) + (2 << 20),
		ReadTimeout:           60 * time.Second,
		WriteTimeout:          120 * time.Second, // с запасом на отдачу больших файлов
		IdleTimeout:           120 * time.Second,
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			if fe, ok := err.(*fiber.Error); ok {
				return httpx.JSON(c, fe.Code, httpx.ErrorBody{Error: fe.Message, Code: "http_error"})
			}
			return httpx.Fail(c, err)
		},
	})

	app.Use(requestid.New())
	app.Use(recover.New(recover.Config{EnableStackTrace: !s.cfg.IsProduction()}))
	app.Use(logger.New(logger.Config{
		Format: "${time} ${status} ${latency} ${method} ${path} reqid=${locals:requestid}\n",
	}))
	app.Use(cors.New(cors.Config{
		AllowOrigins:     joinOrigins(s.cfg.AllowedOrigins),
		AllowMethods:     "GET,POST,PATCH,PUT,DELETE,OPTIONS",
		AllowHeaders:     "Authorization,Content-Type,X-Request-Id,X-Timezone",
		ExposeHeaders:    "X-Request-Id",
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// Измерение каждого запроса.
	//
	// Стоит после recover и logger, но ДО маршрутов: иначе в метрики
	// не попадут ни отказы ограничителя частоты, ни ошибки
	// аутентификации — а именно их и нужно видеть первыми.
	//
	// Маршрут в метку берётся как шаблон роута (/api/tasks/:taskID), а
	// не фактический путь: с путями метки размножились бы по числу
	// задач в системе, и хранилище такую серию не выдержит.
	if s.metrics != nil {
		app.Use(func(c *fiber.Ctx) error {
			// Сам /metrics не измеряем: опрос идёт раз в 15 секунд и
			// только добавил бы шум в собственные графики.
			if c.Path() == "/metrics" {
				return c.Next()
			}
			start := time.Now()
			s.metrics.RequestStarted()
			err := c.Next()
			s.metrics.RequestEnded()

			route := c.Route().Path
			if route == "" || route == "/*" {
				// Статика и клиентские маршруты: отдельная метка, иначе
				// каждый открытый адрес SPA даёт свою серию.
				route = "static"
			}
			status := c.Response().StatusCode()
			if err != nil {
				// Обработчик вернул ошибку — код ответа ещё не
				// выставлен, его поставит ErrorHandler. Берём из ошибки.
				if fe, ok := err.(*fiber.Error); ok {
					status = fe.Code
				} else {
					status = fiber.StatusInternalServerError
				}
			}
			s.metrics.Request(c.Method(), route, status,
				time.Since(start), len(c.Response().Body()))
			return err
		})

		// Выдача метрик. Без аутентификации — её собирает Prometheus,
		// который токенов не носит; закрывать этот адрес нужно на
		// уровне сети (слушать внутренний интерфейс или закрыть на
		// прокси). Ничего, кроме счётчиков, здесь не отдаётся.
		app.Get("/metrics", func(c *fiber.Ctx) error {
			c.Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
			out := s.metrics.Render()
			if s.pgStats != nil {
				out += s.pgStats.Text()
			}
			return c.SendString(out)
		})
	}

	app.Get("/healthz", func(c *fiber.Ctx) error {
		stat := s.db.Stats()
		return httpx.JSON(c, fiber.StatusOK, fiber.Map{
			"status":        "ok",
			"wsConnections": s.hub.ConnectedUsers(),
			"dbConnsInUse":  stat.AcquiredConns(),
			"dbConnsIdle":   stat.IdleConns(),
			"dbConnsTotal":  stat.TotalConns(),
			"dbConnsMax":    stat.MaxConns(),
		})
	})

	api := app.Group("/api")

	// Публичные маршруты — жёсткий лимит частоты защищает от перебора
	// паролей и создания учётных записей ботами.
	authGroup := api.Group("/auth", limiter.New(limiter.Config{
		Max:          20,
		Expiration:   time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
	}))
	authGroup.Post("/register", s.Register)
	authGroup.Post("/login", s.Login)
	authGroup.Post("/refresh", s.Refresh)
	authGroup.Post("/logout", s.Logout)

	// Апгрейд WebSocket требует токен ДО стандартного REST-middleware
	// Auth (там нет заголовка Authorization — только query-параметр),
	// поэтому у него отдельная проверка в realtime.go.
	api.Get("/ws", s.wsAuth, websocket.New(s.wsHandler, websocket.Config{
		HandshakeTimeout: 10 * time.Second,
	}))

	// Всё остальное REST API — с действующим access-токеном и общим
	// лимитом частоты на IP-адрес.
	private := api.Group("", limiter.New(limiter.Config{
		Max:          s.cfg.RateLimitPerMin,
		Expiration:   time.Minute,
		KeyGenerator: func(c *fiber.Ctx) string { return c.IP() },
	}), mw.Auth(s.auth))

	private.Get("/me", s.Me)
	private.Patch("/me", s.UpdateMe)
	private.Post("/me/password", s.ChangePassword)

	private.Get("/users", s.Directory)
	private.Get("/team", s.GetTeam)
	private.Put("/team", s.SetTeam)
	// Группы внутри команды — для выбора исполнителей задачи.
	private.Get("/team/groups", s.ListTeamGroups)
	private.Put("/team/groups", s.SaveTeamGroups)

	private.Get("/notifications", s.ListNotifications)
	private.Post("/notifications/:id/read", s.ReadNotification)
	private.Post("/notifications/read-all", s.ReadAllNotifications)
	// Персональные настройки категорий уведомлений (п.3).
	private.Get("/notification-prefs", s.GetNotificationPrefs)
	private.Put("/notification-prefs", s.SetNotificationPref)

	// Напоминания («будильники»).
	private.Get("/reminders", s.ListReminders)
	private.Post("/reminders", s.CreateReminder)
	private.Patch("/reminders/:reminderID", s.UpdateReminder)
	private.Delete("/reminders/:reminderID", s.DeleteReminder)
	// Перенос сработавшего напоминания («отложить на 5 минут»).
	private.Post("/reminders/:reminderID/snooze", s.SnoozeReminder)

	boards := private.Group("/boards")
	boards.Get("/", s.ListBoards)
	boards.Post("/", s.CreateBoard)
	boards.Get("/:boardID", s.GetBoard)
	boards.Patch("/:boardID", s.UpdateBoard)
	boards.Delete("/:boardID", s.DeleteBoard)
	boards.Post("/:boardID/background", s.UploadBackground)
	boards.Get("/:boardID/background", s.GetBackground)
	boards.Delete("/:boardID/background", s.DeleteBackground)
	boards.Put("/:boardID/members", s.SetMembers)
	boards.Get("/:boardID/columns", s.ListColumns)
	boards.Put("/:boardID/columns", s.SaveColumns)
	boards.Get("/:boardID/tasks", s.ListTasks)
	boards.Post("/:boardID/tasks", s.CreateTask)

	// Диаграммы (Ганта). Свои сущности со своими правами: записи
	// диаграммы не задачи приложения и в задачи не попадают.
	charts := private.Group("/charts")
	charts.Get("/", s.ListCharts)
	charts.Post("/", s.CreateChart)
	charts.Get("/:chartID", s.GetChart)
	charts.Patch("/:chartID", s.UpdateChart)
	charts.Delete("/:chartID", s.DeleteChart)
	charts.Put("/:chartID/members", s.SetChartMembers)
	// Созвон и просьба ознакомиться: уведомление участникам.
	charts.Post("/:chartID/invite", s.InviteToChart)
	charts.Get("/:chartID/items", s.ListChartItems)
	charts.Post("/:chartID/items", s.CreateChartItem)
	charts.Patch("/:chartID/items/:itemID", s.UpdateChartItem)
	charts.Delete("/:chartID/items/:itemID", s.DeleteChartItem)
	// Обсуждение и файлы этапа — по образцу задач.
	charts.Get("/:chartID/items/:itemID/comments", s.ListChartComments)
	charts.Get("/:chartID/items/:itemID/activity", s.ListChartActivity)
	charts.Post("/:chartID/items/:itemID/comments", s.AddChartComment)
	charts.Delete("/:chartID/items/:itemID/comments/:commentID", s.DeleteChartComment)
	charts.Post("/:chartID/items/:itemID/files", s.UploadChartFile)
	charts.Delete("/:chartID/items/:itemID/files/:fileID", s.DeleteChartFile)
	private.Get("/chart-files/:fileID", s.DownloadChartFile)
	private.Get("/chart-files/:fileID/pdf", s.PreviewChartFile)

	// Совместные доски (холст). Фигуры правятся по одной — так
	// одновременная работа не приводит к затиранию чужих правок.
	wb := private.Group("/whiteboards")
	wb.Get("/", s.ListWhiteboards)
	wb.Post("/", s.CreateWhiteboard)
	wb.Get("/:wbID", s.GetWhiteboard)
	wb.Patch("/:wbID", s.UpdateWhiteboard)
	wb.Delete("/:wbID", s.DeleteWhiteboard)
	wb.Put("/:wbID/members", s.SetWhiteboardMembers)
	wb.Post("/:wbID/invite", s.InviteToWhiteboard)
	wb.Get("/:wbID/shapes", s.ListShapes)
	wb.Post("/:wbID/shapes", s.CreateShape)
	wb.Patch("/:wbID/shapes/:shapeID", s.UpdateShape)
	wb.Delete("/:wbID/shapes/:shapeID", s.DeleteShape)
	wb.Post("/:wbID/clear", s.ClearWhiteboard)
	wb.Post("/:wbID/shapes/:shapeID/order", s.ReorderShape)

	// Значки для досок: общий для установки набор, дополняемый людьми.
	private.Get("/board-icons", s.ListBoardIcons)
	private.Post("/board-icons", s.UploadBoardIcon)
	private.Get("/board-icons/:iconID/file", s.DownloadBoardIcon)
	private.Delete("/board-icons/:iconID", s.DeleteBoardIcon)

	// Отметка о просмотре задачи или проекта (п.5).
	private.Post("/views", s.MarkSeen)
	// Кто сейчас в сети.
	private.Get("/presence", s.Presence)

	// Переписка: личные и групповые чаты.
	private.Get("/chats", s.ListChats)
	private.Post("/chats", s.CreateChat)
	chats := private.Group("/chats/:chatID")
	chats.Patch("/", s.RenameChat)
	chats.Post("/members", s.AddChatMember)
	chats.Delete("/members/:userID", s.RemoveChatMember)
	chats.Get("/messages", s.ListMessages)
	chats.Post("/messages", s.SendMessage)
	chats.Post("/files", s.UploadChatFile)
	chats.Post("/read", s.MarkChatRead)
	chats.Delete("/", s.DeleteChat)
	chats.Post("/clear", s.ClearChat)
	chats.Post("/avatar", s.SetChatAvatar)
	chats.Get("/avatar", s.DownloadChatAvatar)
	chats.Get("/polls", s.ListPolls)
	chats.Post("/polls", s.CreatePoll)
	private.Post("/poll-options/:optionID/vote", s.Vote)
	private.Post("/polls/:pollID/close", s.ClosePoll)
	private.Get("/messages/:messageID/file", s.DownloadChatFile)
	private.Get("/messages/:messageID/pdf", s.PreviewChatFile)
	private.Patch("/messages/:messageID", s.EditMessage)
	private.Delete("/messages/:messageID", s.DeleteMessage)

	private.Get("/inbox", s.Inbox)
	// Сводный список всех доступных задач — вкладка «Все задачи».
	private.Get("/tasks", s.AllTasks)

	tasks := private.Group("/tasks/:taskID")
	tasks.Get("/", s.GetTask)
	tasks.Patch("/", s.UpdateTask)
	tasks.Delete("/", s.DeleteTask)
	tasks.Post("/move", s.MoveTask)
	tasks.Post("/copy", s.CopyTask)
	// Перенос задачи в другой проект — со всем, что к ней приросло.
	// Путь /transfer, а не /move: /move уже занят перекладыванием
	// карточки между колонками одной доски.
	tasks.Post("/transfer", s.TransferTask)
	// Готовность к сдаче: исполнитель закончил и ждёт приёмки.
	tasks.Post("/ready", s.SetTaskReady)
	tasks.Post("/complete", s.CompleteTask)
	// Отметка исполнителя о своей части — отдельно от закрытия задачи
	// целиком: это разные действия с разными правами.
	tasks.Post("/assignment", s.CompleteAssignment)
	tasks.Get("/links", s.ListTaskLinks)
	tasks.Post("/links", s.CreateTaskLink)
	tasks.Post("/steps", s.CreateStep)
	tasks.Patch("/steps/:stepID", s.RenameStep)
	tasks.Post("/steps/:stepID/toggle", s.ToggleStep)
	tasks.Delete("/steps/:stepID", s.DeleteStep)
	tasks.Patch("/report", s.SetReport)
	tasks.Get("/comments", s.ListComments)
	tasks.Post("/comments", s.CreateComment)
	tasks.Get("/attachments", s.ListAttachments)
	tasks.Post("/attachments", s.UploadAttachment)
	tasks.Get("/activity", s.ListActivity)
	tasks.Put("/grants", s.SetGrants)

	private.Patch("/comments/:id", s.UpdateComment)
	private.Delete("/comments/:id", s.DeleteComment)

	private.Get("/attachments/:id/content", s.DownloadAttachment)
	// PDF-версия для предпросмотра офисных форматов.
	private.Get("/attachments/:id/pdf", s.PreviewAttachment)
	private.Patch("/attachments/:id", s.RenameAttachment)
	private.Delete("/attachments/:id", s.DeleteAttachment)

	// Администрирование учётных записей. RequireAdmin проверяет права
	// запросом к базе на каждый вызов, а не по полю в токене, — иначе
	// снятие прав вступало бы в силу только через 15 минут.
	// Делегирование, связи задач, шаблоны — три возможности, чья схема
	// заведена миграцией 0010_structure.sql.
	// Дашборд: агрегаты считаются в базе под RLS, поэтому в статистику
	// попадает ровно то, что человеку доступно.
	// Календарь: задачи со сроком в диапазоне, из всех доступных
	// проектов сразу.
	private.Get("/calendar", s.Calendar)

	private.Get("/dashboard", s.Dashboard)
	private.Get("/dashboard/users/:userID/tasks", s.DashboardUserTasks)

	private.Get("/delegations", s.ListDelegations)
	// Действующие замещения всех сотрудников: нужны, чтобы в карточке
	// человека было видно, что он в отпуске и кто его замещает.
	private.Get("/delegations/active", s.ActiveDelegations)
	private.Post("/delegations", s.CreateDelegation)
	private.Delete("/delegations/:id", s.DeleteDelegation)

	private.Get("/templates", s.ListTemplates)
	private.Post("/templates", s.CreateTemplate)
	private.Delete("/templates/:id", s.DeleteTemplate)
	private.Post("/templates/:id/apply", s.ApplyTemplate)

	private.Delete("/links/:id", s.DeleteTaskLink)

	admin := private.Group("/admin", s.RequireAdmin)
	admin.Get("/users", s.AdminListUsers)
	admin.Post("/users", s.AdminCreateUser)
	admin.Patch("/users/:userID", s.AdminUpdateUser)
	admin.Delete("/users/:userID", s.AdminDeleteUser)
	admin.Post("/users/:userID/restore", s.AdminRestoreUser)
	admin.Post("/users/:userID/password", s.AdminResetPassword)

	// ------------------------------------------------------------------
	// Раздача собранного фронтенда тем же сервером.
	//
	// Регистрируется ПОСЛЕ всех маршрутов API — иначе обработчик
	// «вернуть index.html» перехватил бы и запросы к /api.
	//
	// Возврат index.html на неизвестный путь обязателен: адреса вида
	// /b/<uuid> и /inbox существуют только в браузере, на сервере таких
	// файлов нет. Без этого обновление страницы на открытом проекте
	// давало бы 404.
	if s.cfg.StaticDir != "" {
		app.Static("/", s.cfg.StaticDir, fiber.Static{
			Compress:  true,
			ByteRange: true,
			Index:     "index.html",
			MaxAge:    3600,
		})

		indexFile := filepath.Join(s.cfg.StaticDir, "index.html")
		app.Use(func(c *fiber.Ctx) error {
			// Несуществующий путь внутри /api — это ошибка запроса,
			// а не клиентский маршрут: отдавать на него HTML нельзя,
			// иначе клиент получит страницу вместо понятного JSON.
			if strings.HasPrefix(c.Path(), "/api") {
				return httpx.Fail(c, httpx.ErrNotFound)
			}
			if c.Method() != fiber.MethodGet {
				return httpx.Fail(c, httpx.ErrNotFound)
			}
			return c.SendFile(indexFile)
		})
	}

	return app
}

func (s *Server) uid(c *fiber.Ctx) uuid.UUID { return mw.UserID(c) }

func param(c *fiber.Ctx, name string) (uuid.UUID, error) {
	return httpx.UUIDParam(c, name)
}

func joinOrigins(origins []string) string {
	out := ""
	for i, o := range origins {
		if i > 0 {
			out += ","
		}
		out += o
	}
	return out
}

// proxyHeader включает разбор X-Forwarded-For только когда список
// доверенных прокси не пуст. При прямой работе без прокси заголовок
// игнорируется: верить ему от произвольного клиента нельзя.
func proxyHeader(trusted []string) string {
	if len(trusted) == 0 {
		return ""
	}
	return fiber.HeaderXForwardedFor
}
