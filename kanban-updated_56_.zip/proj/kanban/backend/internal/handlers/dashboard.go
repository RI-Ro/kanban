package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
)

// Дашборд считается агрегатами на стороне базы, а не выгрузкой всех
// задач в приложение.
//
// Разница принципиальна: на нескольких тысячах задач выгрузка означает
// мегабайты трафика и заметную паузу на отрисовке, тогда как GROUP BY
// возвращает десяток строк. Все запросы идут под RLS, поэтому в
// статистику попадает ровно то, что человеку доступно, — отдельной
// фильтрации по правам здесь нет и быть не должно.

type dashboardFilter struct {
	From      string
	To        string
	BoardID   *uuid.UUID
	Assignee  *uuid.UUID
	Status    string // all | open | done | overdue
}

func readDashboardFilter(c *fiber.Ctx) dashboardFilter {
	f := dashboardFilter{
		From:   c.Query("from"),
		To:     c.Query("to"),
		Status: c.Query("status", "all"),
	}
	if v := c.Query("boardId"); v != "" {
		if id, err := uuid.Parse(v); err == nil {
			f.BoardID = &id
		}
	}
	if v := c.Query("assignee"); v != "" {
		if id, err := uuid.Parse(v); err == nil {
			f.Assignee = &id
		}
	}
	if f.From == "" {
		// Полгода назад — разумное окно по умолчанию: годовой размах
		// на активной установке уже плохо читается на графике.
		f.From = time.Now().AddDate(0, -6, 0).Format("2006-01-02")
	}
	if f.To == "" {
		f.To = time.Now().AddDate(0, 0, 1).Format("2006-01-02")
	}
	return f
}

// Общее условие отбора. Вынесено в одну строку, чтобы все срезы
// дашборда считались по одной и той же выборке — иначе сумма по
// исполнителям не сойдётся с общим числом, и доверия к отчёту не будет.
//
// Явная проверка can_see_task(t.id, текущий пользователь) страхует от
// утечки: во «нагрузке по исполнителям» и прочих срезах должны
// участвовать только те задачи, которые видит владелец дашборда.
// Полагаться лишь на неявный RLS здесь недостаточно — соединение с
// task_assignees/task_grants могло бы притянуть строки задач, к
// которым у владельца дашборда доступа нет, но есть у исполнителя.
const dashboardWhere = `
	WHERE NOT t.archived
	  AND app.can_see_task(t.id, app.current_user_id())
	  AND t.created_at >= $1::date
	  AND t.created_at <  $2::date
	  AND ($3::uuid IS NULL OR t.board_id = $3::uuid)
	  AND ($4::uuid IS NULL OR EXISTS (
	        SELECT 1 FROM app.task_assignees ta
	         WHERE ta.task_id = t.id AND ta.user_id = $4::uuid))
	  AND ($5::text = 'all'
	    OR ($5::text = 'done'    AND t.completed_at IS NOT NULL)
	    OR ($5::text = 'open'    AND t.completed_at IS NULL)
	    OR ($5::text = 'overdue' AND t.completed_at IS NULL
	                       AND t.due_date IS NOT NULL AND t.due_date < current_date))`

func (s *Server) Dashboard(c *fiber.Ctx) error {
	f := readDashboardFilter(c)
	uid := s.uid(c)
	args := []any{f.From, f.To, f.BoardID, f.Assignee, f.Status}

	type counters struct {
		Total     int `json:"total"`
		Done      int `json:"done"`
		Open      int `json:"open"`
		Overdue   int `json:"overdue"`
		DueSoon   int `json:"dueSoon"`
		NoDueDate int `json:"noDueDate"`
	}
	var totals counters

	byPriority := []map[string]any{}
	byBoard := []map[string]any{}
	byAssignee := []map[string]any{}
	byWeek := []map[string]any{}
	myLoad := map[string]int{}

	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// --- сводные счётчики ---
		if e := tx.QueryRow(c.Context(), `
			SELECT count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date IS NOT NULL
			                          AND t.due_date < current_date),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date BETWEEN current_date AND current_date + 7),
			       count(*) FILTER (WHERE t.due_date IS NULL)
			  FROM app.tasks t`+dashboardWhere, args...).
			Scan(&totals.Total, &totals.Done, &totals.Open, &totals.Overdue,
				&totals.DueSoon, &totals.NoDueDate); e != nil {
			return e
		}

		// --- по приоритетам ---
		rows, e := tx.Query(c.Context(), `
			SELECT t.priority::text, count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL)
			  FROM app.tasks t`+dashboardWhere+`
			 GROUP BY t.priority ORDER BY count(*) DESC`, args...)
		if e != nil {
			return e
		}
		for rows.Next() {
			var name string
			var total, done int
			if e := rows.Scan(&name, &total, &done); e != nil {
				rows.Close()
				return e
			}
			byPriority = append(byPriority, map[string]any{
				"priority": name, "total": total, "done": done,
			})
		}
		rows.Close()

		// --- по проектам ---
		rows, e = tx.Query(c.Context(), `
			SELECT b.id, b.title, count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date IS NOT NULL
			                          AND t.due_date < current_date)
			  FROM app.tasks t
			  JOIN app.boards b ON b.id = t.board_id`+dashboardWhere+`
			 GROUP BY b.id, b.title ORDER BY count(*) DESC LIMIT 20`, args...)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			var title string
			var total, done, overdue int
			if e := rows.Scan(&id, &title, &total, &done, &overdue); e != nil {
				rows.Close()
				return e
			}
			byBoard = append(byBoard, map[string]any{
				"boardId": id, "title": title,
				"total": total, "done": done, "overdue": overdue,
			})
		}
		rows.Close()

		// --- по людям ---
		// Считается участие в задаче: человек либо её исполняет, либо
		// её поставил. Раньше в разрез попадали только исполнители, и
		// работа постановщика — а это тоже работа — в сводке не
		// отражалась вовсе.
		//
		// Двойного счёта нет: если автор задачи заодно и её
		// исполнитель, строка автора не добавляется (NOT EXISTS ниже),
		// и задача учитывается у него один раз.
		//
		// Задача с несколькими исполнителями попадает в строку каждого:
		// это нагрузка на человека, а не разбиение задач на доли.
		//
		// Нагрузка считается БЕЗ ограничения периодом создания: это
		// «сколько сейчас на человеке», а не «сколько создано за
		// полгода». Учитываются только проект-фильтр и статус, поэтому
		// у запроса свой короткий набор аргументов ($1 = boardId,
		// $2 = status) — передавать неиспользуемые даты нельзя: Postgres
		// не смог бы вывести тип незадействованного параметра (42P18).
		rows, e = tx.Query(c.Context(), `
			SELECT p.user_id, count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE t.completed_at IS NULL
			                          AND t.due_date IS NOT NULL
			                          AND t.due_date < current_date),
			       count(*) FILTER (WHERE p.completed_at IS NOT NULL),
			       count(*) FILTER (WHERE p.as_assignee),
			       count(*) FILTER (WHERE NOT p.as_assignee)
			  FROM app.tasks t
			  JOIN LATERAL (
			         SELECT ta.user_id, ta.completed_at, true AS as_assignee
			           FROM app.task_assignees ta WHERE ta.task_id = t.id
			         UNION ALL
			         -- Автор попадает в разрез отдельной строкой, но
			         -- только если он не в исполнителях: иначе одна
			         -- задача посчиталась бы ему дважды.
			         SELECT t.created_by, NULL::timestamptz, false
			          WHERE t.created_by IS NOT NULL
			            AND NOT EXISTS (SELECT 1 FROM app.task_assignees x
			                             WHERE x.task_id = t.id AND x.user_id = t.created_by)
			       ) p ON true
			 WHERE NOT t.archived
			   AND app.can_see_task(t.id, app.current_user_id())
			   AND ($1::uuid IS NULL OR t.board_id = $1::uuid)
			   AND ($2::text = 'all'
			     OR ($2::text = 'done'    AND t.completed_at IS NOT NULL)
			     OR ($2::text = 'open'    AND t.completed_at IS NULL)
			     OR ($2::text = 'overdue' AND t.completed_at IS NULL
			                        AND t.due_date IS NOT NULL AND t.due_date < current_date))
			 GROUP BY p.user_id ORDER BY count(*) DESC LIMIT 30`, f.BoardID, f.Status)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			var total, done, overdue, selfDone, asAssignee, asAuthor int
			if e := rows.Scan(&id, &total, &done, &overdue, &selfDone,
				&asAssignee, &asAuthor); e != nil {
				rows.Close()
				return e
			}
			byAssignee = append(byAssignee, map[string]any{
				"userId": id, "total": total, "done": done,
				"overdue": overdue, "selfDone": selfDone,
				"asAssignee": asAssignee, "asAuthor": asAuthor,
			})
		}
		rows.Close()

		// --- динамика по неделям ---
		rows, e = tx.Query(c.Context(), `
			SELECT to_char(date_trunc('week', t.created_at), 'YYYY-MM-DD'),
			       count(*),
			       count(*) FILTER (WHERE t.completed_at IS NOT NULL)
			  FROM app.tasks t`+dashboardWhere+`
			 GROUP BY 1 ORDER BY 1`, args...)
		if e != nil {
			return e
		}
		for rows.Next() {
			var week string
			var created, done int
			if e := rows.Scan(&week, &created, &done); e != nil {
				rows.Close()
				return e
			}
			byWeek = append(byWeek, map[string]any{
				"week": week, "created": created, "done": done,
			})
		}
		rows.Close()

		// --- лично мне ---
		// Личная сводка «что на мне сейчас» не сужается периодом
		// (поручение месячной давности никуда не делось), но обязана
		// учитывать выбранный проект: иначе при фильтре по проекту
		// плитки показывали бы числа по всем проектам сразу, расходясь
		// со списком задач под ними.
		var assigned, assignedOverdue, delegatedOut, granted int
		var createdTotal, involvedTotal int
		if e := tx.QueryRow(c.Context(), `
			SELECT
			  (SELECT count(*) FROM app.tasks t
			     JOIN app.task_assignees ta ON ta.task_id = t.id
			    WHERE ta.user_id = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  (SELECT count(*) FROM app.tasks t
			     JOIN app.task_assignees ta ON ta.task_id = t.id
			    WHERE ta.user_id = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
			      AND t.due_date IS NOT NULL AND t.due_date < current_date),
			  (SELECT count(*) FROM app.tasks t
			    WHERE t.created_by = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  (SELECT count(*) FROM app.tasks t
			     JOIN app.task_grants g ON g.task_id = t.id
			    WHERE g.user_id = $1 AND NOT t.archived AND t.completed_at IS NULL
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  -- «Я автор» целиком, вместе с завершёнными: остальные
			  -- плитки показывают текущую загрузку, а эта — объём
			  -- поставленного вообще.
			  (SELECT count(*) FROM app.tasks t
			    WHERE t.created_by = $1 AND NOT t.archived
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)),
			  -- Все мои задачи: где я исполнитель ИЛИ автор, без
			  -- двойного счёта — задача, которую я поставил сам себе,
			  -- одна, а не две.
			  (SELECT count(*) FROM app.tasks t
			    WHERE NOT t.archived
			      AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
			      AND (t.created_by = $1
			           OR EXISTS (SELECT 1 FROM app.task_assignees ta
			                       WHERE ta.task_id = t.id AND ta.user_id = $1)))`,
			uid, f.BoardID).
			Scan(&assigned, &assignedOverdue, &delegatedOut, &granted,
				&createdTotal, &involvedTotal); e != nil {
			return e
		}
		myLoad["assigned"] = assigned
		myLoad["assignedOverdue"] = assignedOverdue
		myLoad["createdByMe"] = delegatedOut
		myLoad["grantedToMe"] = granted
		myLoad["createdByMeTotal"] = createdTotal
		myLoad["myTotal"] = involvedTotal
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}

	return httpx.JSON(c, fiber.StatusOK, fiber.Map{
		"totals":     totals,
		"byPriority": byPriority,
		"byBoard":    byBoard,
		"byAssignee": byAssignee,
		"byWeek":     byWeek,
		"myLoad":     myLoad,
		"filter": fiber.Map{
			"from": f.From, "to": f.To, "status": f.Status,
			"boardId": f.BoardID, "assignee": f.Assignee,
		},
	})
}

// DashboardUserTasks — задачи конкретного человека для окна, которое
// открывается нажатием на строку в срезе по исполнителям.
//
// kind различает две роли: assigned — что ему поручено, created — что
// он поручил другим. Это разные вопросы к одному человеку, и смешивать
// их в одном списке нельзя.
func (s *Server) DashboardUserTasks(c *fiber.Ctx) error {
	userID, err := param(c, "userID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	kind := c.Query("kind", "assigned")
	f := readDashboardFilter(c)
	uid := s.uid(c)

	// Три разреза по одному человеку: что ему поручено, что он поручил
	// другим и что ему открыто точечно. Это разные вопросы, и валить их
	// в один список нельзя.
	// $1 = userID во всех разрезах (см. запрос ниже).
	var join, extra string
	switch kind {
	case "created":
		extra = ` AND t.created_by = $1`
	case "granted":
		join = `JOIN app.task_grants g ON g.task_id = t.id AND g.user_id = $1`
	case "involved":
		// Всё, что на человеке: и порученное ему, и поставленное им.
		// Без двойного счёта — условие, а не соединение: JOIN по
		// исполнителям вернул бы задачу, где он и автор, и
		// исполнитель, дважды.
		extra = ` AND (t.created_by = $1
		            OR EXISTS (SELECT 1 FROM app.task_assignees ta
		                        WHERE ta.task_id = t.id AND ta.user_id = $1))`
	default:
		join = `JOIN app.task_assignees ta ON ta.task_id = t.id AND ta.user_id = $1`
	}

	var tasks []taskBrief
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Разрез по человеку НЕ ограничивается периодом создания: плитки
		// «мне поручено / я поручил / открыт доступ» считаются без даты
		// (поручение полугодовой давности никуда не делось), поэтому и
		// список под плиткой должен совпадать — иначе клик по числу
		// показывал бы пустоту. Ограничиваем только проектом и статусом.
		//
		// $1 = userID (владелец разреза), $2 = boardId (может быть NULL),
		// $3 = status ('all'|'open'|'done'|'overdue').
		rows, e := tx.Query(c.Context(), `
			SELECT t.id, t.title, t.board_id, app.board_title(t.board_id),
			       t.column_id, app.column_title(t.column_id), t.priority::text,
			       to_char(t.due_date, 'YYYY-MM-DD'),
			       t.completed_at,
			       t.incoming_number, to_char(t.incoming_date, 'YYYY-MM-DD'), t.tags,
			       (SELECT count(*) FROM app.comments cm WHERE cm.task_id = t.id),
			       (SELECT count(*) FROM app.attachments f WHERE f.task_id = t.id),
			       t.ready_at, t.recur_freq::text, t.recur_interval, t.created_by,
			       COALESCE(array_agg(DISTINCT a.user_id)
			                FILTER (WHERE a.user_id IS NOT NULL), '{}'),
			       COALESCE(array_agg(DISTINCT a.user_id)
			                FILTER (WHERE a.completed_at IS NOT NULL), '{}')
			  FROM app.tasks t
			  LEFT JOIN app.task_assignees a ON a.task_id = t.id
			  `+join+`
			 WHERE NOT t.archived
			   AND app.can_see_task(t.id, app.current_user_id())
			   AND ($2::uuid IS NULL OR t.board_id = $2::uuid)
			   AND ($3::text = 'all'
			     OR ($3::text = 'done'    AND t.completed_at IS NOT NULL)
			     OR ($3::text = 'open'    AND t.completed_at IS NULL)
			     OR ($3::text = 'overdue' AND t.completed_at IS NULL
			                        AND t.due_date IS NOT NULL AND t.due_date < current_date))`+extra+`
			 GROUP BY t.id
			 ORDER BY t.due_date NULLS LAST, t.created_at DESC
			 LIMIT 200`,
			userID, f.BoardID, f.Status)
		if e != nil {
			return e
		}
		defer rows.Close()
		tasks = []taskBrief{}
		for rows.Next() {
			var t taskBrief
			if e := rows.Scan(&t.ID, &t.Title, &t.BoardID, &t.BoardTitle,
				&t.ColumnID, &t.ColumnTitle, &t.Priority, &t.DueDate, &t.CompletedAt,
				&t.IncomingNum, &t.IncomingDate, &t.Tags,
				&t.CommentCnt, &t.AttachCnt, &t.ReadyAt, &t.RecurFreq, &t.RecurInterval, &t.CreatedBy,
				&t.Assignees, &t.AssigneesDone); e != nil {
				return e
			}
			t.Completed = t.CompletedAt != nil
			tasks = append(tasks, t)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, tasks)
}

// taskBrief — строка задачи в списках сводки. Полная задача с
// чек-листом и грантами здесь избыточна.
//
// Состав полей совпадает с календарём: проект, колонка, автор и
// исполнители. Раньше здесь были только название, проект и приоритет —
// по такой строке нельзя было понять ни на какой стадии задача, ни кто
// её ведёт, и приходилось открывать карточку ради очевидного.
type taskBrief struct {
	ID          uuid.UUID   `json:"id"`
	Title       string      `json:"title"`
	BoardID     uuid.UUID   `json:"boardId"`
	BoardTitle  string      `json:"boardTitle"`
	ColumnID    uuid.UUID   `json:"columnId"`
	ColumnTitle string      `json:"columnTitle"`
	Priority    string      `json:"priority"`
	DueDate     *string     `json:"dueDate"`
	Completed   bool        `json:"completed"`
	CompletedAt *time.Time  `json:"completedAt"`
	IncomingNum  string   `json:"incomingNumber"`
	IncomingDate *string  `json:"incomingDate"`
	// Теги нужны фильтру в окне задач исполнителя — он общий с досками.
	Tags         []string `json:"tags"`
	CommentCnt   int        `json:"commentCount"`
	AttachCnt    int        `json:"attachmentCount"`
	ReadyAt      *time.Time `json:"readyAt"`
	RecurFreq     string `json:"recurFreq"`
	RecurInterval int    `json:"recurInterval"`
	CreatedBy   uuid.UUID   `json:"createdBy"`
	Assignees   []uuid.UUID `json:"assignees"`
	// Кто из исполнителей уже отметил свою часть — та же двойная
	// отметка, что и в карточке задачи.
	AssigneesDone []uuid.UUID `json:"assigneesDone"`
}
