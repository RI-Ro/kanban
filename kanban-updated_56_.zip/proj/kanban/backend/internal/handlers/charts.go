package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/example/kanban/internal/httpx"
	"github.com/example/kanban/internal/realtime"
)

// =====================================================================
// Диаграммы (Ганта).
//
// Устройство намеренно повторяет проекты: список своих диаграмм, роли
// владелец/редактор/исполнитель, события по WebSocket всем участникам.
// Записи диаграммы — самостоятельные строки, а не задачи приложения:
// они не попадают ни в календарь, ни во «Все задачи», ни в сводку.
// Связь с задачей проекта существует только как ссылка.
// =====================================================================

type chart struct {
	ID          uuid.UUID       `json:"id"`
	Title       string          `json:"title"`
	Description string          `json:"description"`
	Settings    json.RawMessage `json:"settings"`
	Position    int             `json:"position"`
	Archived    bool            `json:"archived"`
	CreatedBy   uuid.UUID       `json:"createdBy"`
	MyRole      string          `json:"myRole"`
	Members     []chartMember   `json:"members"`
}

type chartMember struct {
	UserID uuid.UUID `json:"userId"`
	Role   string    `json:"role"`
}

// chartItem — полоса (или веха) на диаграмме.
//
// Ссылки на задачи приложения приходят вместе с записью: без них
// клиенту пришлось бы запрашивать их отдельно на каждую полосу, а их
// на диаграмме бывают десятки.
type chartItem struct {
	ID          uuid.UUID   `json:"id"`
	ChartID     uuid.UUID   `json:"chartId"`
	Title       string      `json:"title"`
	Description string      `json:"description"`
	StartsOn    string      `json:"startsOn"`
	EndsOn      string      `json:"endsOn"`
	Progress    int         `json:"progress"`
	Color       string      `json:"color"`
	Milestone   bool        `json:"milestone"`
	Position    int         `json:"position"`
	CreatedBy   uuid.UUID   `json:"createdBy"`
	Next        []uuid.UUID `json:"next"`
	Tasks       []chartTask `json:"tasks"`
	// Сколько на этапе замечаний и файлов. Числа идут вместе со
	// списком: иначе рядом с этапом нечего показать, и о том, что
	// обсуждение вообще есть, узнать можно только открыв его.
	CommentCount int `json:"commentCount"`
	FileCount    int `json:"fileCount"`
}

// chartTask — ссылка на задачу приложения в том виде, в каком её
// показывают на диаграмме.
//
// Visible=false означает, что смотрящий к задаче не допущен. Название
// и проект в этом случае пустые: раскрывать заголовок чужой задачи
// нельзя, а интерфейс пишет об отсутствии доступа.
type chartTask struct {
	TaskID     uuid.UUID `json:"taskId"`
	Title      string    `json:"title"`
	BoardTitle string    `json:"boardTitle"`
	Completed  bool      `json:"completed"`
	Visible    bool      `json:"visible"`
}

const chartCols = `c.id, c.title, c.description, c.settings, c.position, c.archived, c.created_by,
	       COALESCE(app.chart_role(c.id, $1), '')`

func scanChart(row pgx.Row) (chart, error) {
	var ch chart
	err := row.Scan(&ch.ID, &ch.Title, &ch.Description, &ch.Settings,
		&ch.Position, &ch.Archived, &ch.CreatedBy, &ch.MyRole)
	return ch, err
}

// ListCharts отдаёт диаграммы вместе с составом участников.
//
// Состав идёт в списке, а не только в GetChart: окно «Участники»
// открывается из списка, и без него оно показывало пустой состав —
// права при этом работали верно, а кто с какими правами, увидеть было
// нельзя. Состав короткий (единицы строк на диаграмму), поэтому
// отдельный запрос за ним не нужен.
func (s *Server) ListCharts(c *fiber.Ctx) error {
	uid := s.uid(c)
	out := []chart{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT `+chartCols+` FROM app.charts c ORDER BY c.position, c.title`, uid)
		if e != nil {
			return e
		}
		byID := map[uuid.UUID]int{}
		for rows.Next() {
			ch, e := scanChart(rows)
			if e != nil {
				rows.Close()
				return e
			}
			ch.Members = []chartMember{}
			byID[ch.ID] = len(out)
			out = append(out, ch)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}
		if len(out) == 0 {
			return nil
		}
		mrows, e := tx.Query(c.Context(),
			`SELECT chart_id, user_id, role::text FROM app.chart_members`)
		if e != nil {
			return e
		}
		defer mrows.Close()
		for mrows.Next() {
			var chartID uuid.UUID
			var m chartMember
			if e := mrows.Scan(&chartID, &m.UserID, &m.Role); e != nil {
				return e
			}
			if i, ok := byID[chartID]; ok {
				out[i].Members = append(out[i].Members, m)
			}
		}
		return mrows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}

type chartInput struct {
	Title       string          `json:"title"`
	Description string          `json:"description"`
	Settings    json.RawMessage `json:"settings"`
}

func (s *Server) CreateChart(c *fiber.Ctx) error {
	var in chartInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Title == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input", "Укажите название диаграммы"))
	}
	uid := s.uid(c)
	var ch chart
	// Идентификатор задаётся здесь, а вставка идёт БЕЗ RETURNING — по
	// той же причине, что у проектов (см. CreateBoard).
	//
	// При INSERT ... RETURNING Postgres проверяет новую строку не
	// только политикой INSERT, но и политикой SELECT: иначе запрос
	// вернул бы строку, которую смотрящему видеть не полагается. Обе
	// проверки выполняются до триггеров AFTER INSERT, а владельца в
	// app.chart_members записывает именно такой триггер. Поэтому в
	// момент проверки участников у диаграммы ещё нет, can_see_chart
	// отвечает «не видно», и создание отвергается с сообщением
	// «new row violates row-level security policy».
	//
	// Без RETURNING проверяется только политика INSERT (created_by —
	// это я), а перечитать готовую строку можно следующим запросом:
	// к тому времени триггер уже отработал и владелец на месте.
	chartID := uuid.New()
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.charts (id, title, description, settings, created_by,
			                        position)
			VALUES ($5, $2, $3, COALESCE($4::jsonb, '{}'::jsonb), $1,
			        COALESCE((SELECT max(position) + 1 FROM app.charts), 0))`,
			uid, in.Title, in.Description, jsonOrNil(in.Settings), chartID); e != nil {
			return e
		}
		var e error
		ch, e = scanChart(tx.QueryRow(c.Context(),
			`SELECT `+chartCols+` FROM app.charts c WHERE c.id = $2`, uid, chartID))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusCreated, ch)
}

func (s *Server) GetChart(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var ch chart
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var e error
		ch, e = scanChart(tx.QueryRow(c.Context(),
			`SELECT `+chartCols+` FROM app.charts c WHERE c.id = $2`, uid, chartID))
		if e != nil {
			return e
		}
		if ch.MyRole == "" {
			return httpx.Err(fiber.StatusForbidden, "not_member", "Вы не допущены к этой диаграмме")
		}
		rows, e := tx.Query(c.Context(),
			`SELECT user_id, role::text FROM app.chart_members WHERE chart_id = $1`, chartID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var m chartMember
			if e := rows.Scan(&m.UserID, &m.Role); e != nil {
				return e
			}
			ch.Members = append(ch.Members, m)
		}
		return rows.Err()
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, ch)
}

func (s *Server) UpdateChart(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chartInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var ch chart
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `
			UPDATE app.charts
			   SET title       = COALESCE(NULLIF($2, ''), title),
			       description = COALESCE($3, description),
			       settings    = COALESCE($4::jsonb, settings),
			       updated_at  = now()
			 WHERE id = $1`, chartID, in.Title, textOrNil(in.Description), jsonOrNil(in.Settings))
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		ch, e = scanChart(tx.QueryRow(c.Context(),
			`SELECT `+chartCols+` FROM app.charts c WHERE c.id = $2`, uid, chartID))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChart(ch, "updated")
	return httpx.JSON(c, fiber.StatusOK, ch)
}

func (s *Server) DeleteChart(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	// Получателей события собираем ДО удаления: после каскада таблица
	// участников пуста, и рассылать было бы некому.
	watchers := s.chartWatchers(chartID)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(), `DELETE FROM app.charts WHERE id = $1`, chartID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.hub.SendTo(watchers, realtime.Event{
		Type: "chart", Action: "deleted", Payload: fiber.Map{"id": chartID},
	})
	return httpx.NoContent(c)
}

// SetChartMembers — состав участников диаграммы. Правила те же, что у
// проектов: меняет владелец или редактор, роль владельца недоступна
// для назначения и снятия.
func (s *Server) SetChartMembers(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in []memberInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	// Кто был до изменения — чтобы понять, кого добавили, а кого
	// исключили: уведомление нужно и тем и другим, а событие об
	// отзыве доступа — только исключённым.
	var before, after []uuid.UUID
	var title string
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var role string
		if e := tx.QueryRow(c.Context(),
			`SELECT COALESCE(app.chart_role($1, $2), '')`, chartID, uid).Scan(&role); e != nil {
			return e
		}
		if role != "owner" && role != "editor" {
			return httpx.ErrForbidden
		}
		if e := tx.QueryRow(c.Context(),
			`SELECT title FROM app.charts WHERE id = $1`, chartID).Scan(&title); e != nil {
			return e
		}
		rows, e := tx.Query(c.Context(),
			`SELECT user_id FROM app.chart_members WHERE chart_id = $1 AND role <> 'owner'`, chartID)
		if e != nil {
			return e
		}
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				rows.Close()
				return e
			}
			before = append(before, id)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}

		if _, e := tx.Exec(c.Context(),
			`DELETE FROM app.chart_members WHERE chart_id = $1 AND role <> 'owner'`, chartID); e != nil {
			return e
		}
		for _, m := range in {
			if m.Role != "editor" && m.Role != "reader" {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.chart_members (chart_id, user_id, role)
				VALUES ($1, $2, $3::app.board_role)
				ON CONFLICT (chart_id, user_id) DO UPDATE SET role = EXCLUDED.role`,
				chartID, m.UserID, m.Role); e != nil {
				return e
			}
			after = append(after, m.UserID)
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.announceMembership(membershipChange{
		kind: "chart", id: chartID, title: title,
		before: before, after: after, actor: uid,
	})
	return s.GetChart(c)
}

// membershipChange — изменение состава участников диаграммы или доски.
type membershipChange struct {
	kind   string // "chart" | "whiteboard"
	id     uuid.UUID
	title  string
	before []uuid.UUID
	after  []uuid.UUID
	actor  uuid.UUID
}

// announceMembership рассылает последствия изменения состава.
//
// Три разных сообщения, потому что положение у людей разное:
//   • добавленным — уведомление «вас добавили», со ссылкой на объект;
//   • исключённым — уведомление и событие об отзыве доступа, чтобы
//     открытая у них страница перестала показывать чужое, не дожидаясь
//     обновления вручную;
//   • оставшимся — событие о смене состава: окно «Участники» у них
//     открыто, и список в нём должен обновиться сам.
func (s *Server) announceMembership(ch membershipChange) {
	ctx, cancel := bgContext()
	defer cancel()

	was := map[uuid.UUID]bool{}
	for _, id := range ch.before {
		was[id] = true
	}
	now := map[uuid.UUID]bool{}
	for _, id := range ch.after {
		now[id] = true
	}

	var added, removed []uuid.UUID
	for _, id := range ch.after {
		if !was[id] && id != ch.actor {
			added = append(added, id)
		}
	}
	for _, id := range ch.before {
		if !now[id] && id != ch.actor {
			removed = append(removed, id)
		}
	}

	what := "диаграмму"
	if ch.kind == "whiteboard" {
		what = "совместную доску"
	}
	// Имя того, кто менял состав: «вас добавили» без указания, кто
	// именно, заставляет выяснять это отдельно.
	var actorName string
	_ = s.db.AsService(ctx, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `SELECT full_name FROM app.users WHERE id = $1`, ch.actor).
			Scan(&actorName)
	})
	who := actorName
	if who == "" {
		who = "Пользователь"
	}

	// Общий для приложения порядок: кто, что, где. Место здесь внутри
	// самого действия («доступ в диаграмму «…»»), поэтому отдельного
	// «в диаграмме» не добавляем.
	for _, id := range added {
		s.notifyObject(ctx, id,
			notifyPhrase(who, "открыл(а) вам доступ в "+what+" «"+ch.title+"»", "", ""), ch)
	}
	for _, id := range removed {
		s.notifyObject(ctx, id,
			notifyPhrase(who, "закрыл(а) вам доступ в "+what+" «"+ch.title+"»", "", ""), ch)
	}
	if len(removed) > 0 {
		s.hub.SendTo(removed, realtime.Event{
			Type: ch.kind, Action: "accessRevoked", Payload: fiber.Map{"id": ch.id},
		})
	}

	// Событие о новом составе — всем, кто имеет к объекту отношение
	// сейчас или имел минуту назад.
	targets := append([]uuid.UUID{}, ch.after...)
	targets = append(targets, ch.before...)
	targets = append(targets, ch.actor)
	s.hub.SendTo(targets, realtime.Event{
		Type: ch.kind, Action: "members", Payload: fiber.Map{"id": ch.id},
	})
}

// notifyObject пишет уведомление со ссылкой на диаграмму или доску и
// сразу отправляет его в открытые вкладки получателя.
func (s *Server) notifyObject(ctx context.Context, user uuid.UUID, body string, ch membershipChange) {
	var chartID, wbID any
	if ch.kind == "chart" {
		chartID = ch.id
	} else {
		wbID = ch.id
	}
	var nid uuid.UUID
	var createdAt time.Time
	e := s.db.AsService(ctx, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx,
			`SELECT id, created_at FROM app.notify_obj($1, $2, 'membership', $3, $4)`,
			user, body, chartID, wbID).Scan(&nid, &createdAt)
	})
	if e != nil {
		return // категория отключена получателем либо запись не удалась
	}
	n := notifModel(nid, createdAt, body)
	if ch.kind == "chart" {
		n.ChartID = &ch.id
	} else {
		n.WhiteboardID = &ch.id
	}
	s.publishNotification(user, n)
	s.pingNotifications([]uuid.UUID{user})
}

// ── записи диаграммы ────────────────────────────────────────────────

const chartItemCols = `i.id, i.chart_id, i.title, i.description,
	       to_char(i.starts_on, 'YYYY-MM-DD'), to_char(i.ends_on, 'YYYY-MM-DD'),
	       i.progress, i.color, i.milestone, i.position, i.created_by,
	       (SELECT count(*) FROM app.chart_comments cm WHERE cm.item_id = i.id),
	       (SELECT count(*) FROM app.chart_attachments fa WHERE fa.item_id = i.id)`

func (s *Server) ListChartItems(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	items, err := s.loadChartItems(c, chartID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, items)
}

type chartItemInput struct {
	Title       *string      `json:"title"`
	Description *string      `json:"description"`
	StartsOn    *string      `json:"startsOn"`
	EndsOn      *string      `json:"endsOn"`
	Progress    *int         `json:"progress"`
	Color       *string      `json:"color"`
	Milestone   *bool        `json:"milestone"`
	Position    *int         `json:"position"`
	// Полный состав связей и ссылок. Присланный список заменяет
	// прежний целиком; отсутствие поля означает «не трогать».
	Next  *[]uuid.UUID `json:"next"`
	Tasks *[]uuid.UUID `json:"tasks"`
}

func (s *Server) CreateChartItem(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chartItemInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if in.Title == nil || *in.Title == "" || in.StartsOn == nil || in.EndsOn == nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "bad_input",
			"Укажите название, начало и окончание"))
	}
	uid := s.uid(c)
	var itemID uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chart_items
			       (chart_id, title, description, starts_on, ends_on, progress,
			        color, milestone, position, created_by)
			VALUES ($1, $2, COALESCE($3, ''), $4::date, $5::date, COALESCE($6, 0),
			        COALESCE($7, ''), COALESCE($8, false),
			        COALESCE((SELECT max(position) + 1 FROM app.chart_items WHERE chart_id = $1), 0),
			        $9)
			RETURNING id`,
			chartID, *in.Title, in.Description, *in.StartsOn, *in.EndsOn,
			in.Progress, in.Color, in.Milestone, uid).Scan(&itemID); e != nil {
			return e
		}
		if e := s.saveChartItemRelations(c, tx, itemID, in); e != nil {
			return e
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.chart_activity (item_id, actor_id, body) VALUES ($1, $2, $3)`,
			itemID, uid, "Этап создан: "+humanDate(*in.StartsOn)+" — "+humanDate(*in.EndsOn))
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChartItems(chartID)
	return s.oneChartItem(c, chartID, itemID, fiber.StatusCreated)
}

func (s *Server) UpdateChartItem(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chartItemInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Состояние ДО правки: история пишет «стало то, было это», и
		// после UPDATE прежние значения взять уже негде.
		var old chartItemSnapshot
		if e := tx.QueryRow(c.Context(), `
			SELECT title, description, to_char(starts_on,'YYYY-MM-DD'),
			       to_char(ends_on,'YYYY-MM-DD'), progress, color, milestone
			  FROM app.chart_items WHERE id = $1 AND chart_id = $2`, itemID, chartID).
			Scan(&old.Title, &old.Description, &old.StartsOn, &old.EndsOn,
				&old.Progress, &old.Color, &old.Milestone); e != nil {
			return e
		}

		tag, e := tx.Exec(c.Context(), `
			UPDATE app.chart_items
			   SET title       = COALESCE(NULLIF($3, ''), title),
			       description = COALESCE($4, description),
			       starts_on   = COALESCE($5::date, starts_on),
			       ends_on     = COALESCE($6::date, ends_on),
			       progress    = COALESCE($7, progress),
			       color       = COALESCE($8, color),
			       milestone   = COALESCE($9, milestone),
			       position    = COALESCE($10, position),
			       updated_at  = now()
			 WHERE id = $1 AND chart_id = $2`,
			itemID, chartID, textValue(in.Title), in.Description, in.StartsOn,
			in.EndsOn, in.Progress, in.Color, in.Milestone, in.Position)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		if e := s.saveChartItemRelations(c, tx, itemID, in); e != nil {
			return e
		}
		return s.logChartChanges(c, tx, itemID, uid, old, in)
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChartItems(chartID)
	return s.oneChartItem(c, chartID, itemID, fiber.StatusOK)
}

// chartItemSnapshot — состояние этапа до правки, для истории.
type chartItemSnapshot struct {
	Title       string
	Description string
	StartsOn    string
	EndsOn      string
	Progress    int
	Color       string
	Milestone   bool
}

// logChartChanges пишет в историю по одной строке на каждое
// изменившееся свойство.
//
// Отдельные строки, а не одна «этап изменён»: через месяц важно
// видеть именно что поменялось — сроки, объём работ или только
// формулировка. Значения «было → стало» приводятся полностью: без них
// запись отвечает «что-то правили» и ничего не объясняет.
func (s *Server) logChartChanges(c *fiber.Ctx, tx pgx.Tx, itemID, uid uuid.UUID,
	old chartItemSnapshot, in chartItemInput) error {

	var lines []string
	add := func(line string) { lines = append(lines, line) }

	if in.Title != nil && *in.Title != "" && *in.Title != old.Title {
		add("Название: «" + *in.Title + "» (было «" + old.Title + "»)")
	}
	if in.Description != nil && *in.Description != old.Description {
		switch {
		case *in.Description == "":
			add("Описание очищено")
		case old.Description == "":
			add("Добавлено описание")
		default:
			add("Изменено описание")
		}
	}
	// Сроки — одной строкой: они меняются вместе, и две записи про один
	// перенос читаются как два разных события.
	newStart := old.StartsOn
	if in.StartsOn != nil && *in.StartsOn != "" {
		newStart = *in.StartsOn
	}
	newEnd := old.EndsOn
	if in.EndsOn != nil && *in.EndsOn != "" {
		newEnd = *in.EndsOn
	}
	if newStart != old.StartsOn || newEnd != old.EndsOn {
		add("Срок: " + humanDate(newStart) + " — " + humanDate(newEnd) +
			" (было " + humanDate(old.StartsOn) + " — " + humanDate(old.EndsOn) + ")")
	}
	if in.Progress != nil && *in.Progress != old.Progress {
		add("Готовность: " + strconv.Itoa(*in.Progress) + "% (было " +
			strconv.Itoa(old.Progress) + "%)")
	}
	if in.Color != nil && *in.Color != old.Color {
		add("Изменён цвет полосы")
	}
	if in.Milestone != nil && *in.Milestone != old.Milestone {
		if *in.Milestone {
			add("Этап помечен вехой")
		} else {
			add("Отметка вехи снята")
		}
	}
	if in.Next != nil {
		add("Изменены связи со следующими этапами")
	}
	if in.Tasks != nil {
		add("Изменены ссылки на задачи проектов")
	}

	for _, line := range lines {
		if _, e := tx.Exec(c.Context(), `
			INSERT INTO app.chart_activity (item_id, actor_id, body) VALUES ($1, $2, $3)`,
			itemID, uid, line); e != nil {
			return e
		}
	}
	return nil
}

func (s *Server) DeleteChartItem(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		tag, e := tx.Exec(c.Context(),
			`DELETE FROM app.chart_items WHERE id = $1 AND chart_id = $2`, itemID, chartID)
		if e != nil {
			return e
		}
		if tag.RowsAffected() == 0 {
			return httpx.ErrForbidden
		}
		return nil
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChartItems(chartID)
	return httpx.NoContent(c)
}

// saveChartItemRelations заменяет связи и ссылки записи, если клиент их
// прислал. Удаление с последующей вставкой — потому что оба набора
// маленькие (единицы строк), а вычисление разницы здесь только
// добавило бы ошибок.
func (s *Server) saveChartItemRelations(c *fiber.Ctx, tx pgx.Tx, itemID uuid.UUID, in chartItemInput) error {
	if in.Next != nil {
		if _, e := tx.Exec(c.Context(),
			`DELETE FROM app.chart_links WHERE from_item = $1`, itemID); e != nil {
			return e
		}
		for _, to := range *in.Next {
			if to == itemID {
				continue
			}
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.chart_links (from_item, to_item) VALUES ($1, $2)
				ON CONFLICT DO NOTHING`, itemID, to); e != nil {
				return e
			}
		}
	}
	if in.Tasks != nil {
		if _, e := tx.Exec(c.Context(),
			`DELETE FROM app.chart_item_tasks WHERE item_id = $1`, itemID); e != nil {
			return e
		}
		for _, t := range *in.Tasks {
			// Невидимую задачу политика не пропустит — пропускаем её
			// молча: это не ошибка ввода, а попытка сослаться на то,
			// чего для этого человека не существует.
			if _, e := tx.Exec(c.Context(), `
				INSERT INTO app.chart_item_tasks (item_id, task_id) VALUES ($1, $2)
				ON CONFLICT DO NOTHING`, itemID, t); e != nil {
				return e
			}
		}
	}
	return nil
}

// oneChartItem отдаёт одну запись, собранную тем же способом, что и
// список: связи и ссылки там уже учтены, а стоит это одного короткого
// запроса на диаграмму — списки этапов не бывают длинными.
func (s *Server) oneChartItem(c *fiber.Ctx, chartID, itemID uuid.UUID, status int) error {
	items, err := s.loadChartItems(c, chartID)
	if err != nil {
		return httpx.Fail(c, err)
	}
	for i := range items {
		if items[i].ID == itemID {
			return httpx.JSON(c, status, items[i])
		}
	}
	return httpx.Fail(c, httpx.ErrNotFound)
}

func (s *Server) loadChartItems(c *fiber.Ctx, chartID uuid.UUID) ([]chartItem, error) {
	uid := s.uid(c)
	items := []chartItem{}
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(),
			`SELECT `+chartItemCols+` FROM app.chart_items i
			  WHERE i.chart_id = $1 ORDER BY i.position, i.starts_on`, chartID)
		if e != nil {
			return e
		}
		byID := map[uuid.UUID]int{}
		for rows.Next() {
			var it chartItem
			if e := rows.Scan(&it.ID, &it.ChartID, &it.Title, &it.Description,
				&it.StartsOn, &it.EndsOn, &it.Progress, &it.Color, &it.Milestone,
				&it.Position, &it.CreatedBy, &it.CommentCount, &it.FileCount); e != nil {
				rows.Close()
				return e
			}
			it.Next = []uuid.UUID{}
			it.Tasks = []chartTask{}
			byID[it.ID] = len(items)
			items = append(items, it)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}
		if len(items) == 0 {
			return nil
		}
		lrows, e := tx.Query(c.Context(), `
			SELECT l.from_item, l.to_item FROM app.chart_links l
			  JOIN app.chart_items i ON i.id = l.from_item
			 WHERE i.chart_id = $1`, chartID)
		if e != nil {
			return e
		}
		for lrows.Next() {
			var from, to uuid.UUID
			if e := lrows.Scan(&from, &to); e != nil {
				lrows.Close()
				return e
			}
			if idx, ok := byID[from]; ok {
				items[idx].Next = append(items[idx].Next, to)
			}
		}
		lrows.Close()
		if e := lrows.Err(); e != nil {
			return e
		}
		trows, e := tx.Query(c.Context(), `
			SELECT it.item_id, b.task_id, b.title, b.board_title, b.completed, b.visible
			  FROM app.chart_item_tasks it
			  JOIN app.chart_items i ON i.id = it.item_id
			  CROSS JOIN LATERAL app.chart_task_brief(it.task_id, $2) b
			 WHERE i.chart_id = $1`, chartID, uid)
		if e != nil {
			return e
		}
		defer trows.Close()
		for trows.Next() {
			var item uuid.UUID
			var t chartTask
			if e := trows.Scan(&item, &t.TaskID, &t.Title, &t.BoardTitle,
				&t.Completed, &t.Visible); e != nil {
				return e
			}
			if idx, ok := byID[item]; ok {
				items[idx].Tasks = append(items[idx].Tasks, t)
			}
		}
		return trows.Err()
	})
	return items, err
}

// ── события ─────────────────────────────────────────────────────────

// chartWatchers — получатели событий диаграммы. Работает от своего
// фонового контекста: вызывается в том числе из горутин публикации,
// когда запрос уже завершён.
func (s *Server) chartWatchers(chartID uuid.UUID) []uuid.UUID {
	ctx, cancel := bgContext()
	defer cancel()
	var ids []uuid.UUID
	_ = s.db.AsService(ctx, func(tx pgx.Tx) error {
		rows, e := tx.Query(ctx, `SELECT * FROM app.chart_watchers($1)`, chartID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if e := rows.Scan(&id); e != nil {
				return e
			}
			ids = append(ids, id)
		}
		return rows.Err()
	})
	return ids
}

func (s *Server) publishChart(ch chart, action string) {
	watchers := s.chartWatchers(ch.ID)
	// myRole в событии — роль того, чьё действие вызвало рассылку.
	// Клиент подставляет свою, как и для проектов.
	s.hub.SendTo(watchers, realtime.Event{Type: "chart", Action: action, Payload: ch})
}

// publishChartItems сообщает участникам, что записи диаграммы
// изменились. Отдельные полосы в событие не кладём: связи между ними
// меняются пачкой, и перечитать список целиком проще и надёжнее, чем
// сшивать частичные изменения на клиенте.
func (s *Server) publishChartItems(chartID uuid.UUID) {
	watchers := s.chartWatchers(chartID)
	s.hub.SendTo(watchers, realtime.Event{
		Type: "chartItems", Action: "changed", Payload: fiber.Map{"chartId": chartID},
	})
}

// ── мелкие помощники ────────────────────────────────────────────────

// jsonOrNil превращает отсутствующий JSON в NULL: в запросах это
// означает «не менять», а пустой []byte pgx передал бы как невалидный
// jsonb и получил бы ошибку разбора.
func jsonOrNil(raw json.RawMessage) any {
	if len(raw) == 0 {
		return nil
	}
	return []byte(raw)
}

// textOrNil: пустая строка в необязательном текстовом поле — это
// «поле не прислали», а не «очистить». Описание очищается явным
// пробелом; такова цена простого COALESCE вместо указателей во всех
// полях формы.
func textOrNil(v string) any {
	if v == "" {
		return nil
	}
	return v
}

func textValue(v *string) string {
	if v == nil {
		return ""
	}
	return *v
}

// ── обсуждение и файлы на этапе ─────────────────────────────────────
//
// Свои таблицы, а не общие с задачами: у задач комментарии и вложения
// участвуют в счётчиках, активности и уведомлениях по задачам, и
// подмешивать туда этапы диаграмм значило бы ломать эти счётчики.
//
// Права наследуются от диаграммы: обсуждать может любой участник,
// включая исполнителя, — разговор не правка. Удалить чужое может
// только владелец диаграммы.

type chartComment struct {
	ID        uuid.UUID `json:"id"`
	ItemID    uuid.UUID `json:"itemId"`
	AuthorID  uuid.UUID `json:"authorId"`
	Body      string    `json:"body"`
	CreatedAt time.Time `json:"createdAt"`
	CanEdit   bool      `json:"canEdit"`
}

type chartAttachment struct {
	ID        uuid.UUID `json:"id"`
	ItemID    uuid.UUID `json:"itemId"`
	AuthorID  uuid.UUID `json:"authorId"`
	Title     string    `json:"title"`
	Filename  string    `json:"filename"`
	MIME      string    `json:"mime"`
	Size      int64     `json:"size"`
	CreatedAt time.Time `json:"createdAt"`
	CanEdit   bool      `json:"canEdit"`
}

func (s *Server) ListChartComments(c *fiber.Ctx) error {
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	comments := []chartComment{}
	files := []chartAttachment{}
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT id, item_id, author_id, body, created_at
			  FROM app.chart_comments WHERE item_id = $1 ORDER BY created_at`, itemID)
		if e != nil {
			return e
		}
		for rows.Next() {
			var cm chartComment
			if e := rows.Scan(&cm.ID, &cm.ItemID, &cm.AuthorID, &cm.Body, &cm.CreatedAt); e != nil {
				rows.Close()
				return e
			}
			cm.CanEdit = cm.AuthorID == uid
			comments = append(comments, cm)
		}
		rows.Close()
		if e := rows.Err(); e != nil {
			return e
		}

		frows, e := tx.Query(c.Context(), `
			SELECT a.id, a.item_id, a.author_id, a.title, f.filename, f.mime_type, f.size_bytes, a.created_at
			  FROM app.chart_attachments a JOIN app.files f ON f.id = a.file_id
			 WHERE a.item_id = $1 ORDER BY a.created_at`, itemID)
		if e != nil {
			return e
		}
		defer frows.Close()
		for frows.Next() {
			var at chartAttachment
			if e := frows.Scan(&at.ID, &at.ItemID, &at.AuthorID, &at.Title,
				&at.Filename, &at.MIME, &at.Size, &at.CreatedAt); e != nil {
				return e
			}
			at.CanEdit = at.AuthorID == uid
			files = append(files, at)
		}
		return frows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"comments": comments, "files": files})
}

type chartCommentInput struct {
	Body string `json:"body"`
}

func (s *Server) AddChartComment(c *fiber.Ctx) error {
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var in chartCommentInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	if strings.TrimSpace(in.Body) == "" {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "empty", "Комментарий пуст"))
	}
	uid := s.uid(c)
	var cm chartComment
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chart_comments (item_id, author_id, body)
			VALUES ($1, $2, $3)
			RETURNING id, item_id, author_id, body, created_at`,
			itemID, uid, strings.TrimSpace(in.Body)).
			Scan(&cm.ID, &cm.ItemID, &cm.AuthorID, &cm.Body, &cm.CreatedAt); e != nil {
			return e
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.chart_activity (item_id, actor_id, body) VALUES ($1, $2, $3)`,
			itemID, uid, "Добавлено замечание")
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	cm.CanEdit = true
	// Событие — чтобы окно этапа у остальных обновилось само, и
	// уведомление — чтобы замечание нашли и те, у кого диаграмма
	// сейчас не открыта.
	go s.publishChartComment(itemID, cm, "created")
	go s.notifyChartComment(itemID, uid, cm.Body)
	return httpx.JSON(c, fiber.StatusCreated, cm)
}

// publishChartComment рассылает изменение обсуждения участникам
// диаграммы. Событие отдельное от chartItems: там перечитывается весь
// список этапов, а здесь достаточно обновить одно открытое окно.
func (s *Server) publishChartComment(itemID uuid.UUID, payload any, action string) {
	ctx, cancel := bgContext()
	defer cancel()
	var chartID uuid.UUID
	if e := s.db.AsService(ctx, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `SELECT app.chart_of_item($1)`, itemID).Scan(&chartID)
	}); e != nil || chartID == uuid.Nil {
		return
	}
	s.hub.SendTo(s.chartWatchers(chartID), realtime.Event{
		Type: "chartComment", Action: action,
		Payload: fiber.Map{"chartId": chartID, "itemId": itemID, "comment": payload},
	})
	// Счётчики у этапа тоже изменились.
	s.publishChartItems(chartID)
}

// notifyChartFile — то же, что notifyChartComment, но про вложение.
func (s *Server) notifyChartFile(itemID, author uuid.UUID, filename string) {
	s.notifyChartActivity(itemID, author, func(who, item, chart string) string {
		return notifyPhrase(who, "приложил(а) файл «"+filename+"» к этапу «"+item+"»",
			"диаграмме", chart)
	})
}

// notifyChartComment сообщает остальным участникам диаграммы о новом
// замечании. Автору — не сообщаем: он и так знает, что написал.
func (s *Server) notifyChartComment(itemID, author uuid.UUID, body string) {
	// Длинное замечание в уведомлении обрезаем: в колокольчике строка
	// одна, и целая страница текста вытеснит остальные уведомления.
	short := body
	if len([]rune(short)) > 120 {
		short = string([]rune(short)[:120]) + "…"
	}
	s.notifyChartActivity(itemID, author, func(who, item, chart string) string {
		return notifyPhrase(who, "отправил(а) новое замечание «"+short+"» к этапу «"+item+"»",
			"диаграмме", chart)
	})
}

// notifyChartActivity — общая рассылка по участникам диаграммы.
//
// Текст собирает переданная функция: у замечания и у файла порядок
// слов разный, а подставлять куски в общий шаблон значит получить
// фразу вроде «написал в этапе «Монтаж»: сроки в диаграмме «Стройка»».
func (s *Server) notifyChartActivity(itemID, author uuid.UUID,
	compose func(who, item, chart string) string) {
	ctx, cancel := bgContext()
	defer cancel()

	var chartID uuid.UUID
	var chartTitle, itemTitle, authorName string
	if e := s.db.AsService(ctx, func(tx pgx.Tx) error {
		return tx.QueryRow(ctx, `
			SELECT c.id, c.title, i.title, u.full_name
			  FROM app.chart_items i
			  JOIN app.charts c ON c.id = i.chart_id
			  JOIN app.users u ON u.id = $2
			 WHERE i.id = $1`, itemID, author).
			Scan(&chartID, &chartTitle, &itemTitle, &authorName)
	}); e != nil {
		return
	}

	text := compose(authorName, itemTitle, chartTitle)

	for _, uid := range s.chartWatchers(chartID) {
		if uid == author {
			continue
		}
		var nid uuid.UUID
		var createdAt time.Time
		e := s.db.AsService(ctx, func(tx pgx.Tx) error {
			return tx.QueryRow(ctx,
				`SELECT id, created_at FROM app.notify_obj($1, $2, 'comment', $3, NULL)`,
				uid, text, chartID).Scan(&nid, &createdAt)
		})
		if e != nil {
			continue // категория отключена получателем
		}
		n := notifModel(nid, createdAt, text)
		n.ChartID = &chartID
		s.publishNotification(uid, n)
		s.pingNotifications([]uuid.UUID{uid})
	}
}

func (s *Server) DeleteChartComment(c *fiber.Ctx) error {
	id, err := param(c, "commentID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var itemID uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// RETURNING сразу даёт этап, к которому относилось замечание:
		// после удаления узнать его было бы уже неоткуда, а он нужен
		// для рассылки события.
		e := tx.QueryRow(c.Context(),
			`DELETE FROM app.chart_comments WHERE id = $1 RETURNING item_id`, id).Scan(&itemID)
		if errors.Is(e, pgx.ErrNoRows) {
			return httpx.ErrForbidden
		}
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChartComment(itemID, fiber.Map{"id": id}, "deleted")
	return httpx.NoContent(c)
}

func (s *Server) UploadChartFile(c *fiber.Ctx) error {
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	header, err := c.FormFile("file")
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "no_file", "Файл не передан"))
	}
	f, err := header.Open()
	if err != nil {
		return httpx.Fail(c, err)
	}
	defer f.Close()

	stored, err := s.files.Save(f, header.Filename)
	if err != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusBadRequest, "upload_failed", err.Error()))
	}

	var at chartAttachment
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		var fileID uuid.UUID
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.files (owner_id, storage_key, filename, mime_type, size_bytes, checksum)
			VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
			uid, stored.Key, stored.Filename, stored.MIME, stored.Size, stored.Checksum).Scan(&fileID); e != nil {
			return e
		}
		if e := tx.QueryRow(c.Context(), `
			INSERT INTO app.chart_attachments (item_id, file_id, author_id, title)
			VALUES ($1, $2, $3, $4)
			RETURNING id, item_id, author_id, title, created_at`,
			itemID, fileID, uid, stored.Filename).
			Scan(&at.ID, &at.ItemID, &at.AuthorID, &at.Title, &at.CreatedAt); e != nil {
			return e
		}
		_, e := tx.Exec(c.Context(), `
			INSERT INTO app.chart_activity (item_id, actor_id, body) VALUES ($1, $2, $3)`,
			itemID, uid, "Приложен файл «"+stored.Filename+"»")
		return e
	})
	if err != nil {
		// Строка не записалась — файл на диске никому не нужен.
		_ = s.files.Delete(stored.Key)
		return httpx.Fail(c, err)
	}
	at.Filename = stored.Filename
	at.MIME = stored.MIME
	at.Size = stored.Size
	at.CanEdit = true
	go s.publishChartComment(itemID, nil, "files")
	// Файл — такое же событие в работе, как замечание, и уведомлять о
	// нём нужно теми же словами: иначе приложенная смета остаётся
	// незамеченной, пока кто-нибудь случайно не откроет этап.
	go s.notifyChartFile(itemID, uid, stored.Filename)
	return httpx.JSON(c, fiber.StatusCreated, at)
}

// DownloadChartFile отдаёт содержимое. Право на файл вытекает из права
// на диаграмму: политика files_select_chart_attachments пускает к
// строке только того, кто видит этап.
func (s *Server) DownloadChartFile(c *fiber.Ctx) error {
	id, err := param(c, "fileID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var key, mimeType, filename string
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.mime_type, f.filename
			  FROM app.chart_attachments a JOIN app.files f ON f.id = a.file_id
			 WHERE a.id = $1`, id).Scan(&key, &mimeType, &filename)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.stream(c, key, mimeType, filename, c.Query("download") == "1")
}

// PreviewChartFile отдаёт офисный документ, превращённый в PDF: иначе
// таблицу или .docx с этапа нельзя посмотреть, не скачивая. Путь и
// преобразование те же, что у вложений задач.
func (s *Server) PreviewChartFile(c *fiber.Ctx) error {
	id, err := param(c, "fileID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	var key, filename string
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT f.storage_key, f.filename
			  FROM app.chart_attachments a JOIN app.files f ON f.id = a.file_id
			 WHERE a.id = $1`, id).Scan(&key, &filename)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrNotFound)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}
	data, e := s.convertToPDF(c.Context(), key, filename)
	if e != nil {
		return httpx.Fail(c, httpx.Err(fiber.StatusUnprocessableEntity, "convert_failed", e.Error()))
	}
	return sendConvertedPDF(c, data, filename)
}

func (s *Server) DeleteChartFile(c *fiber.Ctx) error {
	id, err := param(c, "fileID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)
	var itemID uuid.UUID
	err = s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		e := tx.QueryRow(c.Context(),
			`DELETE FROM app.chart_attachments WHERE id = $1 RETURNING item_id`, id).Scan(&itemID)
		if errors.Is(e, pgx.ErrNoRows) {
			return httpx.ErrForbidden
		}
		return e
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	go s.publishChartComment(itemID, nil, "files")
	return httpx.NoContent(c)
}


// ── приглашение участникам ──────────────────────────────────────────
//
// Сам вызов и письмо уходят с машины человека (клиент телефонии и
// почтовая программа) — сервер к ним отношения не имеет. Но участники
// должны узнать о сборе, даже если телефон не под рукой: поэтому
// приглашение дублируется уведомлением внутри приложения, со ссылкой
// на саму диаграмму или доску.

type inviteInput struct {
	// call — зовём на видеоконференцию; review — просим ознакомиться.
	Kind string `json:"kind"`
	// Необязательная приписка от зовущего.
	Note string `json:"note"`
}

func (s *Server) InviteToChart(c *fiber.Ctx) error {
	chartID, err := param(c, "chartID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.sendInvite(c, "chart", chartID)
}

func (s *Server) InviteToWhiteboard(c *fiber.Ctx) error {
	boardID, err := param(c, "wbID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	return s.sendInvite(c, "whiteboard", boardID)
}

func (s *Server) sendInvite(c *fiber.Ctx, kind string, id uuid.UUID) error {
	var in inviteInput
	if err := httpx.Decode(c, &in); err != nil {
		return httpx.Fail(c, err)
	}
	uid := s.uid(c)

	var title, actor string
	err := s.db.AsUser(c.Context(), uid, func(tx pgx.Tx) error {
		// Запрос идёт от имени пользователя: политики сами не дадут
		// разослать приглашение к чужому объекту.
		q := `SELECT c.title, u.full_name FROM app.charts c, app.users u
		       WHERE c.id = $1 AND u.id = $2`
		if kind == "whiteboard" {
			q = `SELECT w.title, u.full_name FROM app.whiteboards w, app.users u
			      WHERE w.id = $1 AND u.id = $2`
		}
		return tx.QueryRow(c.Context(), q, id, uid).Scan(&title, &actor)
	})
	if errors.Is(err, pgx.ErrNoRows) {
		return httpx.Fail(c, httpx.ErrForbidden)
	}
	if err != nil {
		return httpx.Fail(c, err)
	}

	// Тот же порядок, что у всех уведомлений: кто, что, где.
	var body string
	switch {
	case kind == "whiteboard":
		body = notifyPhrase(actor, "приглашает принять участие в совместном обсуждении",
			"доске", title)
	case in.Kind == "call":
		body = notifyPhrase(actor, "приглашает на видеоконференцию", "диаграмме", title)
	default:
		body = notifyPhrase(actor, "просит ознакомиться с работами", "диаграмме", title)
	}
	if note := strings.TrimSpace(in.Note); note != "" {
		body += ". " + note
	}

	go s.fanOutInvite(kind, id, uid, body)
	return httpx.JSON(c, fiber.StatusOK, fiber.Map{"sent": true})
}

func (s *Server) fanOutInvite(kind string, id, actor uuid.UUID, body string) {
	ctx, cancel := bgContext()
	defer cancel()

	var targets []uuid.UUID
	if kind == "chart" {
		targets = s.chartWatchers(id)
	} else {
		targets = s.wbWatchers(id)
	}

	for _, uid := range targets {
		if uid == actor {
			continue
		}
		var chartID, wbID any
		if kind == "chart" {
			chartID = id
		} else {
			wbID = id
		}
		var nid uuid.UUID
		var createdAt time.Time
		e := s.db.AsService(ctx, func(tx pgx.Tx) error {
			return tx.QueryRow(ctx,
				`SELECT id, created_at FROM app.notify_obj($1, $2, 'membership', $3, $4)`,
				uid, body, chartID, wbID).Scan(&nid, &createdAt)
		})
		if e != nil {
			continue
		}
		n := notifModel(nid, createdAt, body)
		if kind == "chart" {
			n.ChartID = &id
		} else {
			n.WhiteboardID = &id
		}
		s.publishNotification(uid, n)
		s.pingNotifications([]uuid.UUID{uid})
	}
}

// ── история этапа ───────────────────────────────────────────────────

type chartActivity struct {
	ID        uuid.UUID  `json:"id"`
	ActorID   *uuid.UUID `json:"actorId"`
	Body      string     `json:"body"`
	CreatedAt time.Time  `json:"createdAt"`
}

func (s *Server) ListChartActivity(c *fiber.Ctx) error {
	itemID, err := param(c, "itemID")
	if err != nil {
		return httpx.Fail(c, err)
	}
	out := []chartActivity{}
	err = s.db.AsUser(c.Context(), s.uid(c), func(tx pgx.Tx) error {
		rows, e := tx.Query(c.Context(), `
			SELECT id, actor_id, body, created_at
			  FROM app.chart_activity
			 WHERE item_id = $1
			 ORDER BY created_at DESC
			 LIMIT 200`, itemID)
		if e != nil {
			return e
		}
		defer rows.Close()
		for rows.Next() {
			var a chartActivity
			if e := rows.Scan(&a.ID, &a.ActorID, &a.Body, &a.CreatedAt); e != nil {
				return e
			}
			out = append(out, a)
		}
		return rows.Err()
	})
	if err != nil {
		return httpx.Fail(c, err)
	}
	return httpx.JSON(c, fiber.StatusOK, out)
}
