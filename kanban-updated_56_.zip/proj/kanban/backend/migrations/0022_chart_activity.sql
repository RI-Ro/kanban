-- =====================================================================
-- 0022_chart_activity.sql — история этапов диаграммы.
--
-- Устроена как история задачи (app.activity) и по той же причине: через
-- месяц после переноса сроков никто не помнит, кто их двигал и почему
-- этап оказался в этих датах. Запись строкой, а не структурой: текст
-- читается человеком и не ломается при изменении набора полей этапа.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0022_chart_activity.sql
--
-- Запускать от app_owner, после 0021. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

CREATE TABLE IF NOT EXISTS app.chart_activity (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id    uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    -- Автор может быть удалён, а запись истории остаётся: она о том,
    -- что произошло, а не о том, кто ещё работает в системе.
    actor_id   uuid REFERENCES app.users(id) ON DELETE SET NULL,
    body       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chart_activity_item_idx
    ON app.chart_activity (item_id, created_at DESC);

ALTER TABLE app.chart_activity ENABLE ROW LEVEL SECURITY;

-- Читают все участники диаграммы, включая исполнителя: история — это
-- то же, что видно на полотне, только словами.
DROP POLICY IF EXISTS chart_activity_select ON app.chart_activity;
CREATE POLICY chart_activity_select ON app.chart_activity FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Писать может любой участник — но только от своего имени. Записи
-- появляются как следствие действий (правка этапа, замечание, файл), и
-- отдельной кнопки «добавить в историю» нет.
DROP POLICY IF EXISTS chart_activity_insert ON app.chart_activity;
CREATE POLICY chart_activity_insert ON app.chart_activity FOR INSERT
    WITH CHECK (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id())
                AND actor_id = app.current_user_id());

-- Историю не правят и не удаляют: смысл её в том, что записанное
-- нельзя переписать задним числом. Политик UPDATE и DELETE нет вовсе —
-- при включённом RLS это и означает запрет.

GRANT SELECT, INSERT ON app.chart_activity TO app_user;

-- Готово.
