-- =====================================================================
-- 0020_charts_whiteboards.sql — две новые области:
--
--   1. ДИАГРАММЫ (Ганта). Крупная картина этапов работ: полосы со
--      сроками, связи «следующий за» и ссылки на задачи проектов.
--   2. СОВМЕСТНЫЕ ДОСКИ. Бесконечный холст с фигурами, стикерами,
--      линиями и текстом, который несколько человек правят
--      одновременно.
--
-- Общее у них — модель прав, ровно та же, что у проектов: владелец
-- (автор), редактор, исполнитель. Она уже описана функциями
-- app.board_role / app.can_edit_board и проверена временем, поэтому
-- здесь она повторена один в один, только по своим таблицам
-- участников. Заводить «универсальную» таблицу прав на всё сразу
-- заманчиво, но тогда любая ошибка в ней открывает доступ ко всем трём
-- областям разом; отдельные таблицы дешевле и безопаснее.
--
-- Замещение учитывается везде через app.effective_users: заместитель
-- видит диаграммы и доски того, кого замещает, — иначе на время
-- отпуска работа встала бы.
--
-- Важно про диаграммы: их записи — самостоятельные, это НЕ задачи
-- приложения. Они не попадают ни в календарь, ни во «Все задачи», ни в
-- уведомления по задачам. Связь с задачей проекта — только ссылка,
-- добровольная и необязательная.
--
--     psql "$DB" -v ON_ERROR_STOP=1 -f backend/migrations/0020_charts_whiteboards.sql
--
-- Запускать от app_owner, после 0019_ready_into_report.sql. Идемпотентна.
-- =====================================================================

SET search_path = app, public;

-- ─────────────────────────────────────────────────────────────────────
-- 1. ДИАГРАММЫ.
-- ─────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app.charts (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    -- Пользовательские параметры вида: масштаб (день/неделя/месяц),
    -- показывать ли выходные, цвет по умолчанию и прочее. Отдельными
    -- колонками это заводить рано: набор настроек будет меняться, а
    -- миграция на каждую галочку — плохой обмен. Структура JSON
    -- описана и проверяется на стороне приложения.
    settings    jsonb NOT NULL DEFAULT '{}'::jsonb,
    position    integer NOT NULL DEFAULT 0,
    archived    boolean NOT NULL DEFAULT false,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.chart_members (
    chart_id uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)  ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (chart_id, user_id)
);

CREATE INDEX IF NOT EXISTS chart_members_user_idx ON app.chart_members (user_id);

-- Запись диаграммы. Это самостоятельная сущность: своё название, свои
-- даты, свой прогресс. С задачами приложения её связывают только
-- необязательные ссылки (chart_item_tasks).
CREATE TABLE IF NOT EXISTS app.chart_items (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chart_id    uuid NOT NULL REFERENCES app.charts(id) ON DELETE CASCADE,
    title       text NOT NULL CHECK (length(btrim(title)) > 0),
    description text NOT NULL DEFAULT '',
    starts_on   date NOT NULL,
    ends_on     date NOT NULL,
    -- Процент готовности рисуется заливкой внутри полосы. Ограничение
    -- в базе, а не только в форме: полоса, залитая на 140%, вылезет за
    -- свои границы и испортит картину.
    progress    smallint NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    color       text NOT NULL DEFAULT '',
    -- Веха — событие без длительности («сдача этапа»), рисуется ромбом.
    -- Для неё ends_on равен starts_on.
    milestone   boolean NOT NULL DEFAULT false,
    position    integer NOT NULL DEFAULT 0,
    created_by  uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    -- Конец не раньше начала. Проверка именно здесь: перевёрнутая
    -- полоса — это не «странная картинка», а запись, которую нельзя
    -- осмысленно нарисовать.
    CHECK (ends_on >= starts_on)
);

CREATE INDEX IF NOT EXISTS chart_items_chart_idx ON app.chart_items (chart_id, position);

-- Связь «за этой записью следует эта». Направленная, с запретом петли
-- на себя. Кратные дубли отсекает первичный ключ.
CREATE TABLE IF NOT EXISTS app.chart_links (
    from_item uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    to_item   uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    PRIMARY KEY (from_item, to_item),
    CHECK (from_item <> to_item)
);

CREATE INDEX IF NOT EXISTS chart_links_to_idx ON app.chart_links (to_item);

-- Ссылки на задачи приложения. Задача может быть упомянута в разных
-- диаграммах, запись — ссылаться на несколько задач.
--
-- ON DELETE CASCADE по задаче: удалили задачу — ссылка исчезает, а
-- сама запись диаграммы остаётся. Это осознанно: диаграмма живёт
-- своей жизнью и не должна рассыпаться от уборки в проектах.
CREATE TABLE IF NOT EXISTS app.chart_item_tasks (
    item_id uuid NOT NULL REFERENCES app.chart_items(id) ON DELETE CASCADE,
    task_id uuid NOT NULL REFERENCES app.tasks(id)       ON DELETE CASCADE,
    PRIMARY KEY (item_id, task_id)
);

CREATE INDEX IF NOT EXISTS chart_item_tasks_task_idx ON app.chart_item_tasks (task_id);

-- Роль в диаграмме с учётом замещения — копия app.board_role.
CREATE OR REPLACE FUNCTION app.chart_role(p_chart uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.chart_members m
     WHERE m.chart_id = p_chart
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app.can_see_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IS NOT NULL $$;

CREATE OR REPLACE FUNCTION app.can_edit_chart(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) IN ('owner', 'editor') $$;

CREATE OR REPLACE FUNCTION app.is_chart_owner(p_chart uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.chart_role(p_chart, p_user) = 'owner' $$;

-- Кому рассылать события по диаграмме: участники и их заместители.
CREATE OR REPLACE FUNCTION app.chart_watchers(p_chart uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.chart_members m WHERE m.chart_id = p_chart
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.chart_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.chart_id = p_chart
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

-- Владелец записывается триггером — как у проектов: сразу после
-- INSERT в charts пользователь ещё не участник и не прошёл бы
-- политику chart_members.
CREATE OR REPLACE FUNCTION app.chart_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.chart_members (chart_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS charts_owner_bootstrap ON app.charts;
CREATE TRIGGER charts_owner_bootstrap AFTER INSERT ON app.charts
    FOR EACH ROW EXECUTE FUNCTION app.chart_owner_bootstrap();

-- Название задачи, если она видна смотрящему, иначе NULL.
--
-- Ровно та же мысль, что в напоминаниях (app.task_title_visible):
-- ссылка на задачу из чужого проекта не должна раскрывать её
-- заголовок. Интерфейс в этом случае пишет, что подробностей нет.
CREATE OR REPLACE FUNCTION app.chart_task_brief(p_task uuid, p_user uuid)
RETURNS TABLE (task_id uuid, title text, board_title text, completed boolean, visible boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT t.id,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.title ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN app.board_title(t.board_id) ELSE '' END,
           CASE WHEN app.can_see_task(t.id, p_user) THEN t.completed_at IS NOT NULL ELSE false END,
           app.can_see_task(t.id, p_user)
      FROM app.tasks t
     WHERE t.id = p_task
$$;

ALTER TABLE app.charts           ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_items      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_links      ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.chart_item_tasks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS charts_select ON app.charts;
CREATE POLICY charts_select ON app.charts FOR SELECT
    USING (app.can_see_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_insert ON app.charts;
CREATE POLICY charts_insert ON app.charts FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

-- Правка самой диаграммы (название, настройки вида) — владельцу и
-- редактору: настройка масштаба это часть работы над диаграммой, а не
-- распоряжение ею.
DROP POLICY IF EXISTS charts_update ON app.charts;
CREATE POLICY charts_update ON app.charts FOR UPDATE
    USING (app.can_edit_chart(id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(id, app.current_user_id()));

DROP POLICY IF EXISTS charts_delete ON app.charts;
CREATE POLICY charts_delete ON app.charts FOR DELETE
    USING (app.is_chart_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_select ON app.chart_members;
CREATE POLICY chart_members_select ON app.chart_members FOR SELECT
    USING (app.chart_role(chart_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS chart_members_write ON app.chart_members;
CREATE POLICY chart_members_write ON app.chart_members FOR INSERT
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_update ON app.chart_members;
CREATE POLICY chart_members_update ON app.chart_members FOR UPDATE
    USING (app.is_chart_owner(chart_id, app.current_user_id()))
    WITH CHECK (app.is_chart_owner(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_members_delete ON app.chart_members;
CREATE POLICY chart_members_delete ON app.chart_members FOR DELETE
    USING (
        (app.is_chart_owner(chart_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS chart_items_select ON app.chart_items;
CREATE POLICY chart_items_select ON app.chart_items FOR SELECT
    USING (app.can_see_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_write ON app.chart_items;
CREATE POLICY chart_items_write ON app.chart_items FOR INSERT
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id())
                AND created_by = app.current_user_id());

DROP POLICY IF EXISTS chart_items_update ON app.chart_items;
CREATE POLICY chart_items_update ON app.chart_items FOR UPDATE
    USING (app.can_edit_chart(chart_id, app.current_user_id()))
    WITH CHECK (app.can_edit_chart(chart_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_items_delete ON app.chart_items;
CREATE POLICY chart_items_delete ON app.chart_items FOR DELETE
    USING (app.can_edit_chart(chart_id, app.current_user_id()));

-- Связи и ссылки на задачи живут по правам своей записи: отдельных
-- прав у них нет и быть не должно.
CREATE OR REPLACE FUNCTION app.chart_of_item(p_item uuid)
RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$ SELECT chart_id FROM app.chart_items WHERE id = p_item $$;

DROP POLICY IF EXISTS chart_links_select ON app.chart_links;
CREATE POLICY chart_links_select ON app.chart_links FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_links_write ON app.chart_links;
CREATE POLICY chart_links_write ON app.chart_links FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id())
        -- Связывать можно только записи одной диаграммы: связь между
        -- разными диаграммами нечем нарисовать, а права по ней
        -- пришлось бы считать дважды.
        AND app.chart_of_item(from_item) = app.chart_of_item(to_item));

DROP POLICY IF EXISTS chart_links_delete ON app.chart_links;
CREATE POLICY chart_links_delete ON app.chart_links FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(from_item), app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_select ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_select ON app.chart_item_tasks FOR SELECT
    USING (app.can_see_chart(app.chart_of_item(item_id), app.current_user_id()));

-- Привязать можно только ВИДИМУЮ задачу: иначе ссылку на чужую задачу
-- можно было бы поставить наугад по идентификатору. Видеть её потом
-- смогут не все — это нормально и предусмотрено интерфейсом.
DROP POLICY IF EXISTS chart_item_tasks_write ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_write ON app.chart_item_tasks FOR INSERT
    WITH CHECK (
        app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id())
        AND app.can_see_task(task_id, app.current_user_id()));

DROP POLICY IF EXISTS chart_item_tasks_delete ON app.chart_item_tasks;
CREATE POLICY chart_item_tasks_delete ON app.chart_item_tasks FOR DELETE
    USING (app.can_edit_chart(app.chart_of_item(item_id), app.current_user_id()));

-- ─────────────────────────────────────────────────────────────────────
-- 2. СОВМЕСТНЫЕ ДОСКИ.
-- ─────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS app.whiteboards (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title      text NOT NULL CHECK (length(btrim(title)) > 0),
    position   integer NOT NULL DEFAULT 0,
    archived   boolean NOT NULL DEFAULT false,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.whiteboard_members (
    board_id uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    user_id  uuid NOT NULL REFERENCES app.users(id)       ON DELETE CASCADE,
    role     app.board_role NOT NULL DEFAULT 'reader',
    PRIMARY KEY (board_id, user_id)
);

CREATE INDEX IF NOT EXISTS whiteboard_members_user_idx ON app.whiteboard_members (user_id);

-- Фигура на холсте.
--
-- Геометрия вынесена в колонки (x, y, w, h, angle, z): по ним идут
-- перетаскивание и выборка, и держать их внутри JSON значило бы
-- разбирать JSON на каждое движение мыши. Всё остальное — текст,
-- цвета, толщина пера, точки ломаной, концы стрелки — в data: набор
-- свойств у стикера, линии и рисунка пером разный, и колонки под
-- каждый вид превратили бы таблицу в лоскутное одеяло.
--
-- kind проверяется списком: неизвестный вид клиент не нарисует, а
-- молча потерянная фигура выглядит как пропавшая работа.
CREATE TABLE IF NOT EXISTS app.whiteboard_shapes (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    board_id   uuid NOT NULL REFERENCES app.whiteboards(id) ON DELETE CASCADE,
    kind       text NOT NULL CHECK (kind IN
                 ('note', 'rect', 'ellipse', 'diamond', 'triangle', 'text',
                  'line', 'arrow', 'draw', 'image', 'frame')),
    x          double precision NOT NULL DEFAULT 0,
    y          double precision NOT NULL DEFAULT 0,
    w          double precision NOT NULL DEFAULT 160,
    h          double precision NOT NULL DEFAULT 120,
    angle      double precision NOT NULL DEFAULT 0,
    z          integer NOT NULL DEFAULT 0,
    data       jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    updated_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS whiteboard_shapes_board_idx ON app.whiteboard_shapes (board_id, z);

CREATE OR REPLACE FUNCTION app.wb_role(p_board uuid, p_user uuid)
RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT m.role::text
      FROM app.whiteboard_members m
     WHERE m.board_id = p_board
       AND m.user_id IN (SELECT app.effective_users(p_user))
     ORDER BY CASE m.role WHEN 'owner' THEN 3 WHEN 'editor' THEN 2 ELSE 1 END DESC
     LIMIT 1
$$;

CREATE OR REPLACE FUNCTION app.can_see_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IS NOT NULL $$;

CREATE OR REPLACE FUNCTION app.can_edit_wb(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) IN ('owner', 'editor') $$;

CREATE OR REPLACE FUNCTION app.is_wb_owner(p_board uuid, p_user uuid)
RETURNS boolean LANGUAGE sql STABLE
AS $$ SELECT app.wb_role(p_board, p_user) = 'owner' $$;

CREATE OR REPLACE FUNCTION app.wb_watchers(p_board uuid)
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = app, public
AS $$
    SELECT DISTINCT m.user_id FROM app.whiteboard_members m WHERE m.board_id = p_board
    UNION
    SELECT DISTINCT d.deputy_id
      FROM app.whiteboard_members m
      JOIN app.delegations d ON d.grantor_id = m.user_id
     WHERE m.board_id = p_board
       AND current_date BETWEEN d.starts_at AND d.ends_at
$$;

CREATE OR REPLACE FUNCTION app.wb_owner_bootstrap() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = app, public AS $$
BEGIN
    INSERT INTO app.whiteboard_members (board_id, user_id, role)
    VALUES (NEW.id, NEW.created_by, 'owner');
    RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS whiteboards_owner_bootstrap ON app.whiteboards;
CREATE TRIGGER whiteboards_owner_bootstrap AFTER INSERT ON app.whiteboards
    FOR EACH ROW EXECUTE FUNCTION app.wb_owner_bootstrap();

ALTER TABLE app.whiteboards        ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE app.whiteboard_shapes  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS whiteboards_select ON app.whiteboards;
CREATE POLICY whiteboards_select ON app.whiteboards FOR SELECT
    USING (app.can_see_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_insert ON app.whiteboards;
CREATE POLICY whiteboards_insert ON app.whiteboards FOR INSERT
    WITH CHECK (created_by = app.current_user_id());

DROP POLICY IF EXISTS whiteboards_update ON app.whiteboards;
CREATE POLICY whiteboards_update ON app.whiteboards FOR UPDATE
    USING (app.can_edit_wb(id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboards_delete ON app.whiteboards;
CREATE POLICY whiteboards_delete ON app.whiteboards FOR DELETE
    USING (app.is_wb_owner(id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_select ON app.whiteboard_members;
CREATE POLICY whiteboard_members_select ON app.whiteboard_members FOR SELECT
    USING (app.wb_role(board_id, app.current_user_id()) IS NOT NULL);

DROP POLICY IF EXISTS whiteboard_members_write ON app.whiteboard_members;
CREATE POLICY whiteboard_members_write ON app.whiteboard_members FOR INSERT
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_update ON app.whiteboard_members;
CREATE POLICY whiteboard_members_update ON app.whiteboard_members FOR UPDATE
    USING (app.is_wb_owner(board_id, app.current_user_id()))
    WITH CHECK (app.is_wb_owner(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_members_delete ON app.whiteboard_members;
CREATE POLICY whiteboard_members_delete ON app.whiteboard_members FOR DELETE
    USING (
        (app.is_wb_owner(board_id, app.current_user_id()) AND role <> 'owner')
        OR (user_id = app.current_user_id() AND role <> 'owner')
    );

DROP POLICY IF EXISTS whiteboard_shapes_select ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_select ON app.whiteboard_shapes FOR SELECT
    USING (app.can_see_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_write ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_write ON app.whiteboard_shapes FOR INSERT
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id())
                AND created_by = app.current_user_id());

-- Правит любой редактор, а не только автор фигуры: доска общая, и
-- двигать чужой стикер — обычное дело при совместной работе.
DROP POLICY IF EXISTS whiteboard_shapes_update ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_update ON app.whiteboard_shapes FOR UPDATE
    USING (app.can_edit_wb(board_id, app.current_user_id()))
    WITH CHECK (app.can_edit_wb(board_id, app.current_user_id()));

DROP POLICY IF EXISTS whiteboard_shapes_delete ON app.whiteboard_shapes;
CREATE POLICY whiteboard_shapes_delete ON app.whiteboard_shapes FOR DELETE
    USING (app.can_edit_wb(board_id, app.current_user_id()));

-- ─────────────────────────────────────────────────────────────────────
-- 3. ПРИВИЛЕГИИ.
-- ─────────────────────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON app.charts             TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_members      TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_items        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_links        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.chart_item_tasks   TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboards        TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_members TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON app.whiteboard_shapes  TO app_user;

GRANT EXECUTE ON FUNCTION app.chart_role(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_chart(uuid, uuid)     TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_chart(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.is_chart_owner(uuid, uuid)    TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_watchers(uuid)          TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_of_item(uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.chart_task_brief(uuid, uuid)  TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_role(uuid, uuid)           TO app_user;
GRANT EXECUTE ON FUNCTION app.can_see_wb(uuid, uuid)        TO app_user;
GRANT EXECUTE ON FUNCTION app.can_edit_wb(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.is_wb_owner(uuid, uuid)       TO app_user;
GRANT EXECUTE ON FUNCTION app.wb_watchers(uuid)             TO app_user;

-- Готово.
