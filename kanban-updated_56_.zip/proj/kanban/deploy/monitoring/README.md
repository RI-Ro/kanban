# Наблюдение за «Командой»: Prometheus и Grafana

Приложение само отдаёт метрики на `GET /metrics` в текстовом формате
Prometheus. Отдельный экспортёр для PostgreSQL не нужен — статистику
базы собирает тот же процесс раз в 15 секунд запросами к `pg_stat_*`,
поэтому цель для сбора одна на экземпляр.

## Быстрый запуск

```bash
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d
```

* Grafana — <http://localhost:3000> (вход `admin` / `admin`, меняется
  переменными `GRAFANA_USER` и `GRAFANA_PASSWORD`);
* Prometheus — <http://localhost:9090>.

Источник данных и оба дашборда в папке «Команда» подключаются сами —
импортировать ничего не нужно.

## Если Prometheus и Grafana уже есть

1. Добавьте цель в свой `prometheus.yml` (пример — `prometheus.yml`
   рядом):

   ```yaml
   - job_name: kanban
     metrics_path: /metrics
     static_configs:
       - targets: ["api-1:8080", "api-2:8080"]
   ```

2. По желанию подключите правила оповещений из `rules/kanban.yml`.
3. В Grafana: **Dashboards → New → Import → Upload JSON** и выберите
   `grafana/dashboards/kanban-app.json`, затем `kanban-db.json`.
   Источник данных выбирается переменной в шапке дашборда.

## Дашборды

**Команда · приложение** (`kanban-app`) — время исполнения запросов и
нагрузка:

* сводка: RPS, доля ошибок, p95 и p99, запросов в обработке, время работы;
* поток запросов по маршрутам и по статусам ответа;
* перцентили времени ответа (p50/p90/p95/p99 и среднее) и тепловая карта
  распределения — на ней видно, где лежит основная масса запросов, а где
  единичные выбросы;
* сводная таблица по маршрутам: запросов в секунду, среднее, p95, p99,
  ошибок в секунду — сортируется по любой колонке;
* самые медленные маршруты и ошибки по маршрутам;
* размер ответа и исходящий трафик;
* события WebSocket, подключения, прикладные события, количество
  объектов в системе.

**Команда · база данных** (`kanban-db`) — состояние PostgreSQL и пула:

* сводка: размер базы, попадания в кэш, соединения, доля откатов,
  самая долгая транзакция, блокировки в ожидании;
* пул соединений приложения: занято/свободно против предела, загрузка
  в процентах, ожидания пустого пула;
* транзакции приложения по типу и перцентили их длительности;
* ошибки при работе с базой и взаимные блокировки;
* фиксации и откаты, блоки из кэша и с диска, просмотренные и
  возвращённые строки;
* соединения по состоянию и длительность долгих операций, включая
  простой в открытой транзакции;
* таблицы: объём, живые и мёртвые строки, давность очистки,
  последовательные чтения против чтений по индексу.

Переменная **Экземпляр** в шапке обоих дашбордов позволяет смотреть один
сервер или все сразу.

## Что означают метрики

### Приложение

| Метрика | Тип | Метки | Смысл |
|---|---|---|---|
| `kanban_http_requests_total` | counter | `method`, `route`, `status` | обработано запросов |
| `kanban_http_request_duration_seconds` | histogram | `method`, `route` | время обработки запроса |
| `kanban_http_response_bytes` | histogram | `method`, `route` | размер ответа |
| `kanban_http_requests_in_flight` | gauge | — | запросов выполняется сейчас |
| `kanban_ws_events_total` | counter | `type` | отправлено событий по WebSocket |
| `kanban_ws_connections`, `kanban_ws_users` | gauge | — | подключений и пользователей онлайн |
| `kanban_app_events_total` | counter | `event` | прикладные события |
| `kanban_entities` | gauge | `kind` | объектов в системе |
| `kanban_uptime_seconds` | gauge | — | время с перезапуска |

Метка `route` — это **шаблон** маршрута (`/api/tasks/:id`), а не
конкретный путь. Иначе число значений метки росло бы вместе с числом
задач, и Prometheus такого не выдерживает.

### База данных

| Метрика | Тип | Метки | Смысл |
|---|---|---|---|
| `kanban_db_queries_total` | counter | `op` | транзакций к базе |
| `kanban_db_query_duration_seconds` | histogram | `op` | длительность транзакции |
| `kanban_db_errors_total` | counter | — | ошибок при работе с базой |
| `kanban_db_pool_*` | gauge | — | `total`, `acquired`, `idle`, `max`, `empty_acquires` |
| `pg_database_size_bytes` | gauge | `datname` | размер базы |
| `pg_connections` | gauge | `state` | соединения по состоянию |
| `pg_max_connections` | gauge | — | предел `max_connections` |
| `pg_xact_commit_total`, `pg_xact_rollback_total` | counter | — | фиксации и откаты |
| `pg_blks_hit_total`, `pg_blks_read_total` | counter | — | блоки из кэша и с диска |
| `pg_tup_returned_total`, `pg_tup_fetched_total` | counter | — | просмотрено и возвращено строк |
| `pg_deadlocks_total` | counter | — | взаимные блокировки |
| `pg_locks_waiting` | gauge | — | блокировок в ожидании |
| `pg_longest_query_seconds` | gauge | — | самый долгий запрос |
| `pg_longest_transaction_seconds` | gauge | — | самая долгая транзакция |
| `pg_idle_in_transaction_seconds` | gauge | — | простой в открытой транзакции |
| `pg_table_size_bytes`, `pg_table_live_rows`, `pg_table_dead_rows`, `pg_table_seq_scan_total`, `pg_table_idx_scan_total`, `pg_table_vacuum_age_seconds` | gauge/counter | `table` | по двадцати крупнейшим таблицам схемы `app` |

Метка `op` в метриках транзакций — крупная операция (`user_tx`,
`service_tx`), а не текст запроса: текстов тысячи, и метки по ним
Prometheus не выдержит.

## Настройки

| Переменная | По умолчанию | Назначение |
|---|---|---|
| `METRICS_ENABLED` | `true` | сбор метрик и путь `/metrics` |
| `PROM_PORT` | `9090` | порт Prometheus |
| `PROM_RETENTION` | `30d` | срок хранения |
| `GRAFANA_PORT` | `3000` | порт Grafana |
| `GRAFANA_USER`, `GRAFANA_PASSWORD` | `admin` | вход в Grafana |

Путь `/metrics` не требует входа — это нужно сборщику. Закройте его
снаружи на обратном прокси: в `deploy/nginx-kanban.conf` достаточно
ограничить доступ по адресу сборщика.

## Проверка вручную

```bash
curl -s localhost:8080/metrics | head -40
```

Если ответ пустой, проверьте `METRICS_ENABLED` и сообщение в журнале
приложения: `метрики включены endpoint=/metrics`.
